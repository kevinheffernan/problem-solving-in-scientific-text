# baseline for element marking using HMM + Viterbi

import nltk, json, pickle
from nltk.tag import hmm

import numpy as np
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix

np.random.seed(0)





# need to generate 5 different baselines

# convert to s,e,entity type
def convert_element_info(statement):
    conversion = []
    conversion.append((statement.signal["start"], statement.signal["end"], "SIGNAL"))
    if getattr(statement, "root"):
        conversion.append((statement.root["start"], statement.root["end"], "ROOT-"+statement.root["direction"].upper()))
    if getattr(statement, "head"):
        conversion.append((statement.head["start"], statement.head["end"], "COMPLEMENT-"+statement.head["direction"].upper()))
    if getattr(statement, "condition"):
        conversion.append((statement.condition["start"], statement.condition["end"], "CONDITION-"+statement.condition["direction"].upper()))
    return str(sorted(conversion))


def search_right_of_signal(end, ners):
    elements = []
    for j in range(end+1, len(ners)):
        if ners[j][2] in ["SIGNAL", "SOLUTION"]:
            break
        elif ners[j][2].split("-")[1] == "LEFT":
            elements.append(ners[j])
    return elements


def search_left_of_signal(start, ners):
    elements = []
    for j in range(start-1, -1, -1):
        # stop search if another signal is reached
        if ners[j][2] in ["SIGNAL", "SOLUTION"]:
            break
        elif ners[j][2].split("-")[1] == "RIGHT":
            elements.append(ners[j])
    return elements


def group_into_problem_statements(ners):
    # sort ners by starts (first element is start)
    # print("NERS:", ners)
    ners = sorted(ners)
    problem_statements = []
    for index, ner in enumerate(ners):
        if ner[2] == "SIGNAL":
            problem_statement = [ner]
            right_elements = search_right_of_signal(index, ners)            
            left_elements = search_left_of_signal(index, ners)

            if len(left_elements) > 0:
                problem_statement += left_elements
            if len(right_elements) > 0:
                problem_statement += right_elements
            problem_statements.append(str(sorted(problem_statement)))
    return problem_statements


def load_bilstm_data(prediction_file):
    sentences, sentence = [], []
    with open(prediction_file, "r") as infile:
        for line in infile:
            if line.strip() == "":
                sentences.append(sentence)
                sentence = []
            else:
                sentence.append(line.strip().split())
    return sentences


# given starting tag e.g. B-S
def get_current_element(start_tag):
    if start_tag.split("-")[1] == "E+":
        current_element ="SOLUTION"
    elif start_tag.split("-")[1] == "S":
        current_element ="SIGNAL"
    elif start_tag.split("-")[1] == "RR":
        current_element ="ROOT-RIGHT"
    elif start_tag.split("-")[1] == "RL":
        current_element ="ROOT-LEFT"
    elif start_tag.split("-")[1] == "R":
        current_element ="ROOT"                
    elif start_tag.split("-")[1] == "HL":
        current_element ="COMPLEMENT-LEFT"
    elif start_tag.split("-")[1] == "HR":
        current_element ="COMPLEMENT-RIGHT"
    elif start_tag.split("-")[1] == "H":
        current_element ="COMPLEMENT"                       
    elif start_tag.split("-")[1] == "CL":
        current_element ="CONDITION-LEFT"
    elif start_tag.split("-")[1] == "CR":
        current_element ="CONDITION-RIGHT"
    elif start_tag.split("-")[1] == "C":
        current_element ="CONDITION"        
    return current_element


def convert_to_entity_based(test_predictions):
    # now generate entity-based stats using extract.sentence_no, start, end, entity
    hmm_pred_ners = []
    for sentence in test_predictions:
        ners = []
        start = None
        current_element = None
        for token_no, element in enumerate(sentence):
            token, tag = element[0], element[1]
            if (tag == "O") or (token_no == len(sentence)-1):
                # there was an element before
                if start != None:
                    ners.append((start, token_no-1, current_element))
                    # reset start
                    start = None
                # if we're at the end of sentence and not inside element
                elif tag != "O":
                    current_element = get_current_element(tag)
                    ners.append((token_no, token_no, current_element))
            # beginning of new element
            elif tag.split("-")[0] == "B":
                # if there was element before
                if start != None:
                    ners.append((start, token_no-1, current_element))
                # get new starts and current_element
                current_element = get_current_element(tag)
                start = token_no
        hmm_pred_ners.append(ners)
    return hmm_pred_ners



# gets significance between two different types
def rand_permutation_two_types(baseline, prediction, n, R, answer, num_types, typ1, typ2):
    # print("N", n)
    delta_orig = get_fscore_diff_two_types(baseline, prediction, answer, num_types, typ1, typ2)
    print("delta orig", delta_orig)
    r = 0
    for x in range(0, R):
        temp_A = [e for e in baseline]
        temp_B = [e for e in prediction]
        samples = [np.random.randint(1, 3) for i in range(n)] 
        swap_ind = [i for i, val in enumerate(samples) if val == 1]
        for ind in swap_ind:
            temp_B[ind], temp_A[ind] = temp_A[ind], temp_B[ind]
        delta = get_fscore_diff_two_types(temp_A, temp_B, answer, num_types, typ1, typ2)
        # if result is more extreme
        if(delta>=delta_orig):
            r = r+1
    # print("r:", r)
    pval = float(r+1.0)/(R+1.0)
    # return two-tailed test
    return pval * 2.0


# data_A = baseline, data_B
def rand_permutation(baseline, prediction, n, R, answer, num_types, typ):
    # print("N", n)
    delta_orig = get_fscore_diff(baseline, prediction, answer, num_types, typ)
    print("delta orig", delta_orig)
    r = 0
    for x in range(0, R):
        temp_A = [e for e in baseline]
        temp_B = [e for e in prediction]
        samples = [np.random.randint(1, 3) for i in range(n)] 
        swap_ind = [i for i, val in enumerate(samples) if val == 1]
        for ind in swap_ind:
            temp_B[ind], temp_A[ind] = temp_A[ind], temp_B[ind]
        delta = get_fscore_diff(temp_A, temp_B, answer, num_types, typ)
        # if result is more extreme
        if(delta>=delta_orig):
            r = r+1
    # print("r:", r)
    pval = float(r+1.0)/(R+1.0)
    # return two-tailed test
    return pval * 2.0


def get_f1_measures(gold_ners, pred_ners, num_types):
    # # unpack extract groups into sentences
    # gold_ners = [s for e in gold_ners for s in e]
    # pred_ners = [s for e in pred_ners for s in e]
    # 1 -> 600
    tp, fn, fp = 0,0,0
    sub_tp, sub_fn, sub_fp = {},{},{}

    for sent in range(len(gold_ners)):
        # remove all to do with solution for now
        gold_ners_to_remove = set()
        pred_ners_to_remove = set()
        for ner in gold_ners[sent]:
            if ner[2] == "SOLUTION":
                gold_ners_to_remove.add(ner)
        for ner in pred_ners[sent]:
            if ner[2] == "SOLUTION":
                pred_ners_to_remove.add(ner)
        gold_ners_sent = set(gold_ners[sent]) - gold_ners_to_remove
        pred_ners_sent = set(pred_ners[sent]) - pred_ners_to_remove
        tp += len(set(gold_ners_sent) & set(pred_ners_sent))
        fn += len(set(gold_ners_sent) - set(pred_ners_sent))
        fp += len(set(pred_ners_sent) - set(gold_ners_sent))
        
        # tp += len(set(gold_ners[sent]) & set(pred_ners[sent]))
        # fn += len(set(gold_ners[sent]) - set(pred_ners[sent]))
        # fp += len(set(pred_ners[sent]) - set(gold_ners[sent]))

        for i in num_types:
            sub_gm = set((s,e,t) for s,e,t in gold_ners[sent] if t == i)
            sub_pm = set((s,e,t) for s,e,t in pred_ners[sent] if t == i)

            if i not in sub_tp: sub_tp[i] = 0
            if i not in sub_fn: sub_fn[i] = 0
            if i not in sub_fp: sub_fp[i] = 0

            sub_tp[i] += len(sub_gm & sub_pm)
            sub_fn[i] += len(sub_gm - sub_pm)
            sub_fp[i] += len(sub_pm - sub_gm)

    m_r = 0 if tp == 0 else float(tp)/(tp+fn)
    m_p = 0 if tp == 0 else float(tp)/(tp+fp)
    m_f1 = 0 if m_p == 0 else 2.0*m_r*m_p/(m_r+m_p)

    # print("overall mention: %.2f/%.2f/%.2f" % (m_p,m_r,m_f1))
    # print("Mention F1: {:.2f}%".format(m_f1*100))
    # print("Mention recall: {:.2f}%".format(m_r*100))
    # print("Mention precision: {:.2f}%".format(m_p*100))

    precisions, recalls, f1s = [], [], []

    # print("****************SUB NER TYPES********************")
    for i in num_types:
        # ignoring solution for now
        if i == "SOLUTION": continue
        sub_r = 0 if sub_tp[i] == 0 else float(sub_tp[i]) / (sub_tp[i] + sub_fn[i])
        sub_p = 0 if sub_tp[i] == 0 else float(sub_tp[i]) / (sub_tp[i] + sub_fp[i])
        precisions.append(sub_p)
        recalls.append(sub_r)
        sub_f1 = 0 if sub_p == 0 else 2.0 * sub_r * sub_p / (sub_r + sub_p)
        f1s.append(sub_f1)
        # print(i)
        # print(i, "%.2f/%.2f/%.2f" % (sub_p, sub_r, sub_f1))
        # print("{} F1: {:.2f}%".format(i,sub_f1 * 100))
        # print("{} recall: {:.2f}%".format(i,sub_r * 100))
        # print("{} precision: {:.2f}%".format(i,sub_p * 100))

    macro_p = sum(precisions)/len(precisions)
    macro_r = sum(recalls)/len(recalls)
    macro_f1 = sum(f1s)/len(f1s)
    # print("MICRO MENTION: %.2f/%.2f/%.2f" % (m_p,m_r,m_f1))
    # print("MACRO MENTION: %.2f/%.2f/%.2f" % (macro_p, macro_r, macro_f1))
    # return micro f1, macro f1 and individual f1s
    return m_f1, macro_f1, f1s


experiment_type = "joint"

# get predictions output from the BiLSTM+CRF model
bilstm_pred_ners = convert_to_entity_based(load_bilstm_data("predictions/bilstm_%s_predictions.txt" % experiment_type))
with open('predictions/hmm_predictions_%s.pickle' % experiment_type, 'rb') as f:
     hmm_pred_ners = pickle.load(f)
with open('predictions/biaffine_predictions_%s.pickle' % experiment_type, 'rb') as f:
     biaffine_pred_ners = pickle.load(f)
     if experiment_type == "solution":
         biaffine_pred_ners = biaffine_pred_ners[0::6]

# test_predictions = load_bilstm_data("/home/kevin/emnlp2017-bilstm-cnn-crf/joint_predictions.txt")

# get gold ners
with open("../test/test_docs_%s.jsonlines" % experiment_type, "r") as infile:
    json_lines_test = [json.loads(line) for line in infile.readlines()]
gold_ners = [[tuple(ner) for ner in ners] for extract in json_lines_test for ners in extract["ners"]]


print(len(gold_ners), len(bilstm_pred_ners), len(biaffine_pred_ners), len(hmm_pred_ners))


if experiment_type == "joint":
    num_types = ["SIGNAL", "ROOT-RIGHT", "ROOT-LEFT", "COMPLEMENT-LEFT", "COMPLEMENT-RIGHT", "CONDITION-LEFT", "CONDITION-RIGHT", "SOLUTION"]
elif experiment_type == "problem":
    num_types = ["SIGNAL", "ROOT-RIGHT", "ROOT-LEFT", "COMPLEMENT-LEFT", "COMPLEMENT-RIGHT", "CONDITION-LEFT", "CONDITION-RIGHT"]
elif experiment_type == "problem_no_direction":
    num_types = ["SIGNAL", "ROOT", "COMPLEMENT", "CONDITION"]
elif experiment_type == "joint_no_direction":
    num_types = ["SIGNAL", "ROOT", "COMPLEMENT", "CONDITION", "SOLUTION"]    
else:
    num_types = ["SOLUTION"]



def get_gold_problem_statements():
    # get statement-based precision/recall/f-measure
    from get_problem_statements import get_all_problem_statements
    all_problem_statements = get_all_problem_statements('test')
    # break down into sentence based
    sent_problem_statements = [all_problem_statements[extract][sentence] for extract in range(100) for sentence in range(6)]
    # convert each statement to (start, end, element_type)
    converted = [[convert_element_info(statement) for statement in sentence] for sentence in sent_problem_statements]
    return converted


# global variable
gold_problem_statements = get_gold_problem_statements()
    

def get_f1_score_problem_statement(pred_ners):
    # print("len of gold problem statements",len(gold_problem_statements))
    # gold_problem_statements = get_gold_problem_statements()
    pred_problem_statements = [group_into_problem_statements(pred_ner) for pred_ner in pred_ners]
    tp, fn, fp = 0,0,0

    for sent in range(len(gold_problem_statements)):
        tp += len(set(gold_problem_statements[sent]) & set(pred_problem_statements[sent]))
        fn += len(set(gold_problem_statements[sent]) - set(pred_problem_statements[sent]))
        fp += len(set(pred_problem_statements[sent]) - set(gold_problem_statements[sent]))

    m_r = 0 if tp == 0 else float(tp)/(tp+fn)
    m_p = 0 if tp == 0 else float(tp)/(tp+fp)
    m_f1 = 0 if m_p == 0 else 2.0*m_r*m_p/(m_r+m_p)
    # print("Statement precision/recall/f-measure: %.2f/%.2f/%.2f" % (m_p, m_r, m_f1))    
    return m_f1


def get_fscore_diff(baseline_ners, pred_ners, gold_ners, num_types, typ):
    b_micro_f1, b_macro_f1, b_element_f1s = get_f1_measures(gold_ners, baseline_ners, num_types)
    p_micro_f1, p_macro_f1, p_element_f1s = get_f1_measures(gold_ners, pred_ners, num_types)    
    if typ == 'micro': return float(abs(p_micro_f1 - b_micro_f1))
    elif typ == 'macro': return float(abs(p_macro_f1 - b_macro_f1))
    elif typ == "problem_statement":
        return float(abs(get_f1_score_problem_statement(pred_ners))) - float(abs(get_f1_score_problem_statement(baseline_ners))) 
    else:
        return float(abs(p_element_f1s[num_types.index(typ)] - b_element_f1s[num_types.index(typ)]))


def get_fscore_diff_two_types(baseline_ners, pred_ners, gold_ners, num_types, typ1, typ2):
    b_micro_f1, b_macro_f1, b_element_f1s = get_f1_measures(gold_ners, baseline_ners, num_types)
    p_micro_f1, p_macro_f1, p_element_f1s = get_f1_measures(gold_ners, pred_ners, num_types)    
    return float(abs(p_element_f1s[num_types.index(typ1)] - b_element_f1s[num_types.index(typ2)]))    


### SET PREDICTION NERS ###
pred_ners = hmm_pred_ners

get_f1_measures(gold_ners, pred_ners, num_types)

# # group ners by extract
# hmm_pred_ners_extracts = [hmm_pred_ners[start:start+6] for start in range(0, 600, 6)]
# biaffine_pred_ners_extracts = [biaffine_pred_ners[start:start+6] for start in range(0, 600, 6)]
# bilstm_pred_ners_extracts = [bilstm_pred_ners[start:start+6] for start in range(0, 600, 6)]
# gold_ners_extracts = [gold_ners[start:start+6] for start in range(0, 600, 6)]
    
R = 10000


# # print("BIAFFINE CONFUSION MATRIX\n")
# # print(gold_ners)
# # print(confusion_matrix(gold_ners, biaffine_pred_ners))

# # get_fscore_diff(biaffine_pred_ners, biaffine_pred_ners, gold_ners, num_types, "")

# # print("fscore:", get_fscore_diff(gold_ners, pred_ners, num_types, "macro"))
# # typ = "macro"

# # print("TYPE:", typ)
# pval = rand_permutation_two_types(biaffine_pred_ners, biaffine_pred_ners, len(gold_ners), R, gold_ners, num_types, "ROOT-RIGHT", "ROOT-LEFT")
# if float(pval) <= float(0.05): significance = "*"
# if float(pval) <= float(0.01): significance = "**"
# if float(pval) <= float(0.001): significance = "***"
# if float(pval) > float(0.05): significance = ""
# print("Significance: (" + str(significance) + ") pval:", pval)

for typ in ["micro", "macro"]:
    print("TYPE:", typ)
    pval = rand_permutation(bilstm_pred_ners, biaffine_pred_ners, len(gold_ners), R, gold_ners, num_types, typ)
    if float(pval) <= float(0.05): significance = "*"
    if float(pval) <= float(0.01): significance = "**"
    if float(pval) <= float(0.001): significance = "***"
    if float(pval) > float(0.05): significance = ""
    print("Significance: (" + str(significance) + ") pval:", pval)




#     # print(len(sent_problem_statements))
#     # print(sent_problem_statements[4])
#     # print(convert_element_info(sent_problem_statements[4][0]))
#     # print(convert_element_info(sent_problem_statements[-4][0]))
#     # print(convert_element_info(sent_problem_statements[-4][1]))

# # gold_problem_statements = get_gold_problem_statements()
# # pred_problem_statements = [group_into_problem_statements(pred_ner) for pred_ner in pred_ners]

# # print(gold_problem_statements == pred_problem_statements)    
# # tp, fn, fp = 0,0,0

# # for sent in range(len(gold_problem_statements)):
# #     # print(gold_problem_statements[sent])
# #     # print(pred_problem_statements[sent])
# #     tp += len(set(gold_problem_statements[sent]) & set(pred_problem_statements[sent]))
# #     fn += len(set(gold_problem_statements[sent]) - set(pred_problem_statements[sent]))
# #     fp += len(set(pred_problem_statements[sent]) - set(gold_problem_statements[sent]))

# # m_r = 0 if tp == 0 else float(tp)/(tp+fn)
# # m_p = 0 if tp == 0 else float(tp)/(tp+fp)
# # m_f1 = 0 if m_p == 0 else 2.0*m_r*m_p/(m_r+m_p)

# # print("Statement precision/recall/f-measure: %.2f/%.2f/%.2f" % (m_p, m_r, m_f1))
# # print("Statement F1: {:.2f}%".format(m_f1*100))
# # print("Statement recall: {:.2f}%".format(m_r*100))
# # print("Statement precision: {:.2f}%".format(m_p*100))



# # print(len(gold_problem_statements[0]))
# # print(len(gold_problem_statements[-1]))
# # print(len(gold_problem_statements[-2]))
# # print(len(gold_problem_statements[-3]))
# # print(len(gold_problem_statements[-4]), gold_problem_statements[-4])
# # print(len(gold_problem_statements[-2]), gold_problem_statements[-2])
# # print(len(pred_problem_statements[-2]), pred_problem_statements[-2])
# # for i in range(600):
# #     if gold_problem_statements[i] != pred_problem_statements[i]:
# #         print("DIFF:", i)
# #         print(gold_problem_statements[i])
# #         print(pred_problem_statements[i])        

# # print(tagger.tag("This is a problem".split()))
# # print(tagger.tag("This is a problem for the model".split()))
# # print(tagger.tag("If it is not good , there is an issue with the model".split()))
# # print(tagger.tag("In this paper , we propose a new model .".split()))

