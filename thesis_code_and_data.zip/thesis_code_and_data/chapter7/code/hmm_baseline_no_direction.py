# baseline for element marking using HMM + Viterbi but with no directino

import nltk, json, pickle
from nltk.tag import hmm


def load_bilstm_data(prediction_file):
    sentences, sentence = [], []
    with open(prediction_file, "r") as infile:
        for line in infile:
            if line.strip() == "":
                sentences.append(sentence)
                sentence = []
            else:
                sentence.append(line.strip().split())
    return sentences


def load_bio_data(bio_file, no_direction):
    previous_line = ""
    extra_line_occurred = False
    extracts, extract, sentence = [], [], []

    with open(bio_file, "r") as infile:
        for line in infile:
            # three empty lines
            if previous_line.strip() == "" and line.strip() == "" and extra_line_occurred:
                extracts.append(extract)
                # reset extract
                extract = []
            elif previous_line.strip() == "" and line.strip() == "" and not extra_line_occurred:
                extra_line_occurred = True
            elif line.strip() == "":
                extract.append(sentence)
                sentence = []
                extra_line_occurred = False
            else:
                token = line.split()[0]
                bio_tag = line.split()[1]
                if no_direction:
                    if bio_tag.endswith("L") or bio_tag.endswith("R"):
                        bio_tag = bio_tag[:-1]
                sentence.append((token, bio_tag))
            previous_line = line
    return extracts


# given starting tag e.g. B-S
def get_current_element(start_tag):
    if start_tag.split("-")[1] == "E+":
        current_element ="SOLUTION"
    elif start_tag.split("-")[1] == "S":
        current_element ="SIGNAL"
    elif start_tag.split("-")[1] == "R":
        current_element ="ROOT"
    elif start_tag.split("-")[1] == "H":
        current_element ="COMPLEMENT"       
    elif start_tag.split("-")[1] == "C":
        current_element ="CONDITION"
    return current_element


# convert to s,e,entity type
def convert_element_info(statement):
    conversion = []
    conversion.append((statement.signal["start"], statement.signal["end"], "SIGNAL"))
    if getattr(statement, "root"):
        conversion.append((statement.root["start"], statement.root["end"], "ROOT-"+statement.root["direction"].upper()))
    if getattr(statement, "head"):
        conversion.append((statement.head["start"], statement.head["end"], "COMPLEMENT-"+statement.head["direction"].upper()))
    if getattr(statement, "condition"):
        conversion.append((statement.condition["start"], statement.condition["end"], "CONDITION-"+statement.condition["direction"].upper()))
    return str(sorted(conversion))


def search_right_of_signal(end, ners):
    elements = []
    for j in range(end+1, len(ners)):
        if ners[j][2] in ["SIGNAL", "SOLUTION"]:
            break
        elif ners[j][2].split("-")[1] == "LEFT":
            elements.append(ners[j])
    return elements


def search_left_of_signal(start, ners):
    elements = []
    for j in range(start-1, -1, -1):
        # stop search if another signal is reached
        if ners[j][2] in ["SIGNAL", "SOLUTION"]:
            break
        elif ners[j][2].split("-")[1] == "RIGHT":
            elements.append(ners[j])
    return elements


def group_into_problem_statements(ners):
    # sort ners by starts (first element is start)
    # print("NERS:", ners)
    ners = sorted(ners)
    problem_statements = []
    for index, ner in enumerate(ners):
        if ner[2] == "SIGNAL":
            problem_statement = [ner]
            right_elements = search_right_of_signal(index, ners)            
            left_elements = search_left_of_signal(index, ners)

            if len(left_elements) > 0:
                problem_statement += left_elements
            if len(right_elements) > 0:
                problem_statement += right_elements
            problem_statements.append(str(sorted(problem_statement)))
    return problem_statements


def convert_to_entity_based(test_predictions):
    # now generate entity-based stats using extract.sentence_no, start, end, entity
    hmm_pred_ners = []
    for sentence in test_predictions:
        ners = []
        start = None
        current_element = None
        for token_no, element in enumerate(sentence):
            token, tag = element[0], element[1]
            if (tag == "O") or (token_no == len(sentence)-1):
                # there was an element before
                if start != None:
                    ners.append((start, token_no-1, current_element))
                    # reset start
                    start = None
                # if we're at the end of sentence and not inside element
                elif tag != "O":
                    current_element = get_current_element(tag)
                    ners.append((token_no, token_no, current_element))
            # beginning of new element
            elif tag.split("-")[0] == "B":
                # if there was element before
                if start != None:
                    ners.append((start, token_no-1, current_element))
                # get new starts and current_element
                current_element = get_current_element(tag)
                start = token_no
        hmm_pred_ners.append(ners)
    return hmm_pred_ners


experiment_type = "joint_no_direction"


training_extracts = load_bio_data("../train/training_docs_joint.bio", no_direction=True)
dev_extracts = load_bio_data("../dev/dev_docs_joint.bio", no_direction=True)
test_extracts = load_bio_data("../test/test_docs_joint.bio", no_direction=True)

print(len(training_extracts), len(dev_extracts), len(test_extracts))

training_data = [sentence for extract in training_extracts + dev_extracts for sentence in extract]
test_data = [sentence for extract in test_extracts for sentence in extract]

print(len(training_data))
print(len(test_data))

trainer = hmm.HiddenMarkovModelTrainer()
# train model
tagger = trainer.train_supervised(training_data)
print(tagger)
# get test predictions
hmm_test_predictions = [tagger.tag([t[0] for t in sentence]) for sentence in test_data]

# get predictions output from the BiLSTM+CRF model
# test_predictions = load_bilstm_data("/home/kevin/emnlp2017-bilstm-cnn-crf/problem_predictions.txt")
# test_predictions = load_bilstm_data("/home/kevin/emnlp2017-bilstm-cnn-crf/Joint_no_direction_predictions.txt")

pred_ners = convert_to_entity_based(hmm_test_predictions)

with open("../test/test_docs_%s.jsonlines" % experiment_type, "r") as infile:
    json_lines_test = [json.loads(line) for line in infile.readlines()]
gold_ners = [[tuple(ner) for ner in ners] for extract in json_lines_test for ners in extract["ners"]]


# pred_ners = convert_to_entity_based(hmm_test_predictions)
# save hmm baseline
with open("hmm_predictions_joint_no_direction.pickle", "wb") as outfile:
    pickle.dump(pred_ners, outfile)
# # pred_ners = pred_ners
# with open('/home/kevin/biaffine-ner/biaffine_predictions_joint_no_direction.pickle', 'rb') as f:
#      pred_ners = pickle.load(f)

print(len(gold_ners))
print(len(hmm_test_predictions))
print(hmm_test_predictions[-51])
print(pred_ners[-51])
print(gold_ners[-51])

if experiment_type == "problem_no_direction":
    num_types = ["SIGNAL", "ROOT", "COMPLEMENT", "CONDITION"]
elif experiment_type == "joint_no_direction":
    num_types = ["SIGNAL", "ROOT", "COMPLEMENT", "CONDITION", "SOLUTION"]    
else:
    num_types = ["SOLUTION"]


# 1 -> 600
tp, fn, fp = 0,0,0
sub_tp, sub_fn, sub_fp = {},{},{}

for sent in range(len(gold_ners)):
    tp += len(set(gold_ners[sent]) & set(pred_ners[sent]))
    fn += len(set(gold_ners[sent]) - set(pred_ners[sent]))
    fp += len(set(pred_ners[sent]) - set(gold_ners[sent]))

    for i in num_types:
        sub_gm = set((s,e,t) for s,e,t in gold_ners[sent] if t == i)
        sub_pm = set((s,e,t) for s,e,t in pred_ners[sent] if t == i)
        
        if i not in sub_tp: sub_tp[i] = 0
        if i not in sub_fn: sub_fn[i] = 0
        if i not in sub_fp: sub_fp[i] = 0
        
        sub_tp[i] += len(sub_gm & sub_pm)
        sub_fn[i] += len(sub_gm - sub_pm)
        sub_fp[i] += len(sub_pm - sub_gm)

m_r = 0 if tp == 0 else float(tp)/(tp+fn)
m_p = 0 if tp == 0 else float(tp)/(tp+fp)
m_f1 = 0 if m_p == 0 else 2.0*m_r*m_p/(m_r+m_p)

print("overall mention: %.2f/%.2f/%.2f" % (m_p,m_r,m_f1))
print("Mention F1: {:.2f}%".format(m_f1*100))
print("Mention recall: {:.2f}%".format(m_r*100))
print("Mention precision: {:.2f}%".format(m_p*100))

# # predictions are in format: (sentence_id, start, end, ner type) (1 indexed)
# # fp fn is based off entities
# # print("saving predictions and gold mentions to file")
# # with open("tmp_biaffine_ner_predictions.txt", "w") as outfile:
# #   for tmp_pred_extract in predictions:


precisions, recalls = [], []

print("****************SUB NER TYPES********************")
for i in num_types:
    sub_r = 0 if sub_tp[i] == 0 else float(sub_tp[i]) / (sub_tp[i] + sub_fn[i])
    sub_p = 0 if sub_tp[i] == 0 else float(sub_tp[i]) / (sub_tp[i] + sub_fp[i])
    precisions.append(sub_p)
    recalls.append(sub_r)
    sub_f1 = 0 if sub_p == 0 else 2.0 * sub_r * sub_p / (sub_r + sub_p)
    print(i)
    print("%.2f/%.2f/%.2f" % (sub_p, sub_r, sub_f1))
    print("{} F1: {:.2f}%".format(i,sub_f1 * 100))
    print("{} recall: {:.2f}%".format(i,sub_r * 100))
    print("{} precision: {:.2f}%".format(i,sub_p * 100))

macro_p = sum(precisions)/len(precisions)
macro_r = sum(recalls)/len(recalls)
print("MACRO MENTION: %.2f/%.2f/%.2f" % (macro_p,macro_r,((2.0*macro_p*macro_r)/(macro_p+macro_r))))

