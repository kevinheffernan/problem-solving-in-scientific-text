# feature extraction for the Neural Relational Topic Model

import re, numpy, scipy, math, pickle
import numpy as np
from dataclasses import dataclass
from typing import Any
from nltk.metrics import AnnotationTask
from collections import defaultdict
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer


@dataclass
class ProblemStatement:
    signal: dict
    condition: Any = None
    head: Any = None
    root: Any = None
    link_1: bool = False
    link_2: bool = False
    sentence_number: int = None


@dataclass
class SolutionStatement:
    solution: dict


def get_extracts():
    train = "../train/training_docs.txt"    
    test = "../test/test_docs.txt"
    dev = "../dev/dev_docs.txt"
    # dev = "../dev/annotations/Anna_dev.txt"    

    total_extracts = {}
    for i, annotator in enumerate([train, dev, test]):
        extracts = []
        extract = []
        with open(annotator) as infile:
            for l in infile:
                line = l.strip()
                if line == "":
                    extracts.append(extract)
                    extract = []
                else:
                    extract.append(line)
        if i == 0: total_extracts['train'] = extracts
        elif i == 1: total_extracts['dev'] = extracts
        else: total_extracts['test'] = extracts
    return total_extracts    


def find_start_of_element(text, end_of_element):
    for j in range(end_of_element, -1, -1):
        if text[j].startswith("//"):
            start_of_element = j
            return start_of_element

        
def determine_element(i, text, direction):
    element = None
    # if we're searching right, then the condition will need to have a left
    condition = "[^ ]+//C" + ("L" if direction == "right" else "R")
    head = "[^ ]+//H" + ("L" if direction == "right" else "R")
    root = "[^ ]+//R" + ("L" if direction == "right" else "R") + "[^ ]*"
    signal = "[^ ]+//S[^ ]*"
    if re.match(condition, text[i]):
        element = 'condition'
    elif re.match(head, text[i]):
        element = 'head'
    elif re.match(root, text[i]):
        if not text[i].endswith("//RR") and not text[i].endswith("//RL") and not text[i].endswith("//RR[1,2]"):
            print("root to look at:", text[i], text)        
        element = 'root'
    elif re.match(signal, text[i]):
        element = 'signal'
    return element


def find_solution_statements(text, sent_no):
    statements = []
    next_signal_include_root = False
    previous_root = None
    for i, token in enumerate(text):
        if token.endswith("\\\\") or token.endswith("\\\\*") or token.endswith("\\\\**"):
            statements.append(SolutionStatement(solution = extract_basic_info_solution(text, i)))
    return statements


# from each element extract basic information
def extract_basic_info_solution(text, i):
    start_of_element = None
    for j in range(i, -1, -1):
        if text[j].startswith("\\\\"):
            start_of_element = j
            break    
    element_raw_text = " ".join(text[start_of_element : i+1])
    return {"raw": element_raw_text,
            "text": element_raw_text.split("\\\\")[1],
            "start": start_of_element,
            "end": i}


# from each element extract basic information
def extract_basic_info(text, i):
    start_of_element = find_start_of_element(text, i)
    element_raw_text = " ".join(text[start_of_element : i+1])
    return {"raw": element_raw_text,
            "text": element_raw_text.split("//")[1],
            "start": start_of_element,
            "end": i}


def search_right_of_signal(end, text, statement):
    for j in range(end+1, len(text)):
        if determine_element(j, text, None) == "signal":
            break
        elif determine_element(j, text, "right") in ["root", "head", "condition"]:
            if determine_element(j, text, "right") == "condition":
                statement.condition = extract_basic_info(text, j)
                statement.condition["direction"] = "left"
            elif determine_element(j, text, "right") == "head":
                statement.head = extract_basic_info(text, j)
                statement.head["direction"] = "left"
            elif determine_element(j, text, "right") == "root":
                statement.root = extract_basic_info(text, j)
                statement.root["direction"] = "left"                                
    return statement


def search_left_of_signal(start, text, statement):
    for j in range(start-1, -1, -1):
        # stop search if another signal is reached
        if determine_element(j, text, None) == "signal":
            break
        elif determine_element(j, text, "left") in ["root", "head", "condition"]:
            if determine_element(j, text, "left") == "condition":
                statement.condition = extract_basic_info(text, j)
                statement.condition["direction"] = "right"
            elif determine_element(j, text, "left") == "head":
                statement.head = extract_basic_info(text, j)
                statement.head["direction"] = "right"
            elif determine_element(j, text, "left") == "root":
                statement.root = extract_basic_info(text, j)
                statement.root["direction"] = "right"                
    return statement


def find_statements(text, sent_no):
    statements = []
    next_signal_include_root = False
    previous_root = None
    total_heads, heads_in_statements = 0, 0
    total_conditions, conditions_in_statements = 0, 0
    total_roots, roots_in_statements = 0, 0        
    for i, token in enumerate(text):
        if determine_element(i, text, None) == "signal":
            # print("signal found")
            # new statement
            start_of_signal = find_start_of_element(text, i)
            signal_raw_text = " ".join(text[start_of_signal : i+1])
            link1, link2 = False, False
            if "**" in signal_raw_text.split("//")[2]:
                link2 = True
            if signal_raw_text.split("//")[2] in ["S**,*", "S*", "S*,**"]:
                link1 = True
            statement = ProblemStatement(signal = extract_basic_info(text, i))
            statement.link_1 = link1
            statement.link_2 = link2
            statement.sentence_number = sent_no
            statement = search_left_of_signal(start_of_signal, text, statement)                        
            statement = search_right_of_signal(i, text, statement)
            # # check for RR[1,2]
            # if next_signal_include_root:
            #     statement.root = previous_root
            #     next_signal_include_root = False
            # elif statement.root and "[" in statement.root["raw"].split("//")[2]:
            #     next_signal_include_root = True
            #     previous_root = statement.root
            if statement.head: heads_in_statements += 1
            if statement.condition: conditions_in_statements += 1
            if statement.root: roots_in_statements += 1                        
            statements.append(statement)

        if determine_element(i, text, "left") == "head": total_heads +=1
        if determine_element(i, text, "right") == "head": total_heads +=1
        
        if determine_element(i, text, "left") == "condition": total_conditions +=1
        if determine_element(i, text, "right") == "condition": total_conditions +=1

        if determine_element(i, text, "left") == "root": total_roots +=1
        if determine_element(i, text, "right") == "root": total_roots +=1                

    if total_heads != heads_in_statements:
        print("head discrepancy")
        print(text)
    if total_conditions != conditions_in_statements:
        print("condition discrepancy")
        print(text)
    if total_roots != roots_in_statements:
        print("root discrepancy")
        print(text)                
    return statements


def determine_link_label(statement):
    if statement.link_2 and statement.link_1:
        return 3
    elif statement.link_2 and not statement.link_1:
        return 2
    elif statement.link_1 and not statement.link_2:
        return 1
    elif not statement.link_1 and not statement.link_2:
        return 0

# for kappa the number of categories also needs to be the same so can only compare if problem is linked or not (not comparing to solution)
def determine_link_label_kappa(statement):
    if statement.link_2 and statement.link_1:
        return 1
    elif statement.link_2 and not statement.link_1:
        return 1
    elif statement.link_1 and not statement.link_2:
        return 1
    elif not statement.link_1 and not statement.link_2:
        return 0    


def calculate_num_retrieved(statements_ann1, elem):
    num_retrieved = 0
    for s_ann1 in statements_ann1:
        # in case of link we always retrieve its status
        if elem == "link":
            num_retrieved += 1
        elif getattr(s_ann1, elem):
            num_retrieved += 1
    return num_retrieved


def check_overlapping(s_ann1, s_ann2, elem, link=False, exact=False):
    overlapping = False
    if exact:
        if bool(set(range(getattr(s_ann1, elem)["start"], getattr(s_ann1, elem)["end"]+1)) ==
            set(range(getattr(s_ann2, elem)["start"], getattr(s_ann2, elem)["end"]+1))):
            if link:
                # extra check for links
                if determine_link_label(s_ann1) == determine_link_label(s_ann2):                        
                    overlapping = True
            else:
                overlapping = True
    else:
        if bool(set(range(getattr(s_ann1, elem)["start"], getattr(s_ann1, elem)["end"]+1)) &
            set(range(getattr(s_ann2, elem)["start"], getattr(s_ann2, elem)["end"]+1))):
            if link:
                # extra check for links
                if determine_link_label(s_ann1) == determine_link_label(s_ann2):                        
                    overlapping = True
            else:
                overlapping = True        
    return overlapping


def calculate_num_relevant(statements_ann1, statements_ann2, elem, exact_type=False):
    num_relevant = 0
    for s_ann1 in statements_ann1:
        for s_ann2 in statements_ann2:
            if elem == "link":
                if check_overlapping(s_ann1, s_ann2, "signal", link=True, exact=exact_type):
                    num_relevant += 1                
            elif getattr(s_ann1, elem) and getattr(s_ann2, elem):
                if check_overlapping(s_ann1, s_ann2, elem, link=False, exact=exact_type):
                    num_relevant += 1
    return num_relevant


def calculate_num_relevant_whole_statement(statements_ann1, statements_ann2):
    num_relevant = 0
    for s_ann1 in statements_ann1:
        statement_overlap = True
        for elem in ["signal", "root", "head", "condition"]:
            # placeholder for boolean
            element_overlap = True
            # if element is present in statement 1
            if getattr(s_ann1, elem):
                element_overlap = False
                for s_ann2 in statements_ann2:
                    # if second statement has same element
                    if getattr(s_ann2, elem):
                        # if perfect overlap
                        if check_overlapping(s_ann1, s_ann2, elem, link=False, exact=True):
                            element_overlap = True
            if not element_overlap:
                statement_overlap = False
        if statement_overlap: num_relevant += 1
    return num_relevant
        

# annotator 2 is considered gold
def calculate_precision_recall(num_retrieved, num_relevant, ann1, ann2, elem):
    if elem == "solution":
        print(ann2, num_retrieved[ann2][elem])
    if elem == "link":
        print()
        print("link num retrieved")
        print(ann1, num_relevant[ann1][ann2][elem], num_retrieved[ann1]["signal"], num_retrieved[ann1]["link"])
        print(ann2, num_relevant[ann1][ann2][elem], num_retrieved[ann2]["signal"], num_retrieved[ann2]["link"])
        print()
        # precision = round(num_relevant[ann1][ann2][elem] / num_relevant[ann1][ann2]["signal"], 2)
        # recall = round(num_relevant[ann1][ann2][elem] / num_relevant[ann2][ann1]["signal"], 2)
        # f_measure = round(2 * ((precision * recall) / (precision + recall)), 2)        

    # since reporting to two decimals places need to round to two first before calculating f-measure
    precision = round(num_relevant[ann1][ann2][elem] / num_retrieved[ann1][elem], 2)
    recall = round(num_relevant[ann1][ann2][elem] / num_retrieved[ann2][elem], 2)
    f_measure = round(2 * ((precision * recall) / (precision + recall)), 2)
    return (precision, recall, f_measure)


def calculate_num_links(statements_ann1, sentence_number):
    sentence_links = 0
    for s_ann1 in statements_ann1:
        link_type = determine_link_label(s_ann1)
        if link_type in [1,2]:
            sentence_links += 1
            # links_per_sentence[ann1][sentence_number] += 1
        elif link_type == 3:
            sentence_links += 1
            # links_per_sentence[ann1][sentence_number] += 2
    return sentence_links


def calculate_indices_of_elements(statements):
    indices = {}
    for statement in statements:
        indices[statement.signal["start"]] =  [statement.signal["end"], "S"]
        if statement.root:
            indices[statement.root["start"]] = [statement.root["end"], "R" + ("L" if statement.root["direction"] == "left" else "R")]
        if statement.head:
            indices[statement.head["start"]] = [statement.head["end"], "H" + ("L" if statement.head["direction"] == "left" else "R")]
        if statement.condition:
            indices[statement.condition["start"]] = [statement.condition["end"], "C" + ("L" if statement.condition["direction"] == "left" else "R")]
    return indices


def get_bio_notation(indices_of_elements, sentence):
    bio = []
    index = 0
    while index < len(sentence):
        if index in indices_of_elements:
            start = index
            bio.append("%s\tB-%s" % (sentence[index], indices_of_elements[start][1]))
            index += 1
            while index <= indices_of_elements[start][0]:
                bio.append("%s\tI-%s" % (sentence[index], indices_of_elements[start][1]))
                index += 1
        else:
            bio.append("%s\tO" % (sentence[index]))
            index += 1
    return bio


def calculate_differences(bio_notation):
    differences = {"Kevin:Mam": [], "Kevin:Patricia": [], "Mam:Patricia": []}
    for extract in bio_notation:
        for sentence in bio_notation[extract]:
            kevin_sentence = " ".join([e.split()[0] for e in bio_notation[extract][sentence]["Kevin"]])
            mam_sentence = " ".join([e.split()[0] for e in bio_notation[extract][sentence]["Mam"]])
            patricia_sentence = " ".join([e.split()[0] for e in bio_notation[extract][sentence]["Patricia"]])
            if kevin_sentence != mam_sentence:
                differences["Kevin:Mam"].append((kevin_sentence, mam_sentence))
            if kevin_sentence != patricia_sentence:
                differences["Kevin:Patricia"].append((kevin_sentence, patricia_sentence))
            if mam_sentence != patricia_sentence:
                differences["Mam:Patricia"].append((mam_sentence, patricia_sentence))                                                                                        
    return differences


def calculate_kappa_links(total_problem_statements):
    choices = {"Kevin:Mam": [], "Mam:Patricia": [], "Kevin:Patricia": [], "Kevin:Mam:Patricia": []}
    cumulative_token_no = {"Kevin:Mam": 0, "Kevin:Patricia": 0, "Mam:Patricia": 0}
    overlapping_statements = []
    for extract in total_problem_statements:
        for sentence in total_problem_statements[extract]:
            kevin_statements = total_problem_statements[extract][sentence]["Kevin"]
            mam_statements = total_problem_statements[extract][sentence]["Mam"]
            patricia_statements = total_problem_statements[extract][sentence]["Patricia"]
            for k_s in kevin_statements:
                for m_s in mam_statements:
                    # determine if signals are overlapping
                    if check_overlapping(k_s, m_s, "signal", link=False, exact=False):
                        cumulative_token_no["Kevin:Mam"] += 1
                        choices["Kevin:Mam"].append(("Kevin", cumulative_token_no["Kevin:Mam"], determine_link_label_kappa(k_s)))
                        choices["Kevin:Mam"].append(("Mam", cumulative_token_no["Kevin:Mam"], determine_link_label_kappa(m_s)))                    
                for p_s in patricia_statements:
                    # determine if signals are overlapping
                    if check_overlapping(k_s, p_s, "signal", link=False, exact=False):
                        cumulative_token_no["Kevin:Patricia"] += 1
                        choices["Kevin:Patricia"].append(("Kevin", cumulative_token_no["Kevin:Patricia"], determine_link_label_kappa(k_s)))
                        choices["Kevin:Patricia"].append(("Patricia", cumulative_token_no["Kevin:Patricia"], determine_link_label_kappa(p_s)))
            for m_s in mam_statements:
                for p_s in patricia_statements:
                    # determine if signals are overlapping
                    if check_overlapping(p_s, m_s, "signal", link=False, exact=False):
                        cumulative_token_no["Mam:Patricia"] += 1
                        choices["Mam:Patricia"].append(("Mam", cumulative_token_no["Mam:Patricia"], determine_link_label_kappa(m_s)))
                        choices["Mam:Patricia"].append(("Patricia", cumulative_token_no["Mam:Patricia"], determine_link_label_kappa(p_s)))
            for m_s in mam_statements:
                for p_s in patricia_statements:
                    for k_s in kevin_statements:
                        if check_overlapping(k_s, m_s, "signal", link=False, exact=False) and check_overlapping(k_s, p_s, "signal", link=False, exact=False) and check_overlapping(m_s, p_s, "signal", link=False, exact=False):
                            overlapping_statements.append((k_s, m_s, p_s))
    for i,overlap in enumerate(overlapping_statements):
        k_s = overlap[0]
        m_s = overlap[1]
        p_s = overlap[2]        
        choices["Kevin:Mam:Patricia"].append(("Kevin", i, determine_link_label_kappa(k_s)))
        choices["Kevin:Mam:Patricia"].append(("Mam", i, determine_link_label_kappa(m_s)))
        choices["Kevin:Mam:Patricia"].append(("Patricia", i, determine_link_label_kappa(p_s)))                
    print()
    print("link kappas")
    task = AnnotationTask(data = choices["Kevin:Mam"])
    print("Kevin/Mam:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Mam"])/2)
    task = AnnotationTask(data = choices["Kevin:Patricia"])
    print("Kevin/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Patricia"])/2)
    task = AnnotationTask(data = choices["Mam:Patricia"])
    print("Mam/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Mam:Patricia"])/2)
    task = AnnotationTask(data = choices["Kevin:Mam:Patricia"])
    print("Kevin/Mam/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Mam:Patricia"])/3)
    print()


# kappa for BIO tags
def calculate_precision_recall_bio(bio, simple_bio, solution=False):
    num_retrieved = defaultdict(lambda : defaultdict(dict))
    num_relevant = defaultdict(lambda : defaultdict(dict))
    if simple_bio:
        if solution:
            bio_token_list = ["I-E+", "O"]
        else:
            bio_token_list = ["I-S", "I-RR", "I-RL", "I-HR", "I-HL", "I-CR", "I-CL", "O"]
    else:
        if solution:
            bio_token_list = ["B-E+", "I-E+", "O"]
        else:
            bio_token_list = ["B-S", "I-S", "B-RR", "I-RR", "B-RL", "I-RL", "B-HR", "I-HR", "B-HL", "I-HL", "B-CR", "I-CR", "B-CL", "I-CL", "O"]
    for bio_tag in bio_token_list:
        for group in ["Kevin:Mam", "Kevin:Patricia", "Mam:Patricia"]:
            num_relevant[group][bio_tag] = 0
        num_retrieved["Kevin"][bio_tag] = 0
        num_retrieved["Mam"][bio_tag] = 0
        num_retrieved["Patricia"][bio_tag] = 0
    # print(num_retrieved)
            
    for extract in bio:
        for sentence in bio[extract]:
            if solution:
                # only look at solution sentence
                if sentence == 6:
                    bio_tokens_annotator_1 = [token.split()[1] if token.split()[1] in bio_token_list else "O" for token in bio[extract][sentence]["Kevin"]]
                    for bio_token in bio_tokens_annotator_1:
                        # print(num_retrieved["Kevin"][bio_token], bio_token)
                        # print(bio[extract][sentence]["Kevin"])
                        # print(bio_tokens_annotator_1)                        
                        num_retrieved["Kevin"][bio_token] += 1
                    bio_tokens_annotator_2 = [token.split()[1] if token.split()[1] in bio_token_list else "O" for token in bio[extract][sentence]["Mam"]]                
                    for bio_token in bio_tokens_annotator_2:
                        num_retrieved["Mam"][bio_token] += 1
                    bio_tokens_annotator_3 = [token.split()[1] if token.split()[1] in bio_token_list else "O" for token in bio[extract][sentence]["Patricia"]]                                
                    for bio_token in bio_tokens_annotator_3:
                        num_retrieved["Patricia"][bio_token] += 1                        
                    # 1 is gold
                    for bio_tokens in zip(bio_tokens_annotator_1, bio_tokens_annotator_2):
                        if bio_tokens[0] == bio_tokens[1]:
                            num_relevant["Kevin:Mam"][bio_tokens[0]] += 1
                    # 1 is gold
                    for bio_tokens in zip(bio_tokens_annotator_1, bio_tokens_annotator_3):
                        if bio_tokens[0] == bio_tokens[1]:
                            num_relevant["Kevin:Patricia"][bio_tokens[0]] += 1            
                    # 2 is gold
                    for bio_tokens in zip(bio_tokens_annotator_2, bio_tokens_annotator_3):
                        if bio_tokens[0] == bio_tokens[1]:
                            num_relevant["Mam:Patricia"][bio_tokens[0]] += 1                    
            else:
                bio_tokens_annotator_1 = [token.split()[1] if token.split()[1] not in ["B-E+", "I-E+"] else "O" for token in bio[extract][sentence]["Kevin"]]
                for bio_token in bio_tokens_annotator_1:
                    # print(num_retrieved["Kevin"][bio_token], bio_token)
                    num_retrieved["Kevin"][bio_token] += 1
                bio_tokens_annotator_2 = [token.split()[1] if token.split()[1] not in ["B-E+", "I-E+"] else "O" for token in bio[extract][sentence]["Mam"]]                
                for bio_token in bio_tokens_annotator_2:
                    num_retrieved["Mam"][bio_token] += 1
                bio_tokens_annotator_3 = [token.split()[1] if token.split()[1] not in ["B-E+", "I-E+"] else "O" for token in bio[extract][sentence]["Patricia"]]                                
                for bio_token in bio_tokens_annotator_3:
                    num_retrieved["Patricia"][bio_token] += 1                        
                # 1 is gold
                for bio_tokens in zip(bio_tokens_annotator_1, bio_tokens_annotator_2):
                    if bio_tokens[0] == bio_tokens[1]:
                        num_relevant["Kevin:Mam"][bio_tokens[0]] += 1
                # 1 is gold
                for bio_tokens in zip(bio_tokens_annotator_1, bio_tokens_annotator_3):
                    if bio_tokens[0] == bio_tokens[1]:
                        num_relevant["Kevin:Patricia"][bio_tokens[0]] += 1            
                # 2 is gold
                for bio_tokens in zip(bio_tokens_annotator_2, bio_tokens_annotator_3):
                    if bio_tokens[0] == bio_tokens[1]:
                        num_relevant["Mam:Patricia"][bio_tokens[0]] += 1
    print()
    print("BIO tags precision/recall/f-measure")
    print()
    for group in ["Kevin:Mam", "Kevin:Patricia", "Mam:Patricia"]:
        print(group)
        for bio_tag in bio_token_list:
            precision = round(num_relevant[group][bio_tag] / num_retrieved[group.split(":")[1]][bio_tag], 2)
            recall = round(num_relevant[group][bio_tag] / num_retrieved[group.split(":")[0]][bio_tag], 2)
            f_measure = round(2 * ((precision * recall) / (precision + recall)), 2)
            print(bio_tag + " & " + "%.2f/%.2f/%.2f\\\\" % (precision, recall, f_measure))
        print()
    

# kappa for both sentences where both annotators marked problems
def calculate_kappa_bio_2(bio):
    cumulative_token_no = {"Kevin:Mam": 0, "Kevin:Patricia": 0, "Mam:Patricia": 0, "Kevin:Mam:Patricia": 0}    
    choices = {"Kevin:Mam": [], "Kevin:Patricia": [], "Mam:Patricia": [], "Kevin:Mam:Patricia": []}    
    for extract in bio:
        for sentence in bio[extract]:
            bio_tokens_annotator_1 = [token.split()[1] for token in bio[extract][sentence]["Kevin"]]
            bio_tokens_annotator_2 = [token.split()[1] for token in bio[extract][sentence]["Mam"]]
            bio_tokens_annotator_3 = [token.split()[1] for token in bio[extract][sentence]["Patricia"]]            
            if "I-S" in bio_tokens_annotator_1 and "I-S" in bio_tokens_annotator_2:
                for bio_tokens in zip(bio_tokens_annotator_1, bio_tokens_annotator_2):
                    kevin_bio_token, mam_bio_token = bio_tokens[0], bio_tokens[1]
                    choices["Kevin:Mam"].append(("Kevin", str(cumulative_token_no["Kevin:Mam"]), kevin_bio_token))
                    choices["Kevin:Mam"].append(("Mam", str(cumulative_token_no["Kevin:Mam"]), mam_bio_token))
                    cumulative_token_no["Kevin:Mam"] += 1
            if "I-S" in bio_tokens_annotator_1 and "I-S" in bio_tokens_annotator_3:
                for bio_tokens in zip(bio_tokens_annotator_1, bio_tokens_annotator_3):
                    kevin_bio_token, patricia_bio_token = bio_tokens[0], bio_tokens[1]
                    choices["Kevin:Patricia"].append(("Kevin", str(cumulative_token_no["Kevin:Patricia"]), kevin_bio_token))
                    choices["Kevin:Patricia"].append(("Patricia", str(cumulative_token_no["Kevin:Patricia"]), patricia_bio_token))
                    cumulative_token_no["Kevin:Patricia"] += 1                
            if "I-S" in bio_tokens_annotator_2 and "I-S" in bio_tokens_annotator_3:
                for bio_tokens in zip(bio_tokens_annotator_2, bio_tokens_annotator_3):
                    mam_bio_token, patricia_bio_token = bio_tokens[0], bio_tokens[1]
                    choices["Mam:Patricia"].append(("Mam", str(cumulative_token_no["Mam:Patricia"]), mam_bio_token))
                    choices["Mam:Patricia"].append(("Patricia", str(cumulative_token_no["Mam:Patricia"]), patricia_bio_token))
                    cumulative_token_no["Mam:Patricia"] += 1                
            if "I-S" in bio_tokens_annotator_1 and "I-S" in bio_tokens_annotator_2 and "I-S" in bio_tokens_annotator_3:
                for bio_tokens in zip(bio_tokens_annotator_1, bio_tokens_annotator_2, bio_tokens_annotator_3):
                    kevin_bio_token, mam_bio_token, patricia_bio_token = bio_tokens[0], bio_tokens[1], bio_tokens[2]
                    choices["Kevin:Mam:Patricia"].append(("Kevin", str(cumulative_token_no["Kevin:Mam:Patricia"]), kevin_bio_token))
                    choices["Kevin:Mam:Patricia"].append(("Mam", str(cumulative_token_no["Kevin:Mam:Patricia"]), mam_bio_token))
                    choices["Kevin:Mam:Patricia"].append(("Patricia", str(cumulative_token_no["Kevin:Mam:Patricia"]), patricia_bio_token))                    
                    cumulative_token_no["Kevin:Mam:Patricia"] += 1                                
    print("problem statement kappas (both marked problems in same sentence)")
    task = AnnotationTask(data = choices["Kevin:Mam"])
    print("Kevin/Mam:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Mam"])/2)
    task = AnnotationTask(data = choices["Kevin:Patricia"])
    print("Kevin/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Patricia"])/2)
    task = AnnotationTask(data = choices["Mam:Patricia"])
    print("Mam/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Mam:Patricia"])/2)
    task = AnnotationTask(data = choices["Kevin:Mam:Patricia"])
    print("Kevin/Mam/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Mam:Patricia"])/3)
    
    
def calculate_kappa_bio(bio, indicator, solution=False, all_problem=False, all_solution_problem=False):
    choices = {"Kevin": [], "Mam": [], "Patricia": []}
    cumulative_token_no = {"Kevin": 0, "Mam": 0, "Patricia": 0}
    for extract in bio_notation:
        for sentence in bio_notation[extract]:
            for annotator in bio_notation[extract][sentence]:
                # only take the second bit of info i.e., not the word
                for token in bio_notation[extract][sentence][annotator]:
                    cumulative_token_no[annotator] += 1
                    bio_token = token.split()[1]
                    if solution:
                        if sentence == 6: 
                            if bio_token != "O" and not bio_token.split("-")[1].startswith("E+"):
                                bio_token = "O"
                            choices[annotator].append(('%s' % annotator, str(cumulative_token_no[annotator]), bio_token))
                            if cumulative_token_no[annotator] == 5865:
                                print("sentence to look at")
                                print(bio_notation[extract][sentence][annotator])
                    elif all_problem:
                        if bio_token != "O" and bio_token.split("-")[1].startswith("E+"):
                            bio_token = "O"
                        choices[annotator].append(('%s' % annotator, str(cumulative_token_no[annotator]), bio_token))
                    elif all_solution_problem:
                        choices[annotator].append(('%s' % annotator, str(cumulative_token_no[annotator]), bio_token))                                                    
                    else:
                        if bio_token != "O" and not bio_token.split("-")[1].startswith(indicator):
                            bio_token = "O"                        
                        choices[annotator].append(('%s' % annotator, str(cumulative_token_no[annotator]), bio_token))
            if cumulative_token_no["Kevin"] != cumulative_token_no["Mam"]:
                print("Mismatch between token counts")
                print(bio_notation[extract][sentence][annotator])
    print(cumulative_token_no)
    task = AnnotationTask(data = choices["Kevin"] + choices["Mam"])
    print("Number of choices:")
    print(len(choices["Kevin"]), len(choices["Mam"]))
    kevin_tmp = [a[1] for a in choices["Kevin"]]
    mam_tmp = [a[1] for a in choices["Mam"]]
    for i in range(len(choices["Kevin"])):
        if choices["Kevin"][i][1] != choices["Mam"][i][1]:
            print("mismatch: %d" % i, choices["Kevin"][i], choices["Mam"][i])
    # print([a[1] for a in choices["Mam"])          

    print("Kevin/Mam:", "%.2f" % task.kappa(), "Num instances:", len(choices["Kevin"]))
    task = AnnotationTask(data = choices["Kevin"] + choices["Patricia"])
    print("Kevin/Patricia:", "%.2f" % task.kappa(), "Num instances:", len(choices["Kevin"]))
    task = AnnotationTask(data = choices["Patricia"] + choices["Mam"])
    print("Patricia/Mam:", "%.2f" % task.kappa(), "Num instances:", len(choices["Kevin"]))
    task = AnnotationTask(data = choices["Patricia"] + choices["Mam"] + choices["Kevin"])
    print("All three:", "%.2f" % task.multi_kappa(), "Num instances:", len(choices["Kevin"]))

    
# removes the markings from token
def remove_markings(token):
    # remove prefix marking
    if token[0:2] == "//": token = token[2:]
    if token[0:2] == "\\\\": token = token[2:]    
    # remove postfix marking
    if token.endswith("//HL"): token = token.replace("//HL", "")
    if token.endswith("//HR"): token = token.replace("//HR", "")
    if token.endswith("//RR"): token = token.replace("//RR", "")
    if token.endswith("//RL"): token = token.replace("//RL", "")
    if token.endswith("//CL"): token = token.replace("//CL", "")
    if token.endswith("//CR"): token = token.replace("//CR", "")
    if token.endswith("//S"): token = token.replace("//S", "")
    if token.endswith("//S*"): token = token.replace("//S*", "")
    if token.endswith("//S**"): token = token.replace("//S**", "")
    if token.endswith("//S*,**"): token = token.replace("//S*,**", "")
    if token.endswith("\\\\"): token = token.replace("\\\\", "")
    if token.endswith("\\\\*"): token = token.replace("\\\\*", "")
    if token.endswith("\\\\**"): token = token.replace("\\\\**", "")
    return token    
                

extracts = get_extracts()
print("number of extracts:", len(extracts))
all_extracts = extracts['train'] + extracts['dev'] + extracts['test']
extracts = all_extracts

total_problem_statements = []
total_solution_statements = []

train_solution_statements = []
test_solution_statements = []

train_link_info = []
test_link_info = []

train_statements = []
test_statements = []

statement_number = 0

total_pair_checksum = 0
all_statements = []

# sentences for each statement
all_statement_contexts = []

for extract in range(1000):
    extract_problem_statements = []    
    sentence_number = 0
    for sentence in range(len(extracts[extract])):
        # ignore extract id
        if sentence == 0:
            continue
        sentence_number += 1

        annotator_sent = extracts[extract][sentence].split()
        problem_statements = find_statements(annotator_sent, sentence_number)
        total_problem_statements += problem_statements
        extract_problem_statements += problem_statements
        all_statements += problem_statements
        for statement in problem_statements:
            all_statement_contexts.append(annotator_sent)
        # when we're at the end of an extract
        if sentence_number == 6:
            solution_statements = find_solution_statements(annotator_sent, sentence_number)
            all_statements += solution_statements
            for statement in solution_statements:
                all_statement_contexts.append(annotator_sent)            
            total_pair_checksum = total_pair_checksum + len(extract_problem_statements)*len(solution_statements)
            # get link information for each problem and each solution
            first_solution_number = statement_number + len(extract_problem_statements)

            for p in extract_problem_statements:
                # training info
                if extract < 900:
                    train_statements.append(p)
                    train_link_info.append([statement_number, first_solution_number, p.link_1, p.sentence_number])
                    if len(solution_statements) == 2:
                        train_link_info.append([statement_number, first_solution_number+1, p.link_2, p.sentence_number])
                # development info
                elif extract >= 900:
                    test_statements.append(p)
                    test_link_info.append([statement_number, first_solution_number, p.link_1, p.sentence_number, extract-900+1])
                    if len(solution_statements) == 2:
                        test_link_info.append([statement_number, first_solution_number+1, p.link_2, p.sentence_number, extract-900+1])
                statement_number += 1
            if extract < 900: train_statements += solution_statements
            else: test_statements += solution_statements
            statement_number += len(solution_statements)
        
print("train pairs:", len(train_link_info))
print("test pairs:", len(test_link_info))


# p = statement
def get_context(all_statement_contexts, p, index, context):
    sentence = all_statement_contexts[index]
    lefts, rights = [], []
    if hasattr(p, "signal"):
        lefts.append(p.signal["start"])
        rights.append(p.signal["end"])
        if p.root:
            lefts.append(p.root["start"])
            rights.append(p.root["end"])            
        if p.head:
            lefts.append(p.head["start"])
            rights.append(p.head["end"])                        
        if p.condition:
            lefts.append(p.condition["start"])
            rights.append(p.condition["end"])                                    
    else:
        lefts.append(p.solution["start"])
        rights.append(p.solution["end"])
    most_left = min(lefts)
    most_right = max(rights)
    # if goes below zero take zero
    left_marker = max(most_left - context, 0)
    # if goes beyond sentence length take sentence length
    right_marker = min(most_right + context, len(sentence)-1)
    # return [remove_markings(token) for token in sentence[left_marker:most_left] + sentence[most_right+1:right_marker+1]]
    # using whole sentence for context
    # return [remove_markings(token) for token in sentence[left_marker:most_left]], [remove_markings(token) for token in sentence[most_right+1:right_marker+1]]    
    return [remove_markings(token) for token in sentence]
    
def get_vocab(statements, all_statement_contexts, __CONTEXT__):
    regex = "\( [^)]*[12][0-9][0-9][0-9] [^)]*\)"

    sentences = []
    for index,p in enumerate(statements):
        statement_text = []
        # if problem statement
        if hasattr(p, "signal"):
            statement_text.append(p.signal["text"])
            if p.root:
                statement_text.append(p.root["text"])                
            if p.head:
                statement_text.append(p.head["text"])                
            if p.condition:
                statement_text.append(p.condition["text"])                 
        else:
            statement_text.append(p.solution["text"])                             

        # left_context, right_context = get_context(all_statement_contexts, p, index, __CONTEXT__)
        # context = get_context(all_statement_contexts, p, index, __CONTEXT__)
        context = " ".join(statement_text)
        
        # remove references
        matches = re.findall(regex, context)
        for match in matches:
            context = context.replace(match, "[REF]")
            
        sentences.append(context)        
    if typ == "tfidf":
        vectorizer = TfidfVectorizer(strip_accents='ascii')
    else:
        vectorizer = CountVectorizer(strip_accents='ascii')        
    X = vectorizer.fit_transform(sentences)
    # print(X.shape, type(X))
    print("number of vectorized words:", X.shape)

    return vectorizer


# # context setting
# __CONTEXT__ = 10

print("checksum for length of statements", len(all_statements), len(train_statements)+len(test_statements))
for t in test_link_info:
    print(t)

# vocab = get_vocab(all_statements, all_statement_contexts, __CONTEXT__)

# # initialize the vectorizer on training data
# tf_idf_vectorizer = get_vocab(train_statements, all_statement_contexts, __CONTEXT__)

# print("len of all statements and all_contexts", len(all_statements), len(all_statement_contexts))

# def get_matrix(statements, vectorizer, all_statement_contexts, __CONTEXT__):
#     matrix = []
#     # now gather bow representation
#     sentences = []
#     for index,p in enumerate(statements):
#         statement_text = []
#         # first initialise vector to zero
#         # vector = np.zeros(len(vocab))
#         # get counts of all tokens in statement
#         if hasattr(p, "signal"):
#             statement_text.append(p.signal["text"])
#             if p.root:
#                 statement_text.append(p.root["text"])                
#             if p.head:
#                 statement_text.append(p.head["text"])                
#             if p.condition:
#                 statement_text.append(p.condition["text"])                 
#         else:
#             statement_text.append(p.solution["text"])                                     
#         # if hasattr(p, "signal"):        
#         #     for token in p.signal["text"].split(): vector[vocab.index(token.lower())] += 1.0
#         #     if p.root:
#         #         for token in p.root["text"].split(): vector[vocab.index(token.lower())] += 1.0
#         #     if p.head:
#         #         for token in p.head["text"].split(): vector[vocab.index(token.lower())] += 1.0
#         #     if p.condition:
#         #         for token in p.condition["text"].split(): vector[vocab.index(token.lower())] += 1.0
#         # else:
#         #     for token in p.solution["text"].split(): vector[vocab.index(token.lower())] += 1.0
#         sentences.append(" ".join(statement_text))
#         # for token in get_context(all_statement_contexts, p, index, __CONTEXT__):
#         #     vector[vocab.index(token.lower())] += 1.0            
        
#         # # get log-normalised number of each bow number
#         # denominator = max([math.log(1 + n_i) for n_i in vector])
#         # for i in range(len(vector)):
#         #     # if entry is non-zero
#         #     if vector[i] > 0:
#         #         vector[i] = math.log(1 + vector[i]) / denominator
#         # matrix.append(vector)
#     return vectorizer.transform(sentences).todense()
#     # return np.matrix(matrix)

# docs_matrix = get_matrix(all_statements, tf_idf_vectorizer, all_statement_contexts, __CONTEXT__)
# print("document matrix shape", docs_matrix.shape)

# print(len(total_problem_statements), len(total_solution_statements), len(total_problem_statements) + len(total_solution_statements))

# print("checksum:", total_pair_checksum)

# write vocab to file
# with open("nrtm_vocab_NO_context_TFIDF.txt", "w") as outfile:
#     for token in sorted(tf_idf_vectorizer.vocabulary_:
#         outfile.write("%s\n" % token)

# with open('vocab.pkl', 'wb') as f:
#     pickle.dump(tf_idf_vectorizer.vocabulary_, f, pickle.HIGHEST_PROTOCOL)

# # write training link information to file
# with open("train_no_dev_link_data_tmp.txt", "w") as outfile:
#     for t in train_link_info:
#         outfile.write("%s:%s\t%d\t%d\n" % (t[0], t[1], (1 if t[2] else 0), t[3]))

# # write training link information to file
# with open("train_link_data_Anna.txt", "w") as outfile:
#     for t in train_link_info:
#         outfile.write("%s:%s\t%d\t%d\n" % (t[0], t[1], (1 if t[2] else 0), t[3]))

# # write traininpg link information to file
# with open("test_link_data_Anna.txt", "w") as outfile:
#     for t in test_link_info:
#         outfile.write("%s:%s\t%d\t%d\n" % (t[0], t[1], (1 if t[2] else 0), t[3]))                

# # write training link information to file
# with open("dev_link_data_Patricia.txt", "w") as outfile:
#     for t in test_link_info:
#         outfile.write("%s:%s\t%d\t%d\n" % (t[0], t[1], (1 if t[2] else 0), t[3]))        
        
# # write doc matrix to file
# with open('docs_NO_context_TFIDF.matrix','wb') as outfile:
#     for line in docs_matrix:
#         np.savetxt(outfile, line, fmt='%.2f')


# # SBERT sentence embedding features
# from sentence_transformers import SentenceTransformer

# def get_sbert_features(statements, vocab, all_statement_contexts, __CONTEXT__):
#     matrix = []
#     for index,p in enumerate(statements):
#         # first initialise vector to zero
#         vector = np.zeros(len(vocab))
#         # get counts of all tokens in statement
#         if hasattr(p, "signal"):        
#             for token in p.signal["text"].split(): vector[vocab.index(token.lower())] += 1.0
#             if p.root:
#                 for token in p.root["text"].split(): vector[vocab.index(token.lower())] += 1.0
#             if p.head:
#                 for token in p.head["text"].split(): vector[vocab.index(token.lower())] += 1.0
#             if p.condition:
#                 for token in p.condition["text"].split(): vector[vocab.index(token.lower())] += 1.0
#         else:
#             for token in p.solution["text"].split(): vector[vocab.index(token.lower())] += 1.0
            
#         for token in get_context(all_statement_contexts, p, index, __CONTEXT__):
#             vector[vocab.index(token.lower())] += 1.0            
        
#         # get log-normalised number of each bow number
#         denominator = max([math.log(1 + n_i) for n_i in vector])
#         for i in range(len(vector)):
#             # if entry is non-zero
#             if vector[i] > 0:
#                 vector[i] = math.log(1 + vector[i]) / denominator
#         matrix.append(vector)
#     return np.matrix(matrix)

# docs_matrix = get_matrix(all_statements, vocab, all_statement_contexts, __CONTEXT__)

