# MLP classifier


import tensorflow as tf
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import normalize
import time

flags = tf.app.flags

# define main params via command line
flags.DEFINE_string('optimizer', 'Nadam', 'optimizer to use')
FLAGS = flags.FLAGS


def load_generic_embedding(link_data_file, embedding_file):
    matrix = np.loadtxt(embedding_file)
    indices = np.array([[int(line.strip().split()[0].split(":")[0]), int(line.strip().split()[0].split(":")[1])] for line in open(link_data_file, "r")])
    # print(topic_indices.shape, topic_indices[0], topic_indices[1])
    embeddings = matrix[indices]
    print("embeddings shape:", embeddings.shape);
    # positional_embeddings = load_positional_embeddings(link_data_file)
    # get semantic similarity between both embeddings
    vectors = []
    for index in range(embeddings.shape[0]):
        problem_embedding = embeddings[index][0]
        solution_embedding = embeddings[index][1]    
        # cosine = cosine_similarity(problem_embedding.reshape(1,-1), solution_embedding.reshape(1,-1))[0]
        # print("cosine shape:", cosine.shape, cosine)
        # pos_emb = positional_embeddings[index]
        vector = np.concatenate((problem_embedding, solution_embedding))
        vectors.append(vector)            
    # # combine problem and solution embeddings
    # vectors = []
    # for index in range(embeddings.shape[0]):
    #     problem_embedding = embeddings[index][0]
    #     solution_embedding = embeddings[index][1]    
    #     # vector = np.concatenate((problem_embedding, solution_embedding))
    #     vector = problem_embedding + solution_embedding
    #     vectors.append(vector)    
    return np.array(vectors)

def load_topic_embeddings(link_data_file):
    topic_matrix = np.loadtxt("/home/kevin/Neural-Relational-Topic-Models/topic_embeddings.marix")
    topic_indices = np.array([[int(line.strip().split()[0].split(":")[0]), int(line.strip().split()[0].split(":")[1])] for line in open(link_data_file, "r")])
    print(topic_indices.shape, topic_indices[0], topic_indices[1])
    topic_embeddings = topic_matrix[topic_indices]
    print("topic embeddings shape:", topic_embeddings.shape)
    return topic_embeddings

def load_positional_embeddings(link_data_file):
    embs = [[1,0,0,0,0,0], [0,1,0,0,0,0], [0,0,1,0,0,0], [0,0,0,1,0,0], [0,0,0,0,1,0], [0,0,0,0,0,1]]
    pe = np.array([embs[int(line.strip().split()[2])-1] for line in open(link_data_file, "r")])
    return pe

def combine_embeddings(topic_embeddings, positional_embeddings):
    vectors = []
    for index in range(topic_embeddings.shape[0]):
        problem_topic = topic_embeddings[index][0]
        solution_topic = topic_embeddings[index][1]    
        positional_embedding = positional_embeddings[index]
        vector = np.concatenate((problem_topic, solution_topic))
        vector = np.concatenate((vector, positional_embedding))
        vectors.append(vector)
    return np.array(vectors)

# train_positional_embeddings = load_positional_embeddings("train_link_data.txt")
# test_positional_embeddings = load_positional_embeddings("test_link_data.txt")

# X_train = train_positional_embeddings
# X_test = test_positional_embeddings

# train_topic_embeddings = load_topic_embeddings("train_link_data.txt")
# test_topic_embeddings = load_topic_embeddings("test_link_data.txt")

# print(train_topic_embeddings.shape, train_positional_embeddings.shape)
# print(test_topic_embeddings.shape, test_positional_embeddings.shape)

# X_train = combine_embeddings(train_topic_embeddings, train_positional_embeddings)
# X_test = combine_embeddings(test_topic_embeddings, test_positional_embeddings)

# print("New Xtrain shape", X_train.shape)
# print("New Xtest shape", X_test.shape)

# Create model
def multilayer_perceptron(x, weights, biases):
    # Hidden layer with RELU activation
    layer_1 = tf.add(tf.matmul(x, weights['h1']), biases['b1'])
    layer_1 = tf.nn.relu(layer_1)
    # Hidden layer with RELU activation
    layer_2 = tf.add(tf.matmul(layer_1, weights['h2']), biases['b2'])
    layer_2 = tf.nn.relu(layer_2)
    # Hidden layer with RELU activation
    layer_3 = tf.add(tf.matmul(layer_2, weights['h3']), biases['b3'])
    layer_3 = tf.nn.relu(layer_3)
    
    # layer_4 = tf.add(tf.matmul(layer_3, weights['h4']), biases['b4'])
    # layer_4 = tf.nn.relu(layer_4)        
    # Output layer with linear activation for logits
    out_layer = tf.matmul(layer_3, weights['out']) + biases['out']
    return out_layer




num_seeds = 50
for feature_set in ['binary_C0', 'positional_embeddings', 'SBERT_C0', 'binary_C0__positional_embeddings']:
    different_seed_macro_f1s = []
    different_seed_micro_f1s = []
    different_seed_predictions = []
    for random_seed in range(num_seeds):
        start_time = time.time()
        np.random.seed(0)
        tf.set_random_seed(random_seed)

        # feature_set = "binary_C0__positional_embeddings"
        # feature_set = "SBERT_C0"

        X_train = load_generic_embedding("train_link_data.txt", "feature_files/%s.matrix" % feature_set)
        X_test = load_generic_embedding("test_link_data.txt", "feature_files/%s.matrix" % feature_set)

        # # below for dev set testing
        # X_train = load_generic_embedding("train_no_dev_link_data.txt", "feature_files/%s.matrix" % feature_set)
        # X_test = load_generic_embedding("dev_link_data.txt", "feature_files/%s.matrix" % feature_set)

        print(X_train.shape, X_test.shape)
        print("first 10 test samples")
        print(X_test[0:10])
        # # get train and test data
        # X_train = np.loadtxt("sbert_train_10_CONTEXT.matrix")
        # X_test = np.loadtxt("sbert_test_10_CONTEXT.matrix")


        # # normalize training data
        X_train = normalize(X_train)
        # # normalize testing data
        X_test = normalize(X_test)

        Y_train = np.array([int(line.strip().split()[1]) for line in open("train_link_data.txt", "r")])
        Y_test = np.array([int(line.strip().split()[1]) for line in open("test_link_data.txt", "r")])

        # # below for dev testing only
        # Y_train = np.array([int(line.strip().split()[1]) for line in open("train_no_dev_link_data.txt", "r")])
        # Y_test = np.array([int(line.strip().split()[1]) for line in open("dev_link_data.txt", "r")])

        # X, Y = make_classification(n_samples=50000, n_features=10, n_informative=8, 
        #                            n_redundant=0, n_clusters_per_class=2)
        # # print(Y.shape)
        # # Y = np.array([Y, -(Y-1)]).T  # The model currently needs one column for each class
        # X, X_test, Y, Y_test = train_test_split(X, Y)

        print(X_train.shape, Y_train.shape, Y_test.shape, X_test.shape)


        # Parameters
        learning_rate = 0.01
        training_epochs = 50
        batch_size = 128
        display_step = 1


        # Network Parameters
        # n_hidden_1 = 200 # 1st layer number of features
        # n_hidden_2 = 100 # 2nd layer number of features
        # n_hidden_3 = 50

        n_hidden_1 = 500 # 1st layer number of features
        n_hidden_2 = 250 # 2nd layer number of features
        n_hidden_3 = 50
        # n_hidden_4 = 50
        n_input = X_train.shape[1] # Number of features


        # tf Graph input
        x = tf.placeholder("float", [None, n_input])
        y = tf.placeholder("float", [None])

        # Store layers weight & bias
        weights = {
            'h1': tf.Variable(tf.random_normal([n_input, n_hidden_1])),
            'h2': tf.Variable(tf.random_normal([n_hidden_1, n_hidden_2])),
            'h3': tf.Variable(tf.random_normal([n_hidden_2, n_hidden_3])),
            # 'h4': tf.Variable(tf.random_normal([n_hidden_3, n_hidden_4])),    
            'out': tf.Variable(tf.random_normal([n_hidden_3, 1]))
        }

        biases = {
            'b1': tf.Variable(tf.random_normal([n_hidden_1])),
            'b2': tf.Variable(tf.random_normal([n_hidden_2])),
            'b3': tf.Variable(tf.random_normal([n_hidden_3])),
            # 'b4': tf.Variable(tf.random_normal([n_hidden_4])),        
            'out': tf.Variable(tf.random_normal([1]))
        }

        # Construct model
        net = multilayer_perceptron(x, weights, biases)

        pred = tf.squeeze(net, axis=1)

        # Define loss and optimizer
        cost = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=pred, labels=y))

        if FLAGS.optimizer == "Adam":
            optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)
        elif FLAGS.optimizer == "Nadam":
            optimizer = tf.contrib.opt.NadamOptimizer(learning_rate=learning_rate).minimize(cost)
        elif FLAGS.optimizer == "RMSProp":
            optimizer = tf.train.RMSPropOptimizer(learning_rate=learning_rate).minimize(cost)

        # optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)

        # Initializing the variables
        init = tf.global_variables_initializer()


        # Launch the graph
        with tf.Session() as sess:
            sess.run(init)
            # Training cycle
            for epoch in range(training_epochs):
                avg_cost = 0.
                total_batch = int(X_train.shape[0]/batch_size)
                X_batches = np.array_split(X_train, total_batch)
                Y_batches = np.array_split(Y_train, total_batch)

                # Loop over all batches
                for i in range(total_batch):
                    # print(Y_batches[i])            
                    batch_x, batch_y = X_batches[i], Y_batches[i]
                    # Run optimization op (backprop) and cost op (to get loss value)
                    _, c = sess.run([optimizer, cost], feed_dict={x: batch_x,
                                                                  y: batch_y})
                    # Compute average loss
                    avg_cost += c / total_batch
                # Display logs per epoch step
                if epoch % display_step == 0:
                    print("Epoch:", '%04d' % (epoch+1), "cost=", "{:.9f}".format(avg_cost))
            print("Optimization Finished!")

            global predictions
            predictions = tf.round(tf.nn.sigmoid(pred)).eval({x: X_test, y: Y_test})


        micro_f1 = precision_recall_fscore_support(Y_test, predictions, average="micro")[2]
        macro_f1 = precision_recall_fscore_support(Y_test, predictions, average="macro")[2]
        different_seed_macro_f1s.append(macro_f1)
        different_seed_micro_f1s.append(micro_f1)    
        different_seed_predictions.append(predictions)
        print("Micro F1/Macro F1: %.2f/%.2f" % (micro_f1, macro_f1))
        print("Per class results:", precision_recall_fscore_support(Y_test, predictions))
        print("Link results:", precision_recall_fscore_support(Y_test, predictions, average="macro"))
        print("confusion matrix:")
        print(confusion_matrix(Y_test, predictions))

    print(different_seed_macro_f1s)
    print(len(different_seed_predictions))
    print(len(different_seed_predictions[0]))
    print(len(different_seed_predictions[1]))

    # save macro f1 scores
    with open("predictions/mlp/macro/%s_%s_macro_f1s_%s_seeds.txt" % (feature_set, FLAGS.optimizer, str(num_seeds)), "w") as outfile:
        for f1 in different_seed_macro_f1s:
            outfile.write("%s\n" % f1)

    # save micro f1 scores
    with open("predictions/mlp/micro/%s_%s_micro_f1s_%s_seeds.txt" % (feature_set, FLAGS.optimizer, str(num_seeds)), "w") as outfile:
        for f1 in different_seed_micro_f1s:
            outfile.write("%s\n" % f1)

    # save predictions
    for seed, prediction in enumerate(different_seed_predictions):
        with open("predictions/mlp/raw/seed_%s_%s_%s.txt" % (seed, feature_set, FLAGS.optimizer), "w") as outfile:
            for pred in prediction:
                outfile.write("%s\n" % pred)
