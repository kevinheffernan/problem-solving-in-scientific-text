import tensorflow as tf
# import argparse


flags = tf.app.flags


# command_line_options = argparse.ArgumentParser()
# command_line_options.add_argument("--num_topics", type=int)
# # command_line_options.add_argument("--annotator", type=str)
# # command_line_options.add_argument("--input_type", type=str)
# # command_line_options.add_argument("--is_custom", type=str)
# # command_line_options.add_argument("--training_mode", type=int)
# command_line_args = command_line_options.parse_args()
# print(command_line_args)
# print(command_line_args.num_topics)

# define main params via command line
# flags.DEFINE_string('annotator', command_line_args.annotator, 'annotator')
# flags.DEFINE_string('input_type', command_line_args.input_type, 'input type')
# flags.DEFINE_integer('is_custom', 1 if (command_line_args.is_custom=="True") else 0, 'is this NRTM_custom?')
flags.DEFINE_integer('hidden_dim', 30, 'dimension of embedding layer')
flags.DEFINE_integer('is_custom', 1, 'using NRTM custom?')
flags.DEFINE_string('input_type', 'tfidf_C0', 'using NRTM custom?')
flags.DEFINE_string('annotator', 'Kevin', 'using NRTM custom?')
# flags.DEFINE_integer('mode', command_line_args.training_mode, '1 for pretrain, 2 for training')  # run mode 1 first, and then mode 2

FLAGS = flags.FLAGS

print(FLAGS.hidden_dim)
print(FLAGS.annotator)                  
print(FLAGS.is_custom)
