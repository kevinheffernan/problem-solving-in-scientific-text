import tensorflow as tf
import numpy as np
import utils
import os
import logging
import models
import vae


# utils.set_best_gpu()

flags = tf.app.flags

# model training settings
flags.DEFINE_integer('batch_size', 128, 'training batch size')
flags.DEFINE_float('init_lr_pretrain', 0.01, 'initial learning rate for pre-train')
flags.DEFINE_float('init_lr_train', 0.001, 'initial learning rate for training')
flags.DEFINE_float('lr_decay', 0.1, 'learning rate decay rate')
flags.DEFINE_float('lambda_w', 1e-4, 'lambda for the regularizer of W')
flags.DEFINE_string('noise', 'None', "[None, 'gaussian', 'mask']")
flags.DEFINE_integer('hidden_dim', 40, 'dimension of embedding layer')
flags.DEFINE_integer('top_k', 10, 'top k words')
flags.DEFINE_string('pretrain_layers_list', '[500, 200, 100]', 'pretrain layers of model')  # will also be used in training
# flags.DEFINE_string('pretrain_layers_list', '[200, 100]', 'pretrain layers of model')  # will also be used in training
flags.DEFINE_string('activations', "['sigmoid', 'sigmoid', 'sigmoid', 'sigmoid']", 'activations for different layers')
# flags.DEFINE_string('cf_layers_list', '[50, 25, 8, 1]', 'layers of model')
flags.DEFINE_string('cf_layers_list', '[1000, 250, 50, 8, 1]', 'layers of model')
# flags.DEFINE_string('cf_layers_list', '[500, 250, 50, 8, 1]', 'layers of model')

flags.DEFINE_string('loss', 'cross-entropy', "loss type, could be cross-entropy or rmse")

flags.DEFINE_integer('train_max_epoch', 50, 'max epoch for training')
flags.DEFINE_integer('pretrain_max_epoch', 50, 'max epoch for pretrain')
flags.DEFINE_integer('test_step', 2, 'step for testing')
flags.DEFINE_integer('pretrain_print_step', 1, 'print step for pretrain')
flags.DEFINE_integer('trained_print_step', 1, 'print step for training')
flags.DEFINE_integer('print_words_step', 1, 'step for printing words')

# flags.DEFINE_integer('negative_num', 5, 'negative samples for each positive citation')

__CONTEXT__ = 'NO'
 
# path settings
flags.DEFINE_string('dataset', 'NO_context', 'dataset')
flags.DEFINE_string('data_dir', 'data/NO_context/', 'directory of data')
flags.DEFINE_string('pretrain_dir', 'saver/pretrain_a/', 'directory for storing pre-training files')
flags.DEFINE_string('trained_dir', 'saver/trained_a/', 'directory for storing training files')
flags.DEFINE_integer('mode', 2, '1 for pretrain, 2 for training')  # run mode 1 first, and then mode 2

FLAGS = flags.FLAGS

if not os.path.exists(FLAGS.pretrain_dir):
    os.makedirs(FLAGS.pretrain_dir)
if not os.path.exists(FLAGS.trained_dir):
    os.makedirs(FLAGS.trained_dir)

if FLAGS.mode == 1:
    utils.init_logging(FLAGS.pretrain_dir + 'pretrain.log')
else:
    utils.init_logging(FLAGS.trained_dir + 'trained.log')

# logging.info('Loading data...')
# data = utils.load_custom_data(FLAGS.data_dir, __CONTEXT__)
# logging.info('Finished loading data')


if FLAGS.mode == 1:
    data = {}
    docs = np.loadtxt('/home/kevin/[Master]_dataset/code/feature_files/binary_EXTRACT.matrix')
    vocab = utils.load_vocab("/home/kevin/[Master]_dataset/code/feature_files/vocab_binary_EXTRACT.txt")

    data['doc_contents'] = docs
    data['vocab'] = vocab
else:
    logging.info('Loading data...')
    data = utils.load_custom_data(FLAGS.data_dir, __CONTEXT__)
    logging.info('Finished loading data')



def main(_):
    print("printing flag values")
    print(FLAGS.__flags.keys())
    print(FLAGS.__flags.values())
    utils.print_settings(FLAGS)

    logging.info('#' * 60)
    logging.info('Current mode is {0}'.format(FLAGS.mode))
    logging.info('#' * 60 + '\n')

    if FLAGS.mode == 1:
        vae_net = vae.VariationalAutoEncoder(FLAGS, data['doc_contents'], data['vocab'])
        vae_net.pretrain()
    elif FLAGS.mode == 2:
        nrtm = models.NRTM(FLAGS, data['doc_contents'], data['train_links'], data['train_labels'],
                           data['test_links'], data['test_labels'], data['train_sent_no'],
                           data['test_sent_no'], data['vocab'])
        nrtm.load_model(FLAGS.pretrain_dir)
        nrtm.train()


if __name__ == '__main__':
    tf.app.run()
