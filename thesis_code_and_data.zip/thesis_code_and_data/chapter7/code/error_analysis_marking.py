import json, os, pickle

experiment_type = 'joint'

print(f"\nExperiment type: {experiment_type}")

# bilstm_runs = []
# for filename in os.listdir(f"/home/kevin/emnlp2017-bilstm-cnn-crf/predictions/{experiment_type}"):
#     bilstm_runs.append(pickle.load(open(f"/home/kevin/emnlp2017-bilstm-cnn-crf/predictions/{experiment_type}/" + filename, 'rb')))

biaffine_runs = []
import pickle
for filename in os.listdir(f"/home/kevin/biaffine-ner-tuning/predictions/{experiment_type}"):
    biaffine_runs.append(pickle.load(open(f"/home/kevin/biaffine-ner-tuning/predictions/{experiment_type}/" + filename, 'rb')))

print(biaffine_runs[0])
# get gold ners
with open("../test/test_docs_%s.jsonlines" % experiment_type, "r") as infile:
    json_lines_test = [json.loads(line) for line in infile.readlines()]
gold_ners = [[tuple(ner) for ner in ners] for extract in json_lines_test for ners in extract["ners"]]

# print(len(gold_ners))
# print(gold_ners[4])
# print(len([e for s in gold_ners for e in s if 'SIGNAL' in e[2]]))

# print(len(biaffine_runs))
# print(biaffine_runs[0])
# print(bilstm_runs[0])

# def load_data(infile, experiment_type, bilstm=False, hmm=False):
#     if bilstm:
#         pred_ners = convert_to_entity_based(load_bilstm_data(seed_run))
#     elif hmm:
#         pred_ners= pickle.load(open('predictions/hmm_predictions_%s.pickle' % experiment_type, 'rb'))
#     else:
#         pred_ners = pickle.load(open(infile, 'rb'))
    
#     if experiment_type == "solution" and not hmm:
#         if bilstm:
#             pred_ners = pred_ners[5::6]
#         else:
#             pred_ners = pred_ners[0::6]

#     # get gold ners
#     with open("../test/test_docs_%s.jsonlines" % experiment_type, "r") as infile:
#         json_lines_test = [json.loads(line) for line in infile.readlines()]
#     gold_ners = [[tuple(ner) for ner in ners] for extract in json_lines_test for ners in extract["ners"]
