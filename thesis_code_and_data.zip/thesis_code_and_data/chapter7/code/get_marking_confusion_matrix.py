# baseline for element marking using HMM + Viterbi

import nltk, json, pickle
from nltk.tag import hmm

import numpy as np
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix

np.random.seed(0)

# need to generate 5 different baselines

# convert to s,e,entity type
def convert_element_info(statement):
    conversion = []
    conversion.append((statement.signal["start"], statement.signal["end"], "SIGNAL"))
    if getattr(statement, "root"):
        conversion.append((statement.root["start"], statement.root["end"], "ROOT-"+statement.root["direction"].upper()))
    if getattr(statement, "head"):
        conversion.append((statement.head["start"], statement.head["end"], "COMPLEMENT-"+statement.head["direction"].upper()))
    if getattr(statement, "condition"):
        conversion.append((statement.condition["start"], statement.condition["end"], "CONDITION-"+statement.condition["direction"].upper()))
    return str(sorted(conversion))


def search_right_of_signal(end, ners):
    elements = []
    for j in range(end+1, len(ners)):
        if ners[j][2] in ["SIGNAL", "SOLUTION"]:
            break
        elif ners[j][2].split("-")[1] == "LEFT":
            elements.append(ners[j])
    return elements


def search_left_of_signal(start, ners):
    elements = []
    for j in range(start-1, -1, -1):
        # stop search if another signal is reached
        if ners[j][2] in ["SIGNAL", "SOLUTION"]:
            break
        elif ners[j][2].split("-")[1] == "RIGHT":
            elements.append(ners[j])
    return elements


def group_into_problem_statements(ners):
    # sort ners by starts (first element is start)
    # print("NERS:", ners)
    ners = sorted(ners)
    problem_statements = []
    for index, ner in enumerate(ners):
        if ner[2] == "SIGNAL":
            problem_statement = [ner]
            right_elements = search_right_of_signal(index, ners)            
            left_elements = search_left_of_signal(index, ners)

            if len(left_elements) > 0:
                problem_statement += left_elements
            if len(right_elements) > 0:
                problem_statement += right_elements
            problem_statements.append(str(sorted(problem_statement)))
    return problem_statements


def load_bilstm_data(prediction_file):
    sentences, sentence = [], []
    with open(prediction_file, "r") as infile:
        for line in infile:
            if line.strip() == "":
                sentences.append(sentence)
                sentence = []
            else:
                sentence.append(line.strip().split())
    return sentences


# given starting tag e.g. B-S
def get_current_element(start_tag):
    if start_tag.split("-")[1] == "E+":
        current_element ="SOLUTION"
    elif start_tag.split("-")[1] == "S":
        current_element ="SIGNAL"
    elif start_tag.split("-")[1] == "RR":
        current_element ="ROOT-RIGHT"
    elif start_tag.split("-")[1] == "RL":
        current_element ="ROOT-LEFT"
    elif start_tag.split("-")[1] == "R":
        current_element ="ROOT"                
    elif start_tag.split("-")[1] == "HL":
        current_element ="COMPLEMENT-LEFT"
    elif start_tag.split("-")[1] == "HR":
        current_element ="COMPLEMENT-RIGHT"
    elif start_tag.split("-")[1] == "H":
        current_element ="COMPLEMENT"                       
    elif start_tag.split("-")[1] == "CL":
        current_element ="CONDITION-LEFT"
    elif start_tag.split("-")[1] == "CR":
        current_element ="CONDITION-RIGHT"
    elif start_tag.split("-")[1] == "C":
        current_element ="CONDITION"        
    return current_element


def convert_to_entity_based(test_predictions):
    # now generate entity-based stats using extract.sentence_no, start, end, entity
    hmm_pred_ners = []
    for sentence in test_predictions:
        ners = []
        start = None
        current_element = None
        for token_no, element in enumerate(sentence):
            token, tag = element[0], element[1]
            if (tag == "O") or (token_no == len(sentence)-1):
                # there was an element before
                if start != None:
                    ners.append((start, token_no-1, current_element))
                    # reset start
                    start = None
                # if we're at the end of sentence and not inside element
                elif tag != "O":
                    current_element = get_current_element(tag)
                    ners.append((token_no, token_no, current_element))
            # beginning of new element
            elif tag.split("-")[0] == "B":
                # if there was element before
                if start != None:
                    ners.append((start, token_no-1, current_element))
                # get new starts and current_element
                current_element = get_current_element(tag)
                start = token_no
        hmm_pred_ners.append(ners)
    return hmm_pred_ners



# data_A = baseline, data_B
def rand_permutation(baseline, prediction, n, R, answer, num_types, typ):
    # print("N", n)
    delta_orig = get_fscore_diff(baseline, prediction, answer, num_types, typ)
    print("delta orig", delta_orig)
    r = 0
    for x in range(0, R):
        temp_A = [e for e in baseline]
        temp_B = [e for e in prediction]
        samples = [np.random.randint(1, 3) for i in range(n)] 
        swap_ind = [i for i, val in enumerate(samples) if val == 1]
        for ind in swap_ind:
            temp_B[ind], temp_A[ind] = temp_A[ind], temp_B[ind]
        delta = get_fscore_diff(temp_A, temp_B, answer, num_types, typ)
        # if result is more extreme
        if(delta>=delta_orig):
            r = r+1
    # print("r:", r)
    pval = float(r+1.0)/(R+1.0)
    # return two-tailed test
    return pval * 2.0


def get_f1_measures(gold_ners, pred_ners, num_types):
    # # unpack extract groups into sentences
    # gold_ners = [s for e in gold_ners for s in e]
    # pred_ners = [s for e in pred_ners for s in e]
    # 1 -> 600
    tp, fn, fp = 0,0,0
    sub_tp, sub_fn, sub_fp = {},{},{}

    for sent in range(len(gold_ners)):
        tp += len(set(gold_ners[sent]) & set(pred_ners[sent]))
        fn += len(set(gold_ners[sent]) - set(pred_ners[sent]))
        fp += len(set(pred_ners[sent]) - set(gold_ners[sent]))

        for i in num_types:
            sub_gm = set((s,e,t) for s,e,t in gold_ners[sent] if t == i)
            sub_pm = set((s,e,t) for s,e,t in pred_ners[sent] if t == i)

            if i not in sub_tp: sub_tp[i] = 0
            if i not in sub_fn: sub_fn[i] = 0
            if i not in sub_fp: sub_fp[i] = 0

            sub_tp[i] += len(sub_gm & sub_pm)
            sub_fn[i] += len(sub_gm - sub_pm)
            sub_fp[i] += len(sub_pm - sub_gm)

    m_r = 0 if tp == 0 else float(tp)/(tp+fn)
    m_p = 0 if tp == 0 else float(tp)/(tp+fp)
    m_f1 = 0 if m_p == 0 else 2.0*m_r*m_p/(m_r+m_p)

    # print("overall mention: %.2f/%.2f/%.2f" % (m_p,m_r,m_f1))
    # print("Mention F1: {:.2f}%".format(m_f1*100))
    # print("Mention recall: {:.2f}%".format(m_r*100))
    # print("Mention precision: {:.2f}%".format(m_p*100))

    precisions, recalls, f1s = [], [], []

    print("****************SUB NER TYPES********************")
    for i in num_types:
        sub_r = 0 if sub_tp[i] == 0 else float(sub_tp[i]) / (sub_tp[i] + sub_fn[i])
        sub_p = 0 if sub_tp[i] == 0 else float(sub_tp[i]) / (sub_tp[i] + sub_fp[i])
        precisions.append(sub_p)
        recalls.append(sub_r)
        sub_f1 = 0 if sub_p == 0 else 2.0 * sub_r * sub_p / (sub_r + sub_p)
        f1s.append(sub_f1)
        # print(i)
        print(i, "%.2f/%.2f/%.2f" % (sub_p, sub_r, sub_f1))
        # print("{} F1: {:.2f}%".format(i,sub_f1 * 100))
        # print("{} recall: {:.2f}%".format(i,sub_r * 100))
        # print("{} precision: {:.2f}%".format(i,sub_p * 100))

    macro_p = sum(precisions)/len(precisions)
    macro_r = sum(recalls)/len(recalls)
    macro_f1 = sum(f1s)/len(f1s)
    print("MICRO MENTION: %.2f/%.2f/%.2f" % (m_p,m_r,m_f1))
    print("MACRO MENTION: %.2f/%.2f/%.2f" % (macro_p, macro_r, macro_f1))
    # return micro f1, macro f1 and individual f1s
    return m_f1, macro_f1, f1s

# per sentence ners
def add_outside_ners(ners, sent_length):
    # check for null ners
    if len(ners) == 0: return [(0, sent_length-1, "O")]
    # sort ners
    ners = sorted(ners)
    outside_ners = []
    # add start
    if ners[0][0] > 0:
        outside_ners.append((0, ners[0][0]-1, "O"))
    # add ending
    if ners[-1][1] < sent_length-1:
        outside_ners.append((ners[-1][1]+1, sent_length-1, "O"))
    # add in between
    prev_ner = None
    for ner in ners:
        if prev_ner:
            # if start - end of previous is greater than one
            if ner[0] - prev_ner[1] > 1:
                outside_ners.append((prev_ner[1]+1, ner[0]-1, "O"))
        prev_ner = ner
    # resort
    return sorted(ners + outside_ners)


# sentence-based
def convert_ner_to_bio(ners):
    bio_ners = []
    for ner in ners:
        if ner[2] == "O":
            for i in range(ner[0], ner[1]+1):
                bio_ners.append("O")
        else:
            bio_ners.append("B-" + ner[2])
            for i in range(ner[0]+1, ner[1]+1):
                bio_ners.append("I-" + ner[2])
    return bio_ners


experiment_type = "joint"

# get predictions output from the BiLSTM+CRF model
bilstm_pred_ners = convert_to_entity_based(load_bilstm_data("predictions/bilstm_%s_predictions.txt" % experiment_type))
with open('predictions/hmm_predictions_%s.pickle' % experiment_type, 'rb') as f:
     hmm_pred_ners = pickle.load(f)
with open('predictions/biaffine_predictions_%s.pickle' % experiment_type, 'rb') as f:
     biaffine_pred_ners = pickle.load(f)
     if experiment_type == "solution":
         biaffine_pred_ners = biaffine_pred_ners[0::6]


# get gold ners
with open("../test/test_docs_%s.jsonlines" % experiment_type, "r") as infile:
    json_lines_test = [json.loads(line) for line in infile.readlines()]
gold_ners = [[tuple(ner) for ner in ners] for extract in json_lines_test for ners in extract["ners"]]
gold_ner_sent_lengths = [len(sent) for extract in json_lines_test for sent in extract["sentences"]]

print(len(gold_ners), len(bilstm_pred_ners), len(biaffine_pred_ners), len(hmm_pred_ners))
print(sorted(gold_ners[4]), type(gold_ners), type(gold_ners[0]))
gold_ners_with_outside = [add_outside_ners(gold_ners[i], gold_ner_sent_lengths[i]) for i in range(len(gold_ners))]
biaffine_ners_with_outside = [add_outside_ners(biaffine_pred_ners[i], gold_ner_sent_lengths[i]) for i in range(len(gold_ners))]
print(gold_ners_with_outside[4])
print(gold_ners_with_outside[5])
print(gold_ners_with_outside[6])
print(gold_ners_with_outside[7])

# only take the labels now
gold_confusion_labels = [ner[2] for ners in gold_ners_with_outside for ner in ners]
biaffine_confusion_labels = [ner[2] for ners in biaffine_ners_with_outside for ner in ners]
print(len(gold_confusion_labels))
print(len(biaffine_confusion_labels))
bio_gold = [convert_ner_to_bio(ners) for ners in gold_ners_with_outside]
bio_biaffine = [convert_ner_to_bio(ners) for ners in biaffine_ners_with_outside]
bio_gold_tokens = [bio for sent in bio_gold for bio in sent]
bio_biaffine_tokens = [bio for sent in bio_biaffine for bio in sent]
# print(bio_gold_tokens[0:500])
# print(bio_biaffine_tokens[0:500])
# experiment_type_labels = ["B-SIGNAL", "I-SIGNAL", "B-ROOT-RIGHT", "I-ROOT-RIGHT", "B-ROOT-LEFT", "I-ROOT-LEFT", "B-COMPLEMENT-RIGHT", "I-COMPLEMENT-RIGHT", "B-COMPLEMENT-LEFT", "I-COMPLEMENT-LEFT", "B-CONDITION-RIGHT", "I-CONDITION-RIGHT", "B-CONDITION-LEFT", "I-CONDITION-LEFT", "B-SOLUTION", "I-SOLUTION", "O"]
experiment_type_labels = ["B-SIGNAL", "I-SIGNAL", "B-ROOT-RIGHT", "I-ROOT-RIGHT", "B-ROOT-LEFT", "I-ROOT-LEFT", "B-COMPLEMENT-RIGHT", "I-COMPLEMENT-RIGHT", "B-COMPLEMENT-LEFT", "I-COMPLEMENT-LEFT", "B-CONDITION-RIGHT", "I-CONDITION-RIGHT", "B-CONDITION-LEFT", "I-CONDITION-LEFT", "B-SOLUTION", "I-SOLUTION", "O"]

cm = confusion_matrix(bio_gold_tokens, bio_biaffine_tokens, labels=experiment_type_labels)
# remove "O" last row
cm = cm[:-1]
print(cm)

import seaborn as sns
import matplotlib.pyplot as plt     

fig, ax = plt.subplots(figsize=(9,6))
sns.heatmap(cm, annot=True, ax = ax, cmap='Blues', fmt='d'); #annot=True to annotate cells

# labels, title and ticks
ax.set_xlabel('Predicted labels', fontsize="12", labelpad=15);ax.set_ylabel('True labels', fontsize="12", labelpad=15);
# ax.tick_params(axis='both', which='minor', pad=20)
# ax.set_title('Confusion Matrix'); 
ax.xaxis.set_ticklabels(["B-S", "I-S", "B-RR", "I-RR", "B-RL", "I-RL", "B-HR", "I-HR", "B-HL", "I-HL", "B-CR", "I-CR", "B-CL", "I-CL", "B-E+", "I-E+", "O"], fontsize="12"); ax.yaxis.set_ticklabels(["B-S", "I-S", "B-RR", "I-RR", "B-RL", "I-RL", "B-HR", "I-HR", "B-HL", "I-HL", "B-CR", "I-CR", "B-CL", "I-CL", "B-E+", "I-E+"], fontsize="12");

plt.yticks(rotation=0)
plt.xticks(rotation=40)
plt.tight_layout()
# plt.gcf().subplots_adjust(bottom=0.15)
plt.savefig("joint_confusion_matrix.png")


if experiment_type == "joint":
    num_types = ["SIGNAL", "ROOT-RIGHT", "ROOT-LEFT", "COMPLEMENT-LEFT", "COMPLEMENT-RIGHT", "CONDITION-LEFT", "CONDITION-RIGHT", "SOLUTION"]
elif experiment_type == "problem":
    num_types = ["SIGNAL", "ROOT-RIGHT", "ROOT-LEFT", "COMPLEMENT-LEFT", "COMPLEMENT-RIGHT", "CONDITION-LEFT", "CONDITION-RIGHT"]
elif experiment_type == "problem_no_direction":
    num_types = ["SIGNAL", "ROOT", "COMPLEMENT", "CONDITION"]
elif experiment_type == "joint_no_direction":
    num_types = ["SIGNAL", "ROOT", "COMPLEMENT", "CONDITION", "SOLUTION"]    
else:
    num_types = ["SOLUTION"]


def get_fscore_diff(baseline_ners, pred_ners, gold_ners, num_types, typ):
    b_micro_f1, b_macro_f1, b_element_f1s = get_f1_measures(gold_ners, baseline_ners, num_types)
    p_micro_f1, p_macro_f1, p_element_f1s = get_f1_measures(gold_ners, pred_ners, num_types)    
    if typ == 'micro': return float(abs(p_micro_f1 - b_micro_f1))
    elif typ == 'macro': return float(abs(p_macro_f1 - b_macro_f1))
    else:
        return float(abs(p_element_f1s[num_types.index(typ)] - b_element_f1s[num_types.index(typ)]))



