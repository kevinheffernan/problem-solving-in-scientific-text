import json

with open("../test/test_docs_solution.jsonlines", "r") as infile:
    json_lines = [json.loads(line) for line in infile.readlines()]
    test_ners = [ner for extract in json_lines for ners in extract["ners"] for ner in ners if len(ners)>0]

with open("../dev/dev_docs_solution.jsonlines", "r") as infile:
    json_lines = [json.loads(line) for line in infile.readlines()]
    dev_ners = [ner for extract in json_lines for ners in extract["ners"] for ner in ners if len(ners)>0]

with open("../train/training_docs_solution.jsonlines", "r") as infile:
    json_lines = [json.loads(line) for line in infile.readlines()]
    train_ners = [ner for extract in json_lines for ners in extract["ners"] for ner in ners if len(ners)>0]        


for split in [train_ners, dev_ners, test_ners]:
    elements = {'signal':[], 'condition':[], 'complement':[], 'root':[], 'solution':[]}
    for start, end, element in split:
        elements[element.lower().split('-')[0]].append(end-start+1)
    for element in elements:
        print(element, len(elements[element]),  sum(elements[element]))
    print()

