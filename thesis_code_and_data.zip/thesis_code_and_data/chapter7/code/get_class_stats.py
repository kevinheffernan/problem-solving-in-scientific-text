# get precision recall f-measure from predictions and whether it is statistically significant or not

import sys
import numpy as np
from scipy import stats
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix

np.random.seed(0)


def get_fscore_diff(baseline, prediction, answer, typ):
    # negative class
    if typ == 'negative':
        baseline_fmeasure = precision_recall_fscore_support(answer, baseline)[2][0]
        prediction_fmeasure = precision_recall_fscore_support(answer, prediction)[2][0]
    else:
        baseline_fmeasure = precision_recall_fscore_support(answer, baseline, average=typ)[2]
        prediction_fmeasure = precision_recall_fscore_support(answer, prediction, average=typ)[2]
    return float(abs(prediction_fmeasure - baseline_fmeasure))


# data_A = baseline, data_B
def rand_permutation(baseline, prediction, n, R, answer, typ):
    delta_orig = get_fscore_diff(baseline, prediction, answer, typ)
    print("delta orig", delta_orig)
    r = 0
    for x in range(0, R):
        temp_A = [e for e in baseline]
        temp_B = [e for e in prediction]
        samples = [np.random.randint(1, 3) for i in xrange(n)] 
        swap_ind = [i for i, val in enumerate(samples) if val == 1]
        for ind in swap_ind:
            temp_B[ind], temp_A[ind] = temp_A[ind], temp_B[ind]
        delta = get_fscore_diff(temp_A, temp_B, answer, typ)
        # if result is more extreme
        if(delta>=delta_orig):
            r = r+1
    pval = float(r+1.0)/(R+1.0)
    # return two-tailed test
    return pval * 2.0


feature_set = sys.argv[1]
feature_set_data = [float(line.strip()) for line in open(feature_set, "r")]

answer = [float(line.strip().split()[1]) for line in open("test_link_data.txt", "r")]

# temporary baseline
# baseline = [float(line.strip()) for line in open(sys.argv[1], "r")]
# baseline = [float(line.strip()) for line in open("predictions/SBERT_C5_MLP.txt", "r")]
# baseline = [float(line.strip()) for line in open("predictions/SBERT_C5_NB.pred_extracted", "r")]
baseline = [float(line.strip()) for line in open("nrtm_baseline_predictions.txt", "r")]

# all ones
most_frequent_baseline = [1 for e in range(len(baseline))]

y_actual = [int(line.strip().split()[1]) for line in open("test_link_data.txt", "r")]

mf_baseline_stats = precision_recall_fscore_support(y_actual, most_frequent_baseline)
print("most frequent baseline neg: %.2f/%.2f/%.2f" % (mf_baseline_stats[0][0], mf_baseline_stats[1][0], mf_baseline_stats[2][0]))
print("most frequent baseline pos: %.2f/%.2f/%.2f" % (mf_baseline_stats[0][1], mf_baseline_stats[1][1], mf_baseline_stats[2][1]))

baseline_stats = precision_recall_fscore_support(y_actual, baseline)
print("normal baseline neg: %.2f/%.2f/%.2f" % (baseline_stats[0][0], baseline_stats[1][0], baseline_stats[2][0]))
print("normal baseline pos: %.2f/%.2f/%.2f" % (baseline_stats[0][1], baseline_stats[1][1], baseline_stats[2][1]))

baseline_macros = precision_recall_fscore_support(y_actual, baseline, average='macro')
print("normal baseline macros: %.2f/%.2f/%.2f" % (baseline_macros[0], baseline_macros[1], baseline_macros[2]))

mf_baseline_macros = precision_recall_fscore_support(y_actual, most_frequent_baseline, average='macro')
print("most frequent baseline macros: %.2f/%.2f/%.2f" % (mf_baseline_macros[0], mf_baseline_macros[1], mf_baseline_macros[2]))

per_class = precision_recall_fscore_support(y_actual, feature_set_data)
macros = precision_recall_fscore_support(y_actual, feature_set_data, average='macro')

print "LINK: " + "%.2f/%.2f/%.2f" % (per_class[0][1], per_class[1][1], per_class[2][1])
print "NO LINK: " + "%.2f/%.2f/%.2f" % (per_class[0][0], per_class[1][0], per_class[2][0])
print "MACRO: " + "%.2f/%.2f/%.2f" % (macros[0], macros[1], macros[2])

R = 10000

print("\n######### POSITIVE CLASS ##########") 
pval = rand_permutation(baseline, feature_set_data, len(baseline), R, answer, 'binary')
print("Alpha = 0.05; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.05) else "n't", pval))
print("Alpha = 0.01; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.01) else "n't", pval))
print("Alpha = 0.001; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.001) else "n't", pval))


print("\n######### NEGATIVE CLASS ##########") 
pval = rand_permutation(baseline, feature_set_data, len(baseline), R, answer, 'negative')
print("Alpha = 0.05; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.05) else "n't", pval))
print("Alpha = 0.01; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.01) else "n't", pval))
print("Alpha = 0.001; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.001) else "n't", pval))


print("\n######### MACROS CLASS ##########") 
pval = rand_permutation(baseline, feature_set_data, len(baseline), R, answer, 'macro')
print("Alpha = 0.05; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.05) else "n't", pval))
print("Alpha = 0.01; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.01) else "n't", pval))
print("Alpha = 0.001; Test result is%s significant with p-value: %s" % ("" if float(pval) <= float(0.001) else "n't", pval))


print("\n######### CONFUSION MATRIX #########")
print(confusion_matrix(answer, feature_set_data))
