#!/bin/bash

problem_pattern="(problem|issue|challenge|difficult|limitation|mistake|drawback|disadvantage|weakness|shortcoming)"
before_pattern="(is a[n]*)"
after_pattern="(of|is|are)"


find ~/SciXML-ARC_MASTER/SciXML -name *.scixml | xargs grep -E -e "$before_pattern $problem_pattern" -e "$problem_pattern $after_pattern" | grep -o ".*.scixml" | uniq -c | sort -nr | wc -l

