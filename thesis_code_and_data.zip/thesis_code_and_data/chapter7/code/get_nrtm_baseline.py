# get baseline for nrtm

# get initial proportions of links
sentences = {1:[], 2:[], 3:[], 4:[], 5:[], 6:[]}
# percentage of those sentences with a link
sentence_percentage = {}
with open("/home/kevin/Neural-Relational-Topic-Models/data/no_context/train_link_data.txt", "r") as infile:
    for line in infile:
        links, label, sentence = line.strip().split()
        sentences[int(sentence)].append(int(label))

for sentence in sentences:
    sentence_percentage[sentence] = sentences[sentence].count(1)/len(sentences[sentence])

# get test data
test_sentences = {1:[], 2:[], 3:[], 4:[], 5:[], 6:[]}
statement_number = 0
# give key as statement number and get back sentence_number and index
statement_indices = {}
y_actual = []

with open("/home/kevin/Neural-Relational-Topic-Models/data/no_context/test_link_data.txt", "r") as infile:
    for line in infile:
        links, label, sentence = line.strip().split()
        # make all sentences unlinked for now
        test_sentences[int(sentence)].append(0)
        # get actual labels
        y_actual.append(int(label))
        statement_indices[sentence + "," + str(len(test_sentences[int(sentence)])-1)] = statement_number
        statement_number += 1

import random
random.seed(100)

for sentence in test_sentences:
    # get indices of elements to mark as links    
    inds = random.sample(range(len(test_sentences[sentence])), int(sentence_percentage[sentence]*len(test_sentences[sentence])))
    for ind in inds:
        # assign link
        test_sentences[sentence][ind] = 1
    print(sentence, len(test_sentences[sentence]), test_sentences[sentence].count(1), int(sentence_percentage[sentence]*len(test_sentences[sentence])))
    print(test_sentences[sentence])

# print(statement_indices)
    
# get predicted links
y_pred = [0 for i in range(len(y_actual))]
for sentence in test_sentences:
    for ind in range(len(test_sentences[sentence])):
        statement_number = statement_indices[str(sentence) + "," + str(ind)]
        y_pred[statement_number] = test_sentences[sentence][ind]

print(y_pred)
from sklearn.metrics import precision_recall_fscore_support

# y_pred = [int(line.strip()) for line in open("SBERT_no_context_LR.pred_extracted", "r")]

print(precision_recall_fscore_support(y_actual, y_pred))
print(precision_recall_fscore_support(y_actual, y_pred, average='micro')[2])
print(precision_recall_fscore_support(y_actual, y_pred, average='macro')[2])

with open("nrtm_baseline_predictions.txt", "w") as outfile:
    for prediction in y_pred:
        outfile.write("%s\n" % prediction)

