# baseline for element marking using HMM + Viterbi

import nltk, json, pickle
import numpy as np
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix

# cm = np.array([[70,47],[62,134]])
cm = np.array([[78,39],[71,125]])
print(cm)

import seaborn as sns
import matplotlib.pyplot as plt     

fig, ax = plt.subplots()
sns.heatmap(cm, annot=True, ax = ax, cmap='Blues', fmt='d', annot_kws={"size": 18}); #annot=True to annotate cells
cax = plt.gcf().axes[-1]
cax.tick_params(labelsize=16)
# labels, title and ticks
ax.set_xlabel('Predicted labels', fontsize="16", labelpad=15);ax.set_ylabel('True labels', fontsize="16", labelpad=15);
# ax.tick_params(axis='both', which='minor', pad=20)
# ax.set_title('Confusion Matrix'); 
ax.xaxis.set_ticklabels(["Not linked", "Linked"], fontsize="16"); ax.yaxis.set_ticklabels(["Not Linked","Linked"], fontsize="16");

# plt.yticks(rotation=0)
# plt.xticks(rotation=40)
plt.tight_layout()
# plt.gcf().subplots_adjust(bottom=0.15)
plt.savefig("linking_confusion_matrix_tfidf.png")


