from sklearn.metrics import precision_recall_fscore_support, confusion_matrix
from collections import defaultdict

actual_link_info = [line.strip().split(",") for line in open("test_link_info.txt", "r")]

for classifier in ["NRTM", "NRTM (custom)"]:
    print()
    print(classifier)
    print()
    if classifier == "NRTM (custom)":
        pred_link_info = [line.strip() for line in open("predictions/NRTM_custom_predictions_binary_C0_TEST_Kevin_30_topics_normed_notsbert.txt", "r")]
    elif classifier == "NB":
        pred_link_info = [line.strip() for line in open("predictions/binary_C0__positional_embeddings_NB_TEST.pred_extracted", "r")]
    elif classifier == "NRTM":
        pred_link_info = [line.strip() for line in open("predictions/NRTM_predictions_binary_C0_TEST_Kevin_30_topics_normed_notsbert.txt", "r")]

    sentence_problems = defaultdict(lambda : defaultdict(dict))

    for index, e in enumerate(actual_link_info):
        if e[3] not in sentence_problems:
            sentence_problems[e[3]]['total'] = 0
            sentence_problems[e[3]]["link"] = 0
            sentence_problems[e[3]]["no_link"] = 0
            sentence_problems[e[3]]["no_link_correct"] = 0
            sentence_problems[e[3]]["link_correct"] = 0 
        sentence_problems[e[3]]['total'] += 1
        sentence_problems[e[3]]['link'] += 1 if e[2]=='1' else 0
        sentence_problems[e[3]]['no_link'] += 1 if e[2]=='0' else 0
        sentence_problems[e[3]]['link_correct'] += 1 if (e[2]==pred_link_info[index] and e[2]=='1') else 0
        sentence_problems[e[3]]['no_link_correct'] += 1 if (e[2]==pred_link_info[index] and e[2]=='0') else 0    

    for i in range(1,7):    
        print(i,
              "total: %d"   % sentence_problems[str(i)]['total'],
              "link: %d"    % sentence_problems[str(i)]['link'],
              "no_link: %d" % sentence_problems[str(i)]['no_link'],
              "link_correct: %d" % sentence_problems[str(i)]['link_correct'],
              "(%.2f)" % (0 if sentence_problems[str(i)]['link_correct']==0 else (sentence_problems[str(i)]['link_correct']/sentence_problems[str(i)]['link'])),
              "no_link_correct: %d" % sentence_problems[str(i)]['no_link_correct'],
              "(%.2f)" % (0 if sentence_problems[str(i)]['no_link_correct']==0 else (sentence_problems[str(i)]['no_link_correct']/sentence_problems[str(i)]['no_link'])))


# look at nb vs NRTM-custom per context 

actual_link_info        = [line.strip().split(",") for line in open("test_link_info.txt", "r")]
nrtm_custom_link_info   = [line.strip() for line in open("predictions/NRTM_custom_predictions_binary_C0_TEST_Kevin_30_topics_normed_notsbert.txt", "r")]
nb_link_info            = [line.strip() for line in open("predictions/binary_C0__positional_embeddings_NB_TEST.pred_extracted", "r")]
# below is tmp. remove
nb_link_info            = [line.strip() for line in open("predictions/NRTM_predictions_binary_C0_TEST_Kevin_30_topics_normed_notsbert.txt", "r")]

# group statements by context
extract_link_info = {}
for index, e in enumerate(actual_link_info):
    extract_number = int(e[4])
    if extract_number not in extract_link_info:
        extract_link_info[extract_number] = []
    extract_link_info[extract_number].append(index)

nrtm_extract_link_info = {}
nb_extract_link_info = {}
actual_extract_link_info = {}
for extract_number in extract_link_info:
    extract_sent_ids = extract_link_info[extract_number]
    actual_extract_link_info[extract_number] = [int(actual_link_info[i][2]) for i in extract_sent_ids]
    # print(extract_sent_ids, actual_extract_link_info[extract_number])
    nrtm_extract_link_info[extract_number] = [int(nrtm_custom_link_info[i]) for i in extract_sent_ids]
    nb_extract_link_info[extract_number] = [int(nb_link_info[i]) for i in extract_sent_ids]

extract_macros_nb = []
extract_macros_nrtm = []
extract_fs_nrtm_positive = []
extract_fs_nrtm_negative = []
extract_fs_nb_positive = []
extract_fs_nb_negative = []
nb_checksum = []
nrtm_checksum = []
for extract_number in range(1, 101):
    pr, re, fs, _ = precision_recall_fscore_support(actual_extract_link_info[extract_number],
                                                    nrtm_extract_link_info[extract_number],
                                                    average='macro')
    extract_macros_nrtm.append(fs)

    pr, re, fs, _ = precision_recall_fscore_support(actual_extract_link_info[extract_number],
                                                    nrtm_extract_link_info[extract_number],
                                                    average='binary')
    extract_fs_nrtm_positive.append(fs)

    pr, re, fs, _ = precision_recall_fscore_support(actual_extract_link_info[extract_number],
                                                    nrtm_extract_link_info[extract_number])
    extract_fs_nrtm_negative.append(fs[0])    

    ########################################################################################
    
    pr, re, fs, _ = precision_recall_fscore_support(actual_extract_link_info[extract_number],
                                                    nb_extract_link_info[extract_number],
                                                    average='macro')
    extract_macros_nb.append(fs)

    pr, re, fs, _ = precision_recall_fscore_support(actual_extract_link_info[extract_number],
                                                    nb_extract_link_info[extract_number],
                                                    average='binary')
    extract_fs_nb_positive.append(fs)

    pr, re, fs, _ = precision_recall_fscore_support(actual_extract_link_info[extract_number],
                                                    nb_extract_link_info[extract_number])
    extract_fs_nb_negative.append(fs[0])

    nrtm_checksum += nrtm_extract_link_info[extract_number]
    nb_checksum += nb_extract_link_info[extract_number]

print("NRTM macro avg: %.2f" % (sum(extract_macros_nrtm)/100.0))
print("NB macro avg: %.2f" % (sum(extract_macros_nb)/100.0))

print("NRTM neg fs avg: %.2f" % (sum(extract_fs_nrtm_negative)/100.0))
print("NB neg fs avg: %.2f" % (sum(extract_fs_nb_negative)/100.0))

print("NRTM pos fs avg: %.2f" % (sum(extract_fs_nrtm_positive)/100.0))
print("NB pos fs avg: %.2f" % (sum(extract_fs_nb_positive)/100.0))

answer = [float(line.strip().split()[1]) for line in open("test_link_data.txt", "r")]
print(precision_recall_fscore_support(answer, nb_checksum, average='macro'))
print(precision_recall_fscore_support(answer, nrtm_checksum, average='macro'))

print(confusion_matrix(answer, nrtm_checksum))
