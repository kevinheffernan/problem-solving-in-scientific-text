# baseline for element marking using HMM + Viterbi

import nltk, json, pickle
from nltk.tag import hmm

# need to generate 5 different baselines

def load_bilstm_data(prediction_file):
    sentences, sentence = [], []
    with open(prediction_file, "r") as infile:
        for line in infile:
            if line.strip() == "":
                sentences.append(sentence)
                sentence = []
            else:
                sentence.append(line.strip().split())
    return sentences


def load_bio_data(bio_file, no_direction):
    previous_line = ""
    extra_line_occurred = False
    extracts, extract, sentence = [], [], []

    with open(bio_file, "r") as infile:
        for line in infile:
            # three empty lines
            if previous_line.strip() == "" and line.strip() == "" and extra_line_occurred:
                extracts.append(extract)
                # reset extract
                extract = []
            elif previous_line.strip() == "" and line.strip() == "" and not extra_line_occurred:
                extra_line_occurred = True
            elif line.strip() == "":
                extract.append(sentence)
                sentence = []
                extra_line_occurred = False
            else:
                token = line.split()[0]
                bio_tag = line.split()[1]
                if no_direction:
                    if bio_tag.endswith("L") or bio_tag.endswith("R"):
                        bio_tag = bio_tag[:-1]
                sentence.append((token, bio_tag))
            previous_line = line
    return extracts

experiment_type = "joint"

training_extracts = load_bio_data("../train/training_docs_joint.bio", no_direction=False)
dev_extracts = load_bio_data("../dev/dev_docs_joint.bio", no_direction=False)
test_extracts = load_bio_data("../test/test_docs_joint.bio", no_direction=False)

# training_extracts = load_bio_data("../train/training_docs_%s.bio" % experiment_type, no_direction=True)
# dev_extracts = load_bio_data("../dev/dev_docs_%s.bio" % experiment_type, no_direction=True)
# test_extracts = load_bio_data("../test/test_docs_%s.bio" % experiment_type, no_direction=True)

# print(len(training_extracts), len(dev_extracts), len(test_extracts))

training_data = [sentence for extract in training_extracts + dev_extracts for sentence in extract]
test_data = [sentence for extract in test_extracts for sentence in extract]

# print(len(training_data))
# print(len(test_data))

trainer = hmm.HiddenMarkovModelTrainer()
# train model
tagger = trainer.train_supervised(training_data)
print(tagger)
# get test predictions
test_predictions = [tagger.tag([t[0] for t in sentence]) for sentence in test_data]




# given starting tag e.g. B-S
def get_current_element(start_tag):
    if start_tag.split("-")[1] == "E+":
        current_element ="SOLUTION"
    elif start_tag.split("-")[1] == "S":
        current_element ="SIGNAL"
    elif start_tag.split("-")[1] == "RR":
        current_element ="ROOT-RIGHT"
    elif start_tag.split("-")[1] == "RL":
        current_element ="ROOT-LEFT"
    elif start_tag.split("-")[1] == "HL":
        current_element ="COMPLEMENT-LEFT"       
    elif start_tag.split("-")[1] == "HR":
        current_element ="COMPLEMENT-RIGHT"
    elif start_tag.split("-")[1] == "CL":
        current_element ="CONDITION-LEFT"
    elif start_tag.split("-")[1] == "CR":
        current_element ="CONDITION-RIGHT"
    return current_element


# convert to s,e,entity type
def convert_element_info(statement):
    conversion = []
    conversion.append((statement.signal["start"], statement.signal["end"], "SIGNAL"))
    if getattr(statement, "root"):
        conversion.append((statement.root["start"], statement.root["end"], "ROOT-"+statement.root["direction"].upper()))
    if getattr(statement, "head"):
        conversion.append((statement.head["start"], statement.head["end"], "COMPLEMENT-"+statement.head["direction"].upper()))
    if getattr(statement, "condition"):
        conversion.append((statement.condition["start"], statement.condition["end"], "CONDITION-"+statement.condition["direction"].upper()))
    return str(sorted(conversion))


def search_right_of_signal(end, ners):
    elements = []
    for j in range(end+1, len(ners)):
        if ners[j][2] in ["SIGNAL", "SOLUTION"]:
            break
        elif ners[j][2].split("-")[1] == "LEFT":
            elements.append(ners[j])
    return elements


def search_left_of_signal(start, ners):
    elements = []
    for j in range(start-1, -1, -1):
        # stop search if another signal is reached
        if ners[j][2] in ["SIGNAL", "SOLUTION"]:
            break
        elif ners[j][2].split("-")[1] == "RIGHT":
            elements.append(ners[j])
    return elements


def group_into_problem_statements(ners):
    # sort ners by starts (first element is start)
    # print("NERS:", ners)
    ners = sorted(ners)
    problem_statements = []
    for index, ner in enumerate(ners):
        if ner[2] == "SIGNAL":
            problem_statement = [ner]
            right_elements = search_right_of_signal(index, ners)            
            left_elements = search_left_of_signal(index, ners)

            if len(left_elements) > 0:
                problem_statement += left_elements
            if len(right_elements) > 0:
                problem_statement += right_elements
            problem_statements.append(str(sorted(problem_statement)))
    return problem_statements

# get predictions output from the BiLSTM+CRF model
# test_predictions = load_bilstm_data("/home/kevin/emnlp2017-bilstm-cnn-crf/problem_predictions.txt")
# test_predictions = load_bilstm_data("/home/kevin/emnlp2017-bilstm-cnn-crf/joint_predictions.txt")


# now generate entity-based stats using extract.sentence_no, start, end, entity
hmm_pred_ners = []
for sentence in test_predictions:
    ners = []
    start = None
    current_tag = None
    for token_no, element in enumerate(sentence):
        token, tag = element[0], element[1]
        if (tag == "O") or (token_no == len(sentence)-1):
            # there was an element before
            if start != None:
                ners.append((start, token_no-1, current_element))
                # reset start
                start = None
            # if we're at the end of sentence and not inside element
            elif tag != "O":
                current_element = get_current_element(tag)
                ners.append((token_no, token_no, current_element))
        # beginning of new element
        elif tag.split("-")[0] == "B":
            # if there was element before
            if start != None:
                ners.append((start, token_no-1, current_element))
            # get new starts and current_element
            current_element = get_current_element(tag)
            start = token_no
    hmm_pred_ners.append(ners)

# print(test_predictions[-5])
# print(test_predictions[-4])
# print(test_set_ners[-5])
# print(test_set_ners[-4])
# print(len(test_predictions), len(test_set_ners))

with open("../test/test_docs_%s.jsonlines" % experiment_type, "r") as infile:
    json_lines_test = [json.loads(line) for line in infile.readlines()]

gold_ners = [[tuple(ner) for ner in ners] for extract in json_lines_test for ners in extract["ners"]]
pred_ners = hmm_pred_ners
with open('/home/kevin/biaffine-ner/biaffine_predictions_solution.pickle', 'rb') as f:
     pred_ners = pickle.load(f)
     print(pred_ners)
     if experiment_type == "solution":
         pred_ners = pred_ners[0::6]

print(len(gold_ners))
print(len(test_predictions))
print(len(pred_ners))
print(test_predictions[-51])
print(pred_ners[-51])
print(gold_ners[-51])

if experiment_type == "joint":
    num_types = ["SIGNAL", "ROOT-RIGHT", "ROOT-LEFT", "COMPLEMENT-LEFT", "COMPLEMENT-RIGHT", "CONDITION-LEFT", "CONDITION-RIGHT", "SOLUTION"]
elif experiment_type == "problem":
    num_types = ["SIGNAL", "ROOT-RIGHT", "ROOT-LEFT", "COMPLEMENT-LEFT", "COMPLEMENT-RIGHT", "CONDITION-LEFT", "CONDITION-RIGHT"]
elif experiment_type == "problem_no_direction":
    num_types = ["SIGNAL", "ROOT", "COMPLEMENT", "CONDITION"]
elif experiment_type == "joint_no_direction":
    num_types = ["SIGNAL", "ROOT", "COMPLEMENT", "CONDITION", "SOLUTION"]    
else:
    num_types = ["SOLUTION"]


# 1 -> 600
tp, fn, fp = 0,0,0
sub_tp, sub_fn, sub_fp = {},{},{}

for sent in range(len(gold_ners)):
    tp += len(set(gold_ners[sent]) & set(pred_ners[sent]))
    fn += len(set(gold_ners[sent]) - set(pred_ners[sent]))
    fp += len(set(pred_ners[sent]) - set(gold_ners[sent]))

    for i in num_types:
        sub_gm = set((s,e,t) for s,e,t in gold_ners[sent] if t == i)
        sub_pm = set((s,e,t) for s,e,t in pred_ners[sent] if t == i)
        
        if i not in sub_tp: sub_tp[i] = 0
        if i not in sub_fn: sub_fn[i] = 0
        if i not in sub_fp: sub_fp[i] = 0
        
        sub_tp[i] += len(sub_gm & sub_pm)
        sub_fn[i] += len(sub_gm - sub_pm)
        sub_fp[i] += len(sub_pm - sub_gm)

m_r = 0 if tp == 0 else float(tp)/(tp+fn)
m_p = 0 if tp == 0 else float(tp)/(tp+fp)
m_f1 = 0 if m_p == 0 else 2.0*m_r*m_p/(m_r+m_p)

print("overall mention: %.2f/%.2f/%.2f" % (m_p,m_r,m_f1))
print("Mention F1: {:.2f}%".format(m_f1*100))
print("Mention recall: {:.2f}%".format(m_r*100))
print("Mention precision: {:.2f}%".format(m_p*100))

# # predictions are in format: (sentence_id, start, end, ner type) (1 indexed)
# # fp fn is based off entities
# # print("saving predictions and gold mentions to file")
# # with open("tmp_biaffine_ner_predictions.txt", "w") as outfile:
# #   for tmp_pred_extract in predictions:


precisions, recalls = [], []

print("****************SUB NER TYPES********************")
for i in num_types:
    sub_r = 0 if sub_tp[i] == 0 else float(sub_tp[i]) / (sub_tp[i] + sub_fn[i])
    sub_p = 0 if sub_tp[i] == 0 else float(sub_tp[i]) / (sub_tp[i] + sub_fp[i])
    precisions.append(sub_p)
    recalls.append(sub_r)
    sub_f1 = 0 if sub_p == 0 else 2.0 * sub_r * sub_p / (sub_r + sub_p)
    print(i)
    print("%.2f/%.2f/%.2f" % (sub_p, sub_r, sub_f1))
    print("{} F1: {:.2f}%".format(i,sub_f1 * 100))
    print("{} recall: {:.2f}%".format(i,sub_r * 100))
    print("{} precision: {:.2f}%".format(i,sub_p * 100))

macro_p = sum(precisions)/len(precisions)
macro_r = sum(recalls)/len(recalls)
print("MACRO MENTION: %.2f/%.2f/%.2f" % (macro_p,macro_r,((2.0*macro_p*macro_r)/(macro_p+macro_r))))

def get_gold_problem_statements():
    # get statement-based precision/recall/f-measure
    from get_problem_statements import get_all_problem_statements
    all_problem_statements = get_all_problem_statements('test')
    # break down into sentence based
    sent_problem_statements = [all_problem_statements[extract][sentence] for extract in range(100) for sentence in range(6)]
    # convert each statement to (start, end, element_type)
    converted = [[convert_element_info(statement) for statement in sentence] for sentence in sent_problem_statements]
    return converted
    # print(len(sent_problem_statements))
    # print(sent_problem_statements[4])
    # print(convert_element_info(sent_problem_statements[4][0]))
    # print(convert_element_info(sent_problem_statements[-4][0]))
    # print(convert_element_info(sent_problem_statements[-4][1]))

gold_problem_statements = get_gold_problem_statements()
pred_problem_statements = [group_into_problem_statements(pred_ner) for pred_ner in pred_ners]

print(gold_problem_statements == pred_problem_statements)    
tp, fn, fp = 0,0,0

for sent in range(len(gold_problem_statements)):
    # print(gold_problem_statements[sent])
    # print(pred_problem_statements[sent])
    tp += len(set(gold_problem_statements[sent]) & set(pred_problem_statements[sent]))
    fn += len(set(gold_problem_statements[sent]) - set(pred_problem_statements[sent]))
    fp += len(set(pred_problem_statements[sent]) - set(gold_problem_statements[sent]))

m_r = 0 if tp == 0 else float(tp)/(tp+fn)
m_p = 0 if tp == 0 else float(tp)/(tp+fp)
m_f1 = 0 if m_p == 0 else 2.0*m_r*m_p/(m_r+m_p)

print("Statement precision/recall/f-measure: %.2f/%.2f/%.2f" % (m_p, m_r, m_f1))
print("Statement F1: {:.2f}%".format(m_f1*100))
print("Statement recall: {:.2f}%".format(m_r*100))
print("Statement precision: {:.2f}%".format(m_p*100))



# print(len(gold_problem_statements[0]))
# print(len(gold_problem_statements[-1]))
# print(len(gold_problem_statements[-2]))
# print(len(gold_problem_statements[-3]))
# print(len(gold_problem_statements[-4]), gold_problem_statements[-4])
# print(len(gold_problem_statements[-2]), gold_problem_statements[-2])
# print(len(pred_problem_statements[-2]), pred_problem_statements[-2])
# for i in range(600):
#     if gold_problem_statements[i] != pred_problem_statements[i]:
#         print("DIFF:", i)
#         print(gold_problem_statements[i])
#         print(pred_problem_statements[i])        

# print(tagger.tag("This is a problem".split()))
# print(tagger.tag("This is a problem for the model".split()))
# print(tagger.tag("If it is not good , there is an issue with the model".split()))
# print(tagger.tag("In this paper , we propose a new model .".split()))

