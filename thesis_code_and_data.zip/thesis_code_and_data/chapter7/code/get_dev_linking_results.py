from sklearn.metrics import precision_recall_fscore_support

answer = [float(line.strip().split()[1]) for line in open("dev_link_data_Anna.txt", "r")]

annotator = "Anna"

for feature_set in ["tfidf"]:
    for topic in ["10", "20", "30", "40", "50"]:    
    # for context in ["C0", "C5", "C10", "C1000"]:
        # print("context:", context)
        print("topic:", topic)
        # for topic in ["10", "20", "30", "40", "50"]:
        for context in ["C0", "C5", "C10", "C1000"]:            
            # print("topic:", topic)
            print("context:", context)
            try:
                feature_set_data = [float(line.strip()) for line in open("predictions/NRTM_predictions_%s_%s_DEV_%s_%s_topics_%s.txt" % (feature_set, context, annotator, topic, "notnormed"), "r")]
                precision, recall, fmeasure, support = precision_recall_fscore_support(answer, feature_set_data, average="macro")            
                print("%.2f/%.2f/%.2f" % (precision, recall, fmeasure))
            except Exception as e:
                print(e)
                # print("predictions/NRTM_predictions_%s_%s_DEV_%s_%s_topics_%s.txt" % (feature_set, context, annotator, topic, "notnormed"))
                pass

