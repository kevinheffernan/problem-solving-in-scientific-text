# get each feature set in its own file

# feature extraction for the Neural Relational Topic Model

import re, numpy, scipy, math, pickle
import numpy as np
from dataclasses import dataclass
from typing import Any
from nltk.metrics import AnnotationTask
from collections import defaultdict
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

@dataclass
class ProblemStatement:
    signal: dict
    condition: Any = None
    head: Any = None
    root: Any = None
    link_1: bool = False
    link_2: bool = False
    sentence_number: int = None


@dataclass
class SolutionStatement:
    solution: dict


def get_extracts():
    train = "../train/training_docs.txt"    
    test = "../test/test_docs.txt"
    dev = "../dev/dev_docs.txt"
    # using anna temporarily
    # dev = "../dev/annotations/Anna_dev.txt"

    # # using patricia temporarily
    # dev = "../dev/annotations/Patricia_dev.txt"    

    total_extracts = {}
    for i, annotator in enumerate([train, dev, test]):
        extracts = []
        extract = []
        with open(annotator) as infile:
            for l in infile:
                line = l.strip()
                if line == "":
                    extracts.append(extract)
                    extract = []
                else:
                    extract.append(line)
        if i == 0: total_extracts['train'] = extracts
        elif i == 1: total_extracts['dev'] = extracts
        else: total_extracts['test'] = extracts
    return total_extracts    


def find_start_of_element(text, end_of_element):
    for j in range(end_of_element, -1, -1):
        if text[j].startswith("//"):
            start_of_element = j
            return start_of_element

        
def determine_element(i, text, direction):
    element = None
    # if we're searching right, then the condition will need to have a left
    condition = "[^ ]+//C" + ("L" if direction == "right" else "R")
    head = "[^ ]+//H" + ("L" if direction == "right" else "R")
    root = "[^ ]+//R" + ("L" if direction == "right" else "R") + "[^ ]*"
    signal = "[^ ]+//S[^ ]*"
    if re.match(condition, text[i]):
        element = 'condition'
    elif re.match(head, text[i]):
        element = 'head'
    elif re.match(root, text[i]):
        if not text[i].endswith("//RR") and not text[i].endswith("//RL") and not text[i].endswith("//RR[1,2]"):
            print("root to look at:", text[i], text)        
        element = 'root'
    elif re.match(signal, text[i]):
        element = 'signal'
    return element


def find_solution_statements(text, sent_no):
    statements = []
    next_signal_include_root = False
    previous_root = None
    for i, token in enumerate(text):
        if token.endswith("\\\\") or token.endswith("\\\\*") or token.endswith("\\\\**"):
            statements.append(SolutionStatement(solution = extract_basic_info_solution(text, i)))
    return statements


# from each element extract basic information
def extract_basic_info_solution(text, i):
    start_of_element = None
    for j in range(i, -1, -1):
        if text[j].startswith("\\\\"):
            start_of_element = j
            break    
    element_raw_text = " ".join(text[start_of_element : i+1])
    return {"raw": element_raw_text,
            "text": element_raw_text.split("\\\\")[1],
            "start": start_of_element,
            "end": i}


# from each element extract basic information
def extract_basic_info(text, i):
    start_of_element = find_start_of_element(text, i)
    element_raw_text = " ".join(text[start_of_element : i+1])
    return {"raw": element_raw_text,
            "text": element_raw_text.split("//")[1],
            "start": start_of_element,
            "end": i}


def search_right_of_signal(end, text, statement):
    for j in range(end+1, len(text)):
        if determine_element(j, text, None) == "signal":
            break
        elif determine_element(j, text, "right") in ["root", "head", "condition"]:
            if determine_element(j, text, "right") == "condition":
                statement.condition = extract_basic_info(text, j)
                statement.condition["direction"] = "left"
            elif determine_element(j, text, "right") == "head":
                statement.head = extract_basic_info(text, j)
                statement.head["direction"] = "left"
            elif determine_element(j, text, "right") == "root":
                statement.root = extract_basic_info(text, j)
                statement.root["direction"] = "left"                                
    return statement


def search_left_of_signal(start, text, statement):
    for j in range(start-1, -1, -1):
        # stop search if another signal is reached
        if determine_element(j, text, None) == "signal":
            break
        elif determine_element(j, text, "left") in ["root", "head", "condition"]:
            if determine_element(j, text, "left") == "condition":
                statement.condition = extract_basic_info(text, j)
                statement.condition["direction"] = "right"
            elif determine_element(j, text, "left") == "head":
                statement.head = extract_basic_info(text, j)
                statement.head["direction"] = "right"
            elif determine_element(j, text, "left") == "root":
                statement.root = extract_basic_info(text, j)
                statement.root["direction"] = "right"                
    return statement


def find_statements(text, sent_no):
    statements = []
    next_signal_include_root = False
    previous_root = None
    total_heads, heads_in_statements = 0, 0
    total_conditions, conditions_in_statements = 0, 0
    total_roots, roots_in_statements = 0, 0        
    for i, token in enumerate(text):
        if determine_element(i, text, None) == "signal":
            start_of_signal = find_start_of_element(text, i)
            signal_raw_text = " ".join(text[start_of_signal : i+1])
            link1, link2 = False, False
            if "**" in signal_raw_text.split("//")[2]:
                link2 = True
            if signal_raw_text.split("//")[2] in ["S**,*", "S*", "S*,**"]:
                link1 = True
            statement = ProblemStatement(signal = extract_basic_info(text, i))
            statement.link_1 = link1
            statement.link_2 = link2
            statement.sentence_number = sent_no
            statement = search_left_of_signal(start_of_signal, text, statement)                        
            statement = search_right_of_signal(i, text, statement)

            if statement.head: heads_in_statements += 1
            if statement.condition: conditions_in_statements += 1
            if statement.root: roots_in_statements += 1                        
            statements.append(statement)

        if determine_element(i, text, "left") == "head": total_heads +=1
        if determine_element(i, text, "right") == "head": total_heads +=1
        
        if determine_element(i, text, "left") == "condition": total_conditions +=1
        if determine_element(i, text, "right") == "condition": total_conditions +=1

        if determine_element(i, text, "left") == "root": total_roots +=1
        if determine_element(i, text, "right") == "root": total_roots +=1                

    if total_heads != heads_in_statements:
        print("head discrepancy")
        print(text)
    if total_conditions != conditions_in_statements:
        print("condition discrepancy")
        print(text)
    if total_roots != roots_in_statements:
        print("root discrepancy")
        print(text)                
    return statements


def calculate_indices_of_elements(statements):
    indices = {}
    for statement in statements:
        indices[statement.signal["start"]] =  [statement.signal["end"], "S"]
        if statement.root:
            indices[statement.root["start"]] = [statement.root["end"], "R" + ("L" if statement.root["direction"] == "left" else "R")]
        if statement.head:
            indices[statement.head["start"]] = [statement.head["end"], "H" + ("L" if statement.head["direction"] == "left" else "R")]
        if statement.condition:
            indices[statement.condition["start"]] = [statement.condition["end"], "C" + ("L" if statement.condition["direction"] == "left" else "R")]
    return indices


# removes the markings from token
def remove_markings(token):
    # remove prefix marking
    if token[0:2] == "//": token = token[2:]
    if token[0:2] == "\\\\": token = token[2:]    
    # remove postfix marking
    if token.endswith("//HL"): token = token.replace("//HL", "")
    if token.endswith("//HR"): token = token.replace("//HR", "")
    if token.endswith("//RR"): token = token.replace("//RR", "")
    if token.endswith("//RL"): token = token.replace("//RL", "")
    if token.endswith("//CL"): token = token.replace("//CL", "")
    if token.endswith("//CR"): token = token.replace("//CR", "")
    if token.endswith("//S"): token = token.replace("//S", "")
    if token.endswith("//S*"): token = token.replace("//S*", "")
    if token.endswith("//S**"): token = token.replace("//S**", "")
    if token.endswith("//S*,**"): token = token.replace("//S*,**", "")
    if token.endswith("\\\\"): token = token.replace("\\\\", "")
    if token.endswith("\\\\*"): token = token.replace("\\\\*", "")
    if token.endswith("\\\\**"): token = token.replace("\\\\**", "")
    return token    
                

def get_all_statements_and_contexts(extracts):
    statement_number = 0
    all_statements = []
    all_contexts = []

    for extract in range(len(extracts)):
        extract_problem_statements = []    
        sentence_number = 0
        for sentence in range(len(extracts[extract])):
            # ignore extract id
            if sentence == 0:
                continue
            sentence_number += 1

            annotator_sent = extracts[extract][sentence].split()
            problem_statements = find_statements(annotator_sent, sentence_number)

            all_statements += problem_statements
            for statement in problem_statements:
                all_contexts.append([remove_markings(token) for token in annotator_sent])
            # when we're at the end of an extract
            if sentence_number == 6:
                solution_statements = find_solution_statements(annotator_sent, sentence_number)
                all_statements += solution_statements
                for statement in solution_statements:
                    all_contexts.append([remove_markings(token) for token in annotator_sent])
    return all_statements, all_contexts


def get_all_statements_and_contexts_with_markings(extracts):
    statement_number = 0
    all_statements = []
    all_contexts = []

    for extract in range(len(extracts)):
        extract_problem_statements = []    
        sentence_number = 0
        for sentence in range(len(extracts[extract])):
            # ignore extract id
            if sentence == 0:
                continue
            sentence_number += 1

            annotator_sent = extracts[extract][sentence].split()
            problem_statements = find_statements(annotator_sent, sentence_number)

            all_statements += problem_statements
            for statement in problem_statements:
                all_contexts.append([token for token in annotator_sent])
            # when we're at the end of an extract
            if sentence_number == 6:
                solution_statements = find_solution_statements(annotator_sent, sentence_number)
                all_statements += solution_statements
                for statement in solution_statements:
                    all_contexts.append([token for token in annotator_sent])
    return all_statements, all_contexts



# p = statement
def get_context(sentence, p, context):
    lefts, rights = [], []
    if hasattr(p, "signal"):
        lefts.append(p.signal["start"])
        rights.append(p.signal["end"])
        if p.root:
            lefts.append(p.root["start"])
            rights.append(p.root["end"])            
        if p.head:
            lefts.append(p.head["start"])
            rights.append(p.head["end"])                        
        if p.condition:
            lefts.append(p.condition["start"])
            rights.append(p.condition["end"])                                    
    else:
        lefts.append(p.solution["start"])
        rights.append(p.solution["end"])
    most_left = min(lefts)
    most_right = max(rights)
    # if goes below zero take zero
    left_marker = max(most_left - context, 0)
    # if goes beyond sentence length take sentence length
    right_marker = min(most_right + context, len(sentence)-1)
    # return left and right context
    return [remove_markings(token) for token in sentence[left_marker:most_left]], [remove_markings(token) for token in sentence[most_right+1:right_marker+1]]


def get_statement_text(p):
    statement_text = []
    indices = []
    # if problem statement
    if hasattr(p, "signal"):
        indices.append([p.signal["start"], p.signal["text"]])
        if p.root:
            indices.append([p.root["start"], p.root["text"]])                
        if p.head:
            indices.append([p.head["start"], p.head["text"]])
        if p.condition:
            indices.append([p.condition["start"], p.condition["text"]])                
    else:
        indices.append([p.solution["start"], p.solution["text"]])

    indices.sort()            
    statement_text = [t[1] for t in indices]
    return statement_text


# get vectorizer
def get_vectorizer(statements, typ, all_contexts, __CONTEXT__):
    sentences = []
    for index, p in enumerate(statements):
        statement_text = get_statement_text(p)
        left_context, right_context = get_context(all_contexts[index], p, __CONTEXT__)
        # print(" ".join(left_context) +" | "+ " ".join(statement_text) +" | "+ " ".join(right_context))
        statement_context = " ".join(left_context + statement_text + right_context)
        # print(statement_context)
        sentences.append(statement_context)        
    if typ == "tfidf":
        vectorizer = TfidfVectorizer(strip_accents='ascii')
    elif typ == "binary":
        vectorizer = CountVectorizer(strip_accents='ascii', binary=True)            
    else:
        vectorizer = CountVectorizer(strip_accents='ascii')                    
    X = vectorizer.fit_transform(sentences)

    print("number of vectorized words:", X.shape)
    return vectorizer


def get_matrix_lemmas(statements, all_contexts, __CONTEXT__, vectorizer, log_normal, spacy_module):
    sentences = []
    for index, p in enumerate(statements):
        statement_text = get_statement_text(p)
        left_context, right_context = get_context(all_contexts[index], p, __CONTEXT__)
        statement_context = " ".join(left_context + statement_text + right_context).lower()
        statement_context = " ".join(token.lemma_ for token in spacy_module(statement_context))
        sentences.append(statement_context)
    if not log_normal:
        return vectorizer.transform(sentences).todense()
    else:
        counts = np.array(vectorizer.transform(sentences).todense())
        matrix = []
        for row in counts:
            vector = np.zeros(len(row))
            denominator = max([math.log(1 + n_i) for n_i in row])
            for i in range(len(vector)):
                # if entry is non-zero
                if row[i] > 0:
                    vector[i] = math.log(1 + row[i]) / denominator
            matrix.append(vector)        
        return np.matrix(matrix)


def get_matrix(statements, all_contexts, __CONTEXT__, vectorizer, log_normal):
    sentences = []
    for index, p in enumerate(statements):
        statement_text = get_statement_text(p)
        left_context, right_context = get_context(all_contexts[index], p, __CONTEXT__)
        statement_context = " ".join(left_context + statement_text + right_context).lower()
        sentences.append(statement_context)
    if not log_normal:
        return vectorizer.transform(sentences).todense()
    else:
        counts = np.array(vectorizer.transform(sentences).todense())
        matrix = []
        for row in counts:
            vector = np.zeros(len(row))
            denominator = max([math.log(1 + n_i) for n_i in row])
            for i in range(len(vector)):
                # if entry is non-zero
                if row[i] > 0:
                    vector[i] = math.log(1 + row[i]) / denominator
            matrix.append(vector)        
        return np.matrix(matrix)


def get_lognorm_extract_matrix(sentences, vectorizer):
    counts = np.array(vectorizer.transform(sentences).todense())
    matrix = []
    for row in counts:
        vector = np.zeros(len(row))
        denominator = max([math.log(1 + n_i) for n_i in row])
        for i in range(len(vector)):
            # if entry is non-zero
            if row[i] > 0:
                vector[i] = math.log(1 + row[i]) / denominator
        matrix.append(vector)        
    return np.matrix(matrix)    


def get_bow_type_data(all_statements, all_contexts, __CONTEXT__):
    # initialize the vectorizer on training data (3685 = len of training data)
    tfidf_vectorizer = get_vectorizer(all_statements[:3685], "tfidf", all_contexts,  __CONTEXT__)
    binary_vectorizer = get_vectorizer(all_statements[:3685], "binary", all_contexts, __CONTEXT__)
    count_vectorizer = get_vectorizer(all_statements[:3685], "count", all_contexts, __CONTEXT__)

    tfidf_docs_matrix = get_matrix(all_statements, all_contexts, __CONTEXT__, tfidf_vectorizer, log_normal=False)
    print("document matrix shape", tfidf_docs_matrix.shape)
    with open('feature_files/tfidf_C%s.matrix' % __CONTEXT__,'wb') as outfile:
        for line in tfidf_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                

    binary_docs_matrix = get_matrix(all_statements,  all_contexts, __CONTEXT__, binary_vectorizer, log_normal=False)
    print("document matrix shape", binary_docs_matrix.shape)
    with open('feature_files/binary_C%s.matrix' % __CONTEXT__,'wb') as outfile:
        for line in binary_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                

    lognorm_docs_matrix = get_matrix(all_statements,  all_contexts, __CONTEXT__, count_vectorizer, log_normal=True)
    print("document matrix shape", lognorm_docs_matrix.shape)
    with open('feature_files/lognorm_C%s.matrix' % __CONTEXT__,'wb') as outfile:
        for line in lognorm_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                

    # each vocab is a dictionary so need to ensure each is saved instead of one
    with open('feature_files/vocab_tfidf_C%s.txt' % __CONTEXT__, 'w') as outfile:
        inverse_vocab = {v: k for k, v in tfidf_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    with open('feature_files/vocab_binary_C%s.txt' % __CONTEXT__, 'w') as outfile:
        inverse_vocab = {v: k for k, v in binary_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    with open('feature_files/vocab_lognorm_C%s.txt' % __CONTEXT__, 'w') as outfile:
        inverse_vocab = {v: k for k, v in count_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])                


def get_SBERT(statements, all_contexts, __CONTEXT__):
    from sentence_transformers import SentenceTransformer
    # load RoBERTa model
    model = SentenceTransformer('roberta-large-nli-stsb-mean-tokens')
    sentences = []
    for index, p in enumerate(statements):
        statement_text = get_statement_text(p)
        left_context, right_context = get_context(all_contexts[index], p, __CONTEXT__)
        statement_context = " ".join(left_context + statement_text + right_context).lower()
        sentences.append(statement_context)
    print("sentences loaded.")
    SBERT_embeddings = model.encode(sentences)
    print("SBERT embeddings:", len(SBERT_embeddings), type(SBERT_embeddings), len(SBERT_embeddings[0]))
    SBERT_embedding_matrix = np.matrix(SBERT_embeddings)
    with open("feature_files/SBERT_C%s_Anna.matrix" % __CONTEXT__, "wb") as outfile:
        for line in SBERT_embedding_matrix:
            np.savetxt(outfile, line)    
    print("SBERT embedding shape:", SBERT_embedding_matrix.shape)


def get_positional_embedding(statements):
    embs = [[1,0,0,0,0,0], [0,1,0,0,0,0], [0,0,1,0,0,0], [0,0,0,1,0,0], [0,0,0,0,1,0], [0,0,0,0,0,1]]
    positional_embeddings = []
    for statement in statements:
        if hasattr(statement, "signal"):
            positional_embeddings.append(np.array(embs[statement.sentence_number - 1]))
        else:
            positional_embeddings.append(np.array(embs[-1]))            
    positional_embedding_matrix = np.matrix(positional_embeddings)
    with open("feature_files/positional_embeddings_Patricia.matrix", "w") as outfile:
        for line in positional_embedding_matrix:
            np.savetxt(outfile, line)    


# bow representation for entire extract
def get_bow_type_data_extract_sents(extracts, all_statements, all_contexts, __CONTEXT__):
    # concatentate all sentences in each extract and remove markings and document markers
    extract_sents = [" ".join([remove_markings(t).lower() for t in s.split()]) for e in extracts for s in e[1:]]
    print("Number of extract sents", len(extract_sents))
    tfidf_vectorizer = TfidfVectorizer(strip_accents='ascii')
    binary_vectorizer = CountVectorizer(strip_accents='ascii', binary=True)            
    count_vectorizer = CountVectorizer(strip_accents='ascii')

    # fit on training data
    X = tfidf_vectorizer.fit_transform(extract_sents[:5400])
    X = binary_vectorizer.fit_transform(extract_sents[:5400])
    X = count_vectorizer.fit_transform(extract_sents[:5400])
    
    tfidf_extract_matrix = tfidf_vectorizer.transform(extract_sents).todense()
    binary_extract_matrix = binary_vectorizer.transform(extract_sents).todense()        
    lognorm_extract_matrix = get_lognorm_extract_matrix(extract_sents, count_vectorizer)

    print("tfidf extract sents matrix shape", tfidf_extract_matrix.shape)
    with open('feature_files/tfidf_sents_EXTRACT.matrix', 'wb') as outfile:
        for line in tfidf_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    print("binary extract sents matrix shape", binary_extract_matrix.shape)
    with open('feature_files/binary_sents_EXTRACT.matrix', 'wb') as outfile:
        for line in binary_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    print("lognorm extract sents matrix shape", lognorm_extract_matrix.shape)
    with open('feature_files/lognorm_sents_EXTRACT.matrix', 'wb') as outfile:
        for line in lognorm_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                                        

    # each vocab is a dictionary so need to ensure each is saved instead of one
    with open('feature_files/vocab_tfidf_sents_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in tfidf_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    with open('feature_files/vocab_binary_sents_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in binary_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    with open('feature_files/vocab_lognorm_sents_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in count_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    tfidf_docs_matrix = get_matrix(all_statements, all_contexts, __CONTEXT__, tfidf_vectorizer, log_normal=False)
    print("document matrix shape", tfidf_docs_matrix.shape)
    with open('feature_files/tfidf_C%s_sents_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in tfidf_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    binary_docs_matrix = get_matrix(all_statements,  all_contexts, __CONTEXT__, binary_vectorizer, log_normal=False)
    print("document matrix shape", binary_docs_matrix.shape)
    with open('feature_files/binary_C%s_sents_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in binary_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                

    lognorm_docs_matrix = get_matrix(all_statements,  all_contexts, __CONTEXT__, count_vectorizer, log_normal=True)
    print("document matrix shape", lognorm_docs_matrix.shape)
    with open('feature_files/lognorm_C%s_sents_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in lognorm_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                


# bow representation for entire extract while taking out REFs
def get_bow_type_data_extracts_REFs(extracts, all_statements, all_contexts, __CONTEXT__):
    regex = "\( [^)]*[12][0-9][0-9][0-9] [^)]*\)"    
    # concatentate all sentences in each extract and remove markings and document markers
    extract_sents = [" ".join([remove_markings(t).lower() for t in s.split()]) for e in extracts for s in e[1:]]
    print("Number of extract sents", len(extract_sents))
    ref_extract_sents = []
    for sent in extract_sents:
        # remove references
        matches = re.findall(regex, sent)
        for match in matches:
            sent = sent.replace(match, "[REF]")
        ref_extract_sents.append(sent)
    print("Number of extract sents after REFS", len(ref_extract_sents))        
    tfidf_vectorizer = TfidfVectorizer(strip_accents='ascii')
    binary_vectorizer = CountVectorizer(strip_accents='ascii', binary=True)            
    count_vectorizer = CountVectorizer(strip_accents='ascii')

    # fit on training data
    X = tfidf_vectorizer.fit_transform(ref_extract_sents[:5400])
    X = binary_vectorizer.fit_transform(ref_extract_sents[:5400])
    X = count_vectorizer.fit_transform(ref_extract_sents[:5400])
    
    tfidf_extract_matrix = tfidf_vectorizer.transform(ref_extract_sents).todense()
    binary_extract_matrix = binary_vectorizer.transform(ref_extract_sents).todense()        
    lognorm_extract_matrix = get_lognorm_extract_matrix(ref_extract_sents, count_vectorizer)

    print("tfidf extract sents matrix shape", tfidf_extract_matrix.shape)
    with open('feature_files/tfidf_sents_REFs_EXTRACT.matrix', 'wb') as outfile:
        for line in tfidf_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    print("binary extract sents matrix shape", binary_extract_matrix.shape)
    with open('feature_files/binary_sents_REFs_EXTRACT.matrix', 'wb') as outfile:
        for line in binary_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    print("lognorm extract sents matrix shape", lognorm_extract_matrix.shape)
    with open('feature_files/lognorm_sents_REFs_EXTRACT.matrix', 'wb') as outfile:
        for line in lognorm_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                                        

    # each vocab is a dictionary so need to ensure each is saved instead of one
    with open('feature_files/vocab_tfidf_sents_REFs_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in tfidf_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    with open('feature_files/vocab_binary_sents_REFs_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in binary_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    with open('feature_files/vocab_lognorm_sents_REFs_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in count_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    tfidf_docs_matrix = get_matrix(all_statements, all_contexts, __CONTEXT__, tfidf_vectorizer, log_normal=False)
    print("document matrix shape", tfidf_docs_matrix.shape)
    with open('feature_files/tfidf_C%s_sents_REFs_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in tfidf_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    binary_docs_matrix = get_matrix(all_statements,  all_contexts, __CONTEXT__, binary_vectorizer, log_normal=False)
    print("document matrix shape", binary_docs_matrix.shape)
    with open('feature_files/binary_C%s_sents_REFs_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in binary_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                

    lognorm_docs_matrix = get_matrix(all_statements,  all_contexts, __CONTEXT__, count_vectorizer, log_normal=True)
    print("document matrix shape", lognorm_docs_matrix.shape)
    with open('feature_files/lognorm_C%s_sents_REFs_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in lognorm_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                


# bow representation for entire extract while taking out REFs and lemmatising
def get_bow_type_data_extracts_REFs_lemmas(extracts, all_statements, all_contexts, __CONTEXT__):
    import spacy
    spacy_module = spacy.load('en')
    
    regex = "\( [^)]*[12][0-9][0-9][0-9] [^)]*\)"    
    # concatentate all sentences in each extract and remove markings and document markers
    extract_sents = [" ".join([remove_markings(t).lower() for t in s.split()]) for e in extracts for s in e[1:]]
    extracts = [" ".join([remove_markings(t).lower() for s in e[1:] for t in s.split()]) for e in extracts]    
    extracts_lemmas = [" ".join([token.lemma_ for token in spacy_module(extract.lower())]) for extract in extracts]

    ref_extract = []
    for extract in extracts_lemmas:
        # remove references
        matches = re.findall(regex, extract)
        for match in matches:
            extract = extract.replace(match, "[REF]")
        ref_extract.append(extract)
    print("Number of extract sents after REFS", len(ref_extract))

    tfidf_vectorizer = TfidfVectorizer(strip_accents='ascii')
    binary_vectorizer = CountVectorizer(strip_accents='ascii', binary=True)            
    count_vectorizer = CountVectorizer(strip_accents='ascii')

    # fit on training data
    X = tfidf_vectorizer.fit_transform(ref_extract[:900])
    X = binary_vectorizer.fit_transform(ref_extract[:900])
    X = count_vectorizer.fit_transform(ref_extract[:900])
    
    tfidf_extract_matrix = tfidf_vectorizer.transform(ref_extract).todense()
    binary_extract_matrix = binary_vectorizer.transform(ref_extract).todense()        
    lognorm_extract_matrix = get_lognorm_extract_matrix(ref_extract, count_vectorizer)

    print("tfidf extract sents matrix shape", tfidf_extract_matrix.shape)
    with open('feature_files/tfidf_REFs_lemmas_EXTRACT.matrix', 'wb') as outfile:
        for line in tfidf_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    print("binary extract sents matrix shape", binary_extract_matrix.shape)
    with open('feature_files/binary_REFs_lemmas_EXTRACT.matrix', 'wb') as outfile:
        for line in binary_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    print("lognorm extract sents matrix shape", lognorm_extract_matrix.shape)
    with open('feature_files/lognorm_REFs_lemmas_EXTRACT.matrix', 'wb') as outfile:
        for line in lognorm_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                                        

    # each vocab is a dictionary so need to ensure each is saved instead of one
    with open('feature_files/vocab_tfidf_REFs_lemmas_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in tfidf_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    with open('feature_files/vocab_binary_REFs_lemmas_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in binary_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    with open('feature_files/vocab_lognorm_REFs_lemmas_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in count_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    tfidf_docs_matrix = get_matrix_lemmas(all_statements, all_contexts, __CONTEXT__, tfidf_vectorizer, False, spacy_module)
    print("document matrix shape", tfidf_docs_matrix.shape)
    with open('feature_files/tfidf_C%s_REFs_lemmas_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in tfidf_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    binary_docs_matrix = get_matrix_lemmas(all_statements,  all_contexts, __CONTEXT__, binary_vectorizer, False, spacy_module)
    print("document matrix shape", binary_docs_matrix.shape)
    with open('feature_files/binary_C%s_REFs_lemmas_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in binary_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                

    lognorm_docs_matrix = get_matrix_lemmas(all_statements,  all_contexts, __CONTEXT__, count_vectorizer, True, spacy_module)
    print("document matrix shape", lognorm_docs_matrix.shape)
    with open('feature_files/lognorm_C%s_REFs_lemmas_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in lognorm_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')                
            


# bow representation for entire extract
def get_bow_type_data_extracts(extracts, all_statements, all_contexts, __CONTEXT__):
    # concatentate all sentences in each extract and remove markings and document markers
    extracts = [" ".join([remove_markings(t).lower() for s in e[1:] for t in s.split()]) for e in extracts]
    print("Number of extract sents", len(extracts))

    tfidf_vectorizer = TfidfVectorizer(strip_accents='ascii')
    binary_vectorizer = CountVectorizer(strip_accents='ascii', binary=True)            
    count_vectorizer = CountVectorizer(strip_accents='ascii')

    # fit on training data
    X = tfidf_vectorizer.fit_transform(extracts[:900])
    X = binary_vectorizer.fit_transform(extracts[:900])
    X = count_vectorizer.fit_transform(extracts[:900])
    
    tfidf_extract_matrix = tfidf_vectorizer.transform(extracts).todense()
    binary_extract_matrix = binary_vectorizer.transform(extracts).todense()        
    lognorm_extract_matrix = get_lognorm_extract_matrix(extracts, count_vectorizer)

    # print("tfidf extract matrix shape", tfidf_extract_matrix.shape)
    # with open('feature_files/tfidf_EXTRACT.matrix', 'wb') as outfile:
    #     for line in tfidf_extract_matrix:
    #         np.savetxt(outfile, line, fmt='%.2f')

    # print("binary extract matrix shape", binary_extract_matrix.shape)
    # with open('feature_files/binary_EXTRACT.matrix', 'wb') as outfile:
    #     for line in binary_extract_matrix:
    #         np.savetxt(outfile, line, fmt='%.2f')

    # print("lognorm extract matrix shape", lognorm_extract_matrix.shape)
    # with open('feature_files/lognorm_EXTRACT.matrix', 'wb') as outfile:
    #     for line in lognorm_extract_matrix:
    #         np.savetxt(outfile, line, fmt='%.2f')                                        

    # # each vocab is a dictionary so need to ensure each is saved instead of one
    # with open('feature_files/vocab_tfidf_EXTRACT.txt', 'w') as outfile:
    #     inverse_vocab = {v: k for k, v in tfidf_vectorizer.vocabulary_.items()}
    #     for i in range(len(inverse_vocab)):
    #         outfile.write("%s\n" % inverse_vocab[i])

    # with open('feature_files/vocab_binary_EXTRACT.txt', 'w') as outfile:
    #     inverse_vocab = {v: k for k, v in binary_vectorizer.vocabulary_.items()}
    #     for i in range(len(inverse_vocab)):
    #         outfile.write("%s\n" % inverse_vocab[i])

    # with open('feature_files/vocab_lognorm_EXTRACT.txt', 'w') as outfile:
    #     inverse_vocab = {v: k for k, v in count_vectorizer.vocabulary_.items()}
    #     for i in range(len(inverse_vocab)):
    #         outfile.write("%s\n" % inverse_vocab[i])

    tfidf_docs_matrix = get_matrix(all_statements, all_contexts, __CONTEXT__, tfidf_vectorizer, log_normal=False)
    print("document matrix shape", tfidf_docs_matrix.shape)
    with open('feature_files/tfidf_C%s_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in tfidf_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    # binary_docs_matrix = get_matrix(all_statements,  all_contexts, __CONTEXT__, binary_vectorizer, log_normal=False)
    # print("document matrix shape", binary_docs_matrix.shape)
    # with open('feature_files/binary_C%s_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
    #     for line in binary_docs_matrix:
    #         np.savetxt(outfile, line, fmt='%.2f')                

    # lognorm_docs_matrix = get_matrix(all_statements,  all_contexts, __CONTEXT__, count_vectorizer, log_normal=True)
    # print("document matrix shape", lognorm_docs_matrix.shape)
    # with open('feature_files/lognorm_C%s_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
    #     for line in lognorm_docs_matrix:
    #         np.savetxt(outfile, line, fmt='%.2f')


# bow representation for entire extract
def get_bow_count_type_data_extracts(extracts, all_statements, all_contexts, __CONTEXT__):
    # concatentate all sentences in each extract and remove markings and document markers
    extracts = [" ".join([remove_markings(t).lower() for s in e[1:] for t in s.split()]) for e in extracts]
    print("Number of extract sents", len(extracts))
    count_vectorizer = CountVectorizer(strip_accents='ascii')

    # fit on training data
    X = count_vectorizer.fit_transform(extracts[:900])
    count_extract_matrix = count_vectorizer.transform(extracts).todense()

    print("count extract matrix shape", count_extract_matrix.shape)
    with open('feature_files/count_EXTRACT.matrix', 'wb') as outfile:
        for line in count_extract_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

    # each vocab is a dictionary so need to ensure each is saved instead of one
    with open('feature_files/vocab_count_EXTRACT.txt', 'w') as outfile:
        inverse_vocab = {v: k for k, v in count_vectorizer.vocabulary_.items()}
        for i in range(len(inverse_vocab)):
            outfile.write("%s\n" % inverse_vocab[i])

    count_docs_matrix = get_matrix(all_statements, all_contexts, __CONTEXT__, count_vectorizer, log_normal=False)
    print("document matrix shape", count_docs_matrix.shape)
    with open('feature_files/count_C%s_EXTRACT.matrix' % __CONTEXT__,'wb') as outfile:
        for line in count_docs_matrix:
            np.savetxt(outfile, line, fmt='%.2f')

            

if __name__ == "__main__":
    # read in extracts
    extracts = get_extracts()
    all_extracts = extracts['train'] + extracts['dev'] + extracts['test']
    extracts = all_extracts
    print("number of extracts:", len(extracts))

    all_statements, all_contexts = get_all_statements_and_contexts(extracts)


    # CONTEXT PARAMETER
    __CONTEXT__ = 5

    get_bow_type_data_extracts(extracts, all_statements, all_contexts, __CONTEXT__)    

    # get_bow_type_data_extracts_REFs_lemmas(extracts, all_statements, all_contexts, __CONTEXT__)    

    # get_bow_count_type_data_extracts(extracts, all_statements, all_contexts, __CONTEXT__)

    # get_bow_type_data_extracts_REFs(extracts, all_statements, all_contexts, __CONTEXT__)

    # get_bow_type_data(all_statements, all_contexts, __CONTEXT__)

    # get_SBERT(all_statements, all_contexts, __CONTEXT__)

    # get_positional_embedding(all_statements)

