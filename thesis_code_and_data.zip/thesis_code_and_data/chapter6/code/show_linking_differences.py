# shows differences in linking

import sys, glob
import numpy as np
from scipy import stats
from sklearn.metrics import precision_recall_fscore_support
from get_features import get_extracts, get_all_statements_and_contexts_with_markings

test_link_sent_numbers = [int(line.strip().split()[2]) for line in open("test_link_data.txt", "r")]
answer = [int(line.strip().split()[1]) for line in open("test_link_data.txt", "r")]
nrtm_custom = [int(line.strip()) for line in open("predictions/nrtm_custom/raw/binary_C0_seed_0.txt", "r")]
naive_bayes = [int(line.strip()) for line in open("predictions/binary_C0__positional_embeddings_NB_TEST.pred_extracted", "r")]
answer_sent_responses = {1:[], 2:[], 3:[], 4:[], 5:[], 6:[]}
naive_bayes_sent_responses = {1:[], 2:[], 3:[], 4:[], 5:[], 6:[]}
nrtm_custom_sent_responses = {1:[], 2:[], 3:[], 4:[], 5:[], 6:[]}
# print("%.2f" % precision_recall_fscore_support(answer, nrtm_custom, average='macro')[2])
# print("%.2f" % precision_recall_fscore_support(answer, naive_bayes, average='macro')[2])

##############################
feature_set_data = naive_bayes
##############################

for index in range(len(answer)):
    naive_bayes_sent_responses[test_link_sent_numbers[index]].append(naive_bayes[index])
    nrtm_custom_sent_responses[test_link_sent_numbers[index]].append(nrtm_custom[index])    
    answer_sent_responses[test_link_sent_numbers[index]].append(answer[index])    

print(len(answer))

# for sent_no in range(1, 7):
#     print(sent_no)
#     nrtm_res = precision_recall_fscore_support(answer_sent_responses[sent_no], nrtm_custom_sent_responses[sent_no])
#     nb_res = precision_recall_fscore_support(answer_sent_responses[sent_no], naive_bayes_sent_responses[sent_no])
#     print(nrtm_res)
#     print(nb_res)
#     print("%d & %.2f/%.2f/%.2f & %.2f/%.2f/%.2f & %.2f/%.2f/%.2f & %.2f/%.2f/%.2f \\\\" % (sent_no, nb_res[0][0], nb_res[1][0], nb_res[2][0], nrtm_res[0][0], nrtm_res[1][0], nrtm_res[2][0],
#                                                                                            nb_res[0][1], nb_res[1][1], nb_res[2][1], nrtm_res[0][1], nrtm_res[1][1], nrtm_res[2][1]))
    # print("%.2f/%.2f/%.2f/%d" % precision_recall_fscore_support(answer_sent_responses[sent_no], feature_set_sent_responses[sent_no]))
# print(sent_responses)

# print(test_link_sent_numbers)

indices_to_show = [index for index in range(len(answer)) if feature_set_data[index] != answer[index]]

test_link_pairs = [[int(e) for e in l.split()[0].split(":")] for l in open("test_link_data.txt", "r")]

# read in extracts
extracts = get_extracts()
all_extracts = extracts['train'] + extracts['dev'] + extracts['test']
extracts = all_extracts
# print("number of extracts:", len(extracts))
all_statements, all_contexts = get_all_statements_and_contexts_with_markings(extracts)
# print(len(all_contexts))

test_contexts = [[" ".join(all_contexts[pair[0]]), " ".join(all_contexts[pair[1]])] for pair in test_link_pairs]

# print(len(test_contexts))

# print(len(indices_to_show))

for index in range(len(answer)):
    if "//this//rr " in " ".join(test_contexts[index]).lower():
    # if naive_bayes[index] != nrtm_custom[index]:
        print(index, test_link_sent_numbers[index])
        print("Answer: %d, NB: %d, NRTM: %d" % (answer[index], naive_bayes[index], nrtm_custom[index]))
        print(test_contexts[index])
        print()


# DIFFERENCE
# ['//State - of - the - art Machine Translation ( MT ) systems//RR are still //far from being perfect//S .', 'In this paper , we present \\\\an application of the online learning paradigm to the IMT framework\\\\ .']    
