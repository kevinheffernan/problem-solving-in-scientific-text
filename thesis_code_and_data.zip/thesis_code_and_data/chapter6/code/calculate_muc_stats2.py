import re, numpy, scipy
from dataclasses import dataclass
from typing import Any
from nltk.metrics import AnnotationTask
from collections import defaultdict


@dataclass
class ProblemStatement:
    signal: dict
    condition: Any = None
    head: Any = None
    root: Any = None
    link_1: bool = False
    link_2: bool = False
    sentence_number: int = None


@dataclass
class SolutionStatement:
    solution: dict

    
def get_extracts():
    Kevin = "../dev/annotations/Kevin_dev.txt"
    Anna = "../dev/annotations/Anna_dev.txt"
    Patricia = "../dev/annotations/Patricia_dev.txt"    
    total_extracts = {}
    for i, annotator in enumerate([Kevin, Anna, Patricia]):
        extracts = []
        extract = []
        with open(annotator) as infile:
            for l in infile:
                line = l.strip()
                if line == "":
                    extracts.append(extract)
                    extract = []
                else:
                    extract.append(line)
        if i == 0: total_extracts['Kevin'] = extracts
        elif i == 1: total_extracts['Mam'] = extracts
        else: total_extracts['Patricia'] = extracts
    return total_extracts



def find_start_of_element(text, end_of_element):
    for j in range(end_of_element, -1, -1):
        if text[j].startswith("//"):
            start_of_element = j
            return start_of_element

        
def determine_element(i, text, direction):
    element = None
    condition = "[^ ]+//C" + ("L" if direction == "right" else "R")
    head = "[^ ]+//H" + ("L" if direction == "right" else "R")
    root = "[^ ]+//R" + ("L" if direction == "right" else "R") + "[^ ]*"
    signal = "[^ ]+//S[^ ]*"
    if re.match(condition, text[i]):
        element = 'condition'
    elif re.match(head, text[i]):
        element = 'head'
    elif re.match(root, text[i]):
        element = 'root'        
    elif re.match(signal, text[i]):
        element = 'signal'
    return element


def find_solution_statements(text, sent_no):
    statements = []
    next_signal_include_root = False
    previous_root = None
    for i, token in enumerate(text):
        if token.endswith("\\\\") or token.endswith("\\\\*") or token.endswith("\\\\**"):
            statements.append(SolutionStatement(solution = extract_basic_info_solution(text, i)))
    return statements


# from each element extract basic information
def extract_basic_info_solution(text, i):
    start_of_element = None
    for j in range(i, -1, -1):
        if text[j].startswith("\\\\"):
            start_of_element = j
            break    
    element_raw_text = " ".join(text[start_of_element : i+1])
    return {"raw": element_raw_text,
            "text": element_raw_text.split("\\\\")[1],
            "start": start_of_element,
            "end": i}


# from each element extract basic information
def extract_basic_info(text, i):
    start_of_element = find_start_of_element(text, i)
    element_raw_text = " ".join(text[start_of_element : i+1])
    return {"raw": element_raw_text,
            "text": element_raw_text.split("//")[1],
            "start": start_of_element,
            "end": i}


def search_right_of_signal(end, text, statement):
    for j in range(end+1, len(text)):
        if determine_element(j, text, None) == "signal":
            break
        elif determine_element(j, text, "right") in ["root", "head", "condition"]:
            if determine_element(j, text, "right") == "condition":
                statement.condition = extract_basic_info(text, j)
                statement.condition["direction"] = "left"
            elif determine_element(j, text, "right") == "head":
                statement.head = extract_basic_info(text, j)
                statement.head["direction"] = "left"
            elif determine_element(j, text, "right") == "root":
                statement.root = extract_basic_info(text, j)
                statement.root["direction"] = "left"                                
    return statement


def search_left_of_signal(start, text, statement):
    for j in range(start-1, -1, -1):
        if determine_element(j, text, None) == "signal":
            break
        elif determine_element(j, text, "left") in ["root", "head", "condition"]:
            if determine_element(j, text, "left") == "condition":
                statement.condition = extract_basic_info(text, j)
                statement.condition["direction"] = "right"
            elif determine_element(j, text, "left") == "head":
                statement.head = extract_basic_info(text, j)
                statement.head["direction"] = "right"
            elif determine_element(j, text, "left") == "root":
                statement.root = extract_basic_info(text, j)
                statement.root["direction"] = "right"                
    return statement


def find_statements(text, sent_no):
    statements = []
    next_signal_include_root = False
    previous_root = None
    for i, token in enumerate(text):
        if determine_element(i, text, None) == "signal":
            # new statement
            start_of_signal = find_start_of_element(text, i)
            signal_raw_text = " ".join(text[start_of_signal : i+1])
            link1, link2 = False, False
            if "**" in signal_raw_text.split("//")[2]:
                link2 = True
            if signal_raw_text.split("//")[2] in ["S**,*", "S*", "S*,**"]:
                link1 = True
            statement = ProblemStatement(signal = extract_basic_info(text, i))
            statement.link_1 = link1
            statement.link_2 = link2
            statement.sentence_number = sent_no
            statement = search_left_of_signal(start_of_signal, text, statement)                        
            statement = search_right_of_signal(i, text, statement)
            ## removing for now
            # # check for RR[1,2]
            # if next_signal_include_root:
            #     statement.root = previous_root
            #     next_signal_include_root = False
            # elif statement.root and "[" in statement.root["raw"].split("//")[2]:
            #     next_signal_include_root = True
            #     previous_root = statement.root                
            statements.append(statement)                        
    return statements


def determine_link_label(statement):
    if statement.link_2 and statement.link_1:
        return 3
    elif statement.link_2 and not statement.link_1:
        return 2
    elif statement.link_1 and not statement.link_2:
        return 1
    elif not statement.link_1 and not statement.link_2:
        return 0


def calculate_num_retrieved(statements_ann1, elem):
    num_retrieved = 0
    for s_ann1 in statements_ann1:
        # in case of link we always retrieve its status
        if elem == "link":
            num_retrieved += 1
        elif getattr(s_ann1, elem):
            num_retrieved += 1
    return num_retrieved


def get_bio_sentence(indices, sentence):
    bio_sentence = ["O"] * len(sentence)
    for start in indices:
        bio_sentence[start : indices[start][0]+1] = indices[start][1]
    print(bio_sentence)


# determines if overlap without taking element type into account
def determine_overlapping(s_ann1, s1_elem, statements_ann_2):
    elements = ["signal", "root", "head", "condition"]
    overlapping = False
    exact, incorrect, partial, missing = 0,0,0,0
    for s_ann2 in statements_ann_2:
        for s2_elem in elements:
            # confirm element exists in statement
            if getattr(s_ann2, s2_elem):
                # if an exact boundary match
                if bool(set(range(getattr(s_ann1, s1_elem)["start"], getattr(s_ann1, s1_elem)["end"]+1)) ==
                        set(range(getattr(s_ann2, s2_elem)["start"], getattr(s_ann2, s2_elem)["end"]+1))):
                    overlapping = True
                    # if same element type
                    if s1_elem == s2_elem:
                        # if signal then no direction so exact match
                        if s1_elem == "signal":
                            exact = 1
                        # otherwise if not signal and if same direction
                        elif getattr(s_ann1, s1_elem)["direction"] == getattr(s_ann2, s2_elem)["direction"]:
                            exact = 1
                        else:
                            incorrect = 1
                    # if not same element type
                    else:
                        incorrect = 1
                # if partial boundary match
                else:
                    if bool(set(range(getattr(s_ann1, s1_elem)["start"], getattr(s_ann1, s1_elem)["end"]+1)) &
                            set(range(getattr(s_ann2, s2_elem)["start"], getattr(s_ann2, s2_elem)["end"]+1))):
                        overlapping = True
                        # if same element type
                        if s1_elem == s2_elem:
                            # if signal then no direction so partial match
                            if s1_elem == "signal":
                                partial = 1
                            # otherwise if same direction
                            elif getattr(s_ann1, s1_elem)["direction"] == getattr(s_ann2, s2_elem)["direction"]:
                                partial = 1
                            else:
                                incorrect = 1
                        # if not same element type
                        else:
                            incorrect = 1
    if not overlapping:
        missing = 1
    # double-check not partial and incorrect
    if partial == 1 and incorrect == 1: incorrect = 0
    return [exact, partial, incorrect, missing]

    

def check_overlapping(s_ann1, s_ann2, elem, link=False, exact=True):
    overlapping = False
    # if element not present there was no overlap
    if (bool(getattr(s_ann1, elem)) ^ bool(getattr(s_ann2, elem))) or (not bool(getattr(s_ann1, elem)) and not bool(getattr(s_ann2, elem))):
        return False
    if exact:
        if bool(set(range(getattr(s_ann1, elem)["start"], getattr(s_ann1, elem)["end"]+1)) ==
            set(range(getattr(s_ann2, elem)["start"], getattr(s_ann2, elem)["end"]+1))):
            if link:
                # extra check for links
                if determine_link_label(s_ann1) == determine_link_label(s_ann2):                        
                    overlapping = True
            else:
                overlapping = True
    else:
        if bool(set(range(getattr(s_ann1, elem)["start"], getattr(s_ann1, elem)["end"]+1)) &
            set(range(getattr(s_ann2, elem)["start"], getattr(s_ann2, elem)["end"]+1))):
            if link:
                # extra check for links
                if determine_link_label(s_ann1) == determine_link_label(s_ann2):                        
                    overlapping = True
            else:
                overlapping = True        
    return overlapping


def calculate_num_relevant(statements_ann1, statements_ann2, elem, exact=True):
    num_relevant = 0
    for s_ann1 in statements_ann1:
        for s_ann2 in statements_ann2:
            if elem == "link":
                if check_overlapping(s_ann1, s_ann2, "signal", link=True, exact=False):
                    num_relevant += 1                
            elif getattr(s_ann1, elem) and getattr(s_ann2, elem):
                if check_overlapping(s_ann1, s_ann2, elem, link=False, exact=True):
                    num_relevant += 1
    return num_relevant
        

# annotator 2 is considered gold
def calculate_precision_recall(num_retrieved, num_relevant, ann1, ann2, elem):
    if elem == "solution":
        print(ann2, num_retrieved[ann2][elem])
    precision = num_relevant[ann1][ann2][elem] / num_retrieved[ann2][elem]
    recall = num_relevant[ann1][ann2][elem] / num_retrieved[ann1][elem]
    f_measure = 2 * ((precision * recall) / (precision + recall))
    return (precision, recall, f_measure)


def calculate_num_links(statements_ann1, ann1, sentence_number):
    for s_ann1 in statements_ann1:
        link_type = determine_link_label(k_statement)
        if link_type in [1,2]:
            links_per_sentence[ann1][sentence_number] += 1
        elif link_type == 3:
            links_per_sentence[ann1][sentence_number] += 2


def calculate_indices_of_elements(statements):
    indices = {}
    for statement in statements:
        indices[statement.signal["start"]] =  [statement.signal["end"], "S" + str(determine_link_label(statement))]
        if statement.root:
            indices[statement.root["start"]] = [statement.root["end"], "R" + ("L" if statement.root["direction"] == "left" else "R")]
        if statement.head:
            indices[statement.head["start"]] = [statement.head["end"], "H" + ("L" if statement.head["direction"] == "left" else "R")]
        if statement.condition:
            indices[statement.condition["start"]] = [statement.condition["end"], "C" + ("L" if statement.condition["direction"] == "left" else "R")]
    return indices


def get_bio_notation(indices_of_elements, sentence):
    bio = []
    index = 0
    while index < len(sentence):
        if index in indices_of_elements:
            start = index
            bio.append("%s\tB-%s" % (sentence[index], indices_of_elements[start][1]))
            index += 1
            while index <= indices_of_elements[start][0]:
                bio.append("%s\tI-%s" % (sentence[index], indices_of_elements[start][1]))
                index += 1
        else:
            bio.append("%s\tO" % (sentence[index]))
            index += 1
    return bio


def calculate_differences(bio_notation):
    differences = {"Kevin:Mam": [], "Kevin:Patricia": [], "Mam:Patricia": []}
    for extract in bio_notation:
        for sentence in bio_notation[extract]:
            kevin_sentence = " ".join([e.split()[0] for e in bio_notation[extract][sentence]["Kevin"]])
            mam_sentence = " ".join([e.split()[0] for e in bio_notation[extract][sentence]["Mam"]])
            patricia_sentence = " ".join([e.split()[0] for e in bio_notation[extract][sentence]["Patricia"]])
            if kevin_sentence != mam_sentence:
                differences["Kevin:Mam"].append((kevin_sentence, mam_sentence))
            if kevin_sentence != patricia_sentence:
                differences["Kevin:Patricia"].append((kevin_sentence, patricia_sentence))
            if mam_sentence != patricia_sentence:
                differences["Mam:Patricia"].append((mam_sentence, patricia_sentence))                                                                                        
    return differences


def calculate_kappa_links(total_problem_statements):
    choices = {"Kevin:Mam": [], "Mam:Patricia": [], "Kevin:Patricia": [], "Kevin:Mam:Patricia": []}
    cumulative_token_no = {"Kevin:Mam": 0, "Kevin:Patricia": 0, "Mam:Patricia": 0}
    overlapping_statements = []
    for extract in total_problem_statements:
        for sentence in total_problem_statements[extract]:
            kevin_statements = total_problem_statements[extract][sentence]["Kevin"]
            mam_statements = total_problem_statements[extract][sentence]["Mam"]
            patricia_statements = total_problem_statements[extract][sentence]["Patricia"]
            for k_s in kevin_statements:
                for m_s in mam_statements:
                    # determine if signals are overlapping
                    if check_overlapping(k_s, m_s, "signal", link=False, exact=False):
                        cumulative_token_no["Kevin:Mam"] += 1
                        choices["Kevin:Mam"].append(("Kevin", cumulative_token_no["Kevin:Mam"], determine_link_label(k_s)))
                        choices["Kevin:Mam"].append(("Mam", cumulative_token_no["Kevin:Mam"], determine_link_label(m_s)))                    
                for p_s in patricia_statements:
                    # determine if signals are overlapping
                    if check_overlapping(k_s, p_s, "signal", link=False, exact=False):
                        cumulative_token_no["Kevin:Patricia"] += 1
                        choices["Kevin:Patricia"].append(("Kevin", cumulative_token_no["Kevin:Patricia"], determine_link_label(k_s)))
                        choices["Kevin:Patricia"].append(("Patricia", cumulative_token_no["Kevin:Patricia"], determine_link_label(p_s)))
            for m_s in mam_statements:
                for p_s in patricia_statements:
                    # determine if signals are overlapping
                    if check_overlapping(p_s, m_s, "signal", link=False, exact=False):
                        cumulative_token_no["Mam:Patricia"] += 1
                        choices["Mam:Patricia"].append(("Mam", cumulative_token_no["Mam:Patricia"], determine_link_label(m_s)))
                        choices["Mam:Patricia"].append(("Patricia", cumulative_token_no["Mam:Patricia"], determine_link_label(p_s)))
            for m_s in mam_statements:
                for p_s in patricia_statements:
                    for k_s in kevin_statements:
                        if check_overlapping(k_s, m_s, "signal", link=False, exact=False) and check_overlapping(k_s, p_s, "signal", link=False, exact=False) and check_overlapping(m_s, p_s, "signal", link=False, exact=False):
                            overlapping_statements.append((k_s, m_s, p_s))
    for i,overlap in enumerate(overlapping_statements):
        k_s = overlap[0]
        m_s = overlap[1]
        p_s = overlap[2]        
        choices["Kevin:Mam:Patricia"].append(("Kevin", i, determine_link_label(k_s)))
        choices["Kevin:Mam:Patricia"].append(("Mam", i, determine_link_label(m_s)))
        choices["Kevin:Mam:Patricia"].append(("Patricia", i, determine_link_label(p_s)))                
    print("link kappas")
    task = AnnotationTask(data = choices["Kevin:Mam"])
    print("Kevin/Mam:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Mam"])/2)
    task = AnnotationTask(data = choices["Kevin:Patricia"])
    print("Kevin/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Patricia"])/2)
    task = AnnotationTask(data = choices["Mam:Patricia"])
    print("Mam/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Mam:Patricia"])/2)
    task = AnnotationTask(data = choices["Kevin:Mam:Patricia"])
    print("Kevin/Mam/Patricia:", "%.2f" % task.kappa(), "no instances:", len(choices["Kevin:Mam:Patricia"])/3)

    
def calculate_kappa_bio(bio, indicator, solution=False, all_problem=False, all_solution_problem=False):
    choices = {"Kevin": [], "Mam": [], "Patricia": []}
    cumulative_token_no = {"Kevin": 0, "Mam": 0, "Patricia": 0}
    for extract in bio_notation:
        for sentence in bio_notation[extract]:
            for annotator in bio_notation[extract][sentence]:
                # only take the second bit of info i.e., not the word
                for token in bio_notation[extract][sentence][annotator]:
                    cumulative_token_no[annotator] += 1
                    bio_token = token.split()[1]
                    if solution:
                        if sentence == 6: 
                            if bio_token != "O" and not bio_token.split("-")[1].startswith("E+"):
                                bio_token = "O"
                            choices[annotator].append(('%s' % annotator, str(cumulative_token_no[annotator]), bio_token))
                    elif all_problem:
                        if bio_token != "O" and bio_token.split("-")[1].startswith("E+"):
                            bio_token = "O"
                        choices[annotator].append(('%s' % annotator, str(cumulative_token_no[annotator]), bio_token))
                    elif all_solution_problem:
                        choices[annotator].append(('%s' % annotator, str(cumulative_token_no[annotator]), bio_token))                                                    
                    else:
                        if bio_token != "O" and not bio_token.split("-")[1].startswith(indicator):
                            bio_token = "O"                        
                        choices[annotator].append(('%s' % annotator, str(cumulative_token_no[annotator]), bio_token))
    print(cumulative_token_no)
    task = AnnotationTask(data = choices["Kevin"] + choices["Mam"])
    print("Kevin/Mam:", "%.2f" % task.kappa(), "Num instances:", len(choices["Kevin"]))
    task = AnnotationTask(data = choices["Kevin"] + choices["Patricia"])
    print("Kevin/Patricia:", "%.2f" % task.kappa(), "Num instances:", len(choices["Kevin"]))
    task = AnnotationTask(data = choices["Patricia"] + choices["Mam"])
    print("Patricia/Mam:", "%.2f" % task.kappa(), "Num instances:", len(choices["Kevin"]))
    task = AnnotationTask(data = choices["Patricia"] + choices["Mam"] + choices["Kevin"])
    print("All three:", "%.2f" % task.multi_kappa(), "Num instances:", len(choices["Kevin"]))
                

extracts = get_extracts()
    
# for bio notation
indices_of_elements = defaultdict(lambda : defaultdict(dict))
bio_sentences = defaultdict(lambda : defaultdict(dict))
bio_notation = defaultdict(lambda : defaultdict(dict))
total_problem_statements = defaultdict(lambda : defaultdict(dict))
total_solution_statements = defaultdict(lambda : defaultdict(dict))            
    

for extract in range(100):
    sentence_number = 0
    # extracts removed
    # if extract in [7, 24, 25, 28, 31, 35, 39, 60, 73, 91, 105]:
    #     continue
    for sentence in range(len(extracts['Kevin'][extract])):
        # ignore extract id
        if sentence == 0:
            continue
        sentence_number += 1

        # get statements first and calculate num retrieved
        problem_statements = defaultdict(lambda : defaultdict(dict))
        solution_statements = defaultdict(lambda : defaultdict(dict))                
        for annotator in ["Kevin", "Mam", "Patricia"]:
            annotator_sent = extracts[annotator][extract][sentence].split()
            problem_statements[annotator] = find_statements(annotator_sent, sentence_number)
            total_problem_statements[extract][sentence_number][annotator] = [problem_statements[annotator], annotator_sent]
            indices_of_elements[extract][sentence_number][annotator] = calculate_indices_of_elements(problem_statements[annotator])            
            if sentence_number == 6:
                solution_statements[annotator] = find_solution_statements(annotator_sent, sentence_number)
                total_solution_statements[extract][sentence_number][annotator] = [solution_statements[annotator], annotator_sent]
                for solution_statement in solution_statements[annotator]:
                    indices_of_elements[extract][sentence_number][annotator][solution_statement.solution["start"]] =  [solution_statement.solution["end"], "E+"]
            bio_notation[extract][sentence_number][annotator] = get_bio_notation(indices_of_elements[extract][sentence_number][annotator], annotator_sent)

same_links = dict()


# removes B/I and direction. leaves only one element letter for simple comparison
def get_simple_bio(sent_bio, elem):
    simple_bio = []
    for index, token in enumerate(sent_bio):
        bio_info = token.split("\t")[1]
        if len(bio_info.split("-"))==2:
            e = bio_info.split("-")[1][0]
            if e != elem:
                simple_bio.append("O")
            else:
                simple_bio.append(elem)                
        else:
            simple_bio.append("O")
    return simple_bio


# special simple bio for linking
def get_link_bio(sent_bio):
    link_bio = []
    for index, token in enumerate(sent_bio):
        bio_info = token.split("\t")[1]
        if len(bio_info.split("-"))==2:
            e = bio_info.split("-")[1][0]
            if e != "S":
                link_bio.append("O")
            else:
                link_bio.append(bio_info.split("-")[1])                
        else:
            link_bio.append("O")
    return link_bio    


# returns indices where both elements begin to overlap on an element
def calculate_overlaps(sent1, sent2, elem):
    index = 0
    overlaps = []
    while index < len(sent1):
        if sent1[index] == elem and sent2[index] == elem:
            overlap = []                
            while sent1[index] == elem and sent2[index] == elem:
                overlap.append(index)
                index += 1
                if index >= len(sent1): break                
            overlaps.append(overlap)
        else:
            index += 1
    return overlaps


# returns number of elements of type using simple bio
def calculate_num_elements(sent, elem):
    index = 0
    num_elements = 0
    while index < len(sent):
        if sent[index] == elem:
            num_elements += 1
            while sent[index] == elem:
                index += 1
                if index >= len(sent): break
        else:
            index += 1
    return num_elements


# checks whether the element has exact overlap or not
def element_is_different(sent1, sent2, elem):
    different = False
    index = 0
    while index < len(sent1):
        if sent1[index] == elem and sent2[index] == elem:
            while sent1[index] == sent2[index]:
                index += 1
                if index >= len(sent1): break
                if sent1[index] != sent2[index]:
                    different = True
                    break
        else:
            index += 1
    return different  
            

# # check for elements with no overlap
# def check_no_overlap(sent1, sent2, elem):
#     num_no_overlap = 0
#     index = 0
#     prev_in_element1 = False
#     prev_in_element2 = False
#     cur_in_element1 = False
#     cur_in_element2 = False
#     while index < len(sent1):
#         prev_in_element1 = cur_in_element1
#         prev_in_element2 = cur_in_element2
#         cur_in_element1 = True if sent1[index] == elem else False            
#         cur_in_element2 = True if sent2[index] == elem else False
#         if not cur_in_element1 and 
#         if (cur_in_element1 ^ cur_in_element2) and (prev_in_element1 ^ prev_in_element2):
#             num_no_overlap += 1
#         index += 1
#     return num_no_overlap

# def check_overlap(statements_1, statements_2, elem):
#     num_no_overlap = {0: [], 1: []}
    
#     for s_ann1 in statements_1:
#         for s_ann2 in statements_2:
            
#             if bool(set(range(getattr(s_ann1, elem)["start"], getattr(s_ann1, elem)["end"]+1)) &
#                 set(range(getattr(s_ann2, elem)["start"], getattr(s_ann2, elem)["end"]+1))):
#                 overlap += 
#             else:

        

# in sentence find how many signals were marked then determine how many a and b overlapped on and how many they didn't and average difference in overlap + variance

statement_info = defaultdict(lambda : defaultdict(lambda: defaultdict(dict)))
# d = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
for ann1 in ["Kevin","Mam","Patricia"]:
    for ann2 in ["Kevin","Mam","Patricia"]:
        if ann1 == ann2: continue
        for typ in ["exact", "partial", "incorr", "missing"]:
            for elem in ["signal", "root", "head", "condition"]:
                statement_info[ann1][ann2][typ][elem] = 0

# statement_info = defaultdict(lambda : defaultdict(dict))            

num_total_statements_k = 0
for extract in bio_notation:
    for sentence_number in bio_notation[extract]:
        # kevin = get_simple_bio(bio_notation[extract][sentence_number]['Kevin'], "S")
        # mam = get_simple_bio(bio_notation[extract][sentence_number]['Mam'], "S")
        # patricia = get_simple_bio(bio_notation[extract][sentence_number]['Patricia'], "S")

        kevin = total_problem_statements[extract][sentence_number]["Kevin"][0]
        mam = total_problem_statements[extract][sentence_number]["Mam"][0]
        patricia = total_problem_statements[extract][sentence_number]["Patricia"][0]


        kevin_sent = total_problem_statements[extract][sentence_number]["Kevin"][1]
        mam_sent = total_problem_statements[extract][sentence_number]["Mam"][1]
        patricia_sent = total_problem_statements[extract][sentence_number]["Patricia"][1]

        for ann1 in ["Kevin","Mam","Patricia"]:
            for ann2 in ["Kevin","Mam","Patricia"]:
                if ann1 == ann2: continue
                for ann1_statement in total_problem_statements[extract][sentence_number][ann1][0]:
                    for elem in ["signal", "root", "head", "condition"]:
                        ann2_statements = total_problem_statements[extract][sentence_number][ann2][0]
                        # if annotator 1 has that elem in the statement
                        if getattr(ann1_statement, elem):
                            stats = determine_overlapping(ann1_statement, elem, ann2_statements)
                            if ann1 in ["Kevin","Mam"] and ann2 in ["Mam","Kevin"] and elem == "signal":
                                if stats[1] == 1:
                                    print("\nPARTIAL MATCH BETWEEN MYSELF AND MAM\n")
                                    print("GOLD ANN.:", ann1)
                                    print("ELEM", elem)                                
                                    print("ann1 statement", ann1_statement)
                                    print("ann2 statements", ann2_statements)
                                    print(stats)                                    

                            if sum(stats) > 1:
                                print("SUM GREATER THAN 1")
                                print("ANN 1:", ann1)
                                print("ELEM", elem)                                
                                print("ann1 statement", ann1_statement)
                                print("ann2 statements", ann2_statements)
                                print(stats)
                            statement_info[ann1][ann2]["exact"][elem] += stats[0]
                            statement_info[ann1][ann2]["partial"][elem] += stats[1]
                            statement_info[ann1][ann2]["incorr"][elem] += stats[2]
                            statement_info[ann1][ann2]["missing"][elem] += stats[3]

print("SIGNAL INFORMATION FOR ME\n")                            
print(statement_info["Kevin"]["Mam"]["exact"]["signal"])
print(statement_info["Kevin"]["Mam"]["partial"]["signal"])
print(statement_info["Kevin"]["Mam"]["incorr"]["signal"])
print(statement_info["Kevin"]["Mam"]["missing"]["signal"])


                
        # # mam is gold
        # for statement_k in kevin:
        #     num_total_statements_k += 1
        #     for elem in ["signal", "root", "head", "condition"]:
        #         # confirm element exists in gold statement
        #         if getattr(statement_k, elem):
        #             # print("elem:", elem)                    
        #             # determine stats for that element in statement
        #             stats = determine_overlapping(statement_k, elem, mam)
        #             statement_info["exact"][elem] += stats[0]
        #             statement_info["partial"][elem] += stats[1]
        #             statement_info["(a->b)"][elem] += stats[2]
        #             statement_info["missing"][elem] += stats[3]
        # for statement_m in mam:
        #     for elem in ["signal", "root", "head", "condition"]:
        #         # confirm element exists in gold statement
        #         if getattr(statement_m, elem):            
        #             stats = determine_overlapping(statement_m, elem, kevin)
        #             statement_info["(b->a)"][elem] += stats[2]                    
        #             # print("exact:", stats[0])
        #             # print("partial:", stats[1])
        #             # print("incorrect:", stats[2])
        #             # print("missing:", stats[3])
        #             # print(" ".join(kevin_sent))
        #             # print(" ".join(mam_sent))

total_outputs = defaultdict(lambda : defaultdict(lambda: defaultdict(dict)))        
# total_outputs = []
for ann1 in statement_info:
    for ann2 in statement_info[ann1]:
        if ann1 == ann2: continue
        total_outputs[ann1][ann2] = []
        print("%s/%s" % (ann1, ann2) + "\t" + "\t&\t".join(["S","R","H","C"]))
        for typ in statement_info[ann1][ann2]:
            outputs = []
            for elem in statement_info[ann1][ann2][typ]:
                outputs.append(statement_info[ann1][ann2][typ][elem])
            total_outputs[ann1][ann2].append([typ] + outputs + [sum(outputs)])
            print("{\\bf " + typ + "}" + "\t&\t" + "\t&\t".join([str(o) for o in outputs] + [str(sum(outputs))]))
            # print incorrect from the other annotator's perspective
            # if typ=="incorr":
            #     outputs = []
            #     for elem in statement_info[ann2][ann1][typ]:
            #         outputs.append(statement_info[ann2][ann1][typ][elem])
            #     total_outputs[ann1][ann2].append([typ] + outputs + [sum(outputs)])
            #     print("{\\bf " + typ + " (%s is gold)}" % (ann2) + "\t&\t" + "\t&\t".join([str(o) for o in outputs] + [str(sum(outputs))]))
        # outputs = []
        # for elem in statement_info[ann2][ann1]["missing"]:
        #     outputs.append(statement_info[ann2][ann1][typ][elem])
        # total_outputs[ann1][ann2].append([typ] + outputs + [sum(outputs)])
        print("{\\bf spurious}" + "\t&\t" + "\t&\t".join([str(o) for o in outputs] + [str(sum(outputs))]))                
        print()

print("TOTAL OUTPUTS\n")
print(total_outputs["Kevin"]["Mam"])

        
for ann1 in total_outputs:
    for ann2 in total_outputs[ann1]:
        if ann1 == ann2: continue
        print(ann1 + "/" + ann2)
        for l in total_outputs[ann1][ann2]:
            row_sum = l[-1]
            # transpose list and then sum the colums
            cols = list(zip(*[output[1:] for output in total_outputs[ann1][ann2]]))
            # # print("cols")
            # print(cols)
            # print("cols",cols)
            col_sums = [sum(o) for o in cols]
            # print("col_sums:", col_sums)            
            print("{\\bf %s}" % (l[0]) + "\t&\t" + "\t&\t".join([str(o)+" & (%02d/%02d)" % (100*(round(o/col_sums[i],2)), 100*(round(o/row_sum, 2))) for i,o in enumerate(l[1:-1])] + [str(l[-1]) + " & (%02d)" % (100*round(l[-1]/col_sums[-1], 2))])+"\\\\")
        print("Total:" + "\t\t&\t" + "\t\t&\t".join([str(o) for o in col_sums])+"\\\\")
        print()
                    
#             found = False
#             for statement_m in mam:
#                 if check_overlapping(statement_k, statement_m, "root", link=False, exact=True):
#                     if statement_m.root["direction"] == statement_k.root["direction"]:
#                         statement_info["kevin"]["mam"]["exact"].append([statement_k, kevin_sent, mam_sent])
#                     else:
#                         statement_info["kevin"]["mam"]["incorrect"].append([statement_k, kevin_sent, mam_sent])                        
#                     found = True
#                 elif check_overlapping(statement_k, statement_m, "root", link=False, exact=False):
#                     if statement_m.root["direction"] == statement_k.root["direction"]:
#                         statement_info["kevin"]["mam"]["partial"].append([statement_k, kevin_sent, mam_sent])
#                     else:
#                         statement_info["kevin"]["mam"]["incorrect"].append([statement_k, kevin_sent, mam_sent])                                            
#                     found = True
#             if not found:
#                 statement_info["kevin"]["mam"]["missing"].append([statement_k, kevin_sent, mam_sent])

#         for statement_m in mam:
#             found = False
#             for statement_k in kevin:
#                 if check_overlapping(statement_k, statement_m, "root", link=False, exact=True):
#                     found = True
#                 elif check_overlapping(statement_k, statement_m, "root", link=False, exact=False):
#                     found = True
#             if not found:
#                 statement_info["kevin"]["mam"]["spurious"].append([statement_m, kevin_sent, mam_sent])

                
# for p in statement_info["kevin"]["mam"]["spurious"]:
#     # print(p[0].signal["text"], " | ", p[1].signal["text"])
#     if p[0].root:
#         print(p[0].root["text"])    
#         print(" ".join(p[1]))
#         print(" ".join(p[2]))
#         print()
# print(num_total_statements_k)

        # kevin = get_link_bio(bio_notation[extract][sentence_number]['Kevin'])
        # mam = get_link_bio(bio_notation[extract][sentence_number]['Mam'])
        # patricia = get_link_bio(bio_notation[extract][sentence_number]['Patricia'])        
        
        # print(kevin)
        # print(mam)
        # print(patricia)
        # print(calculate_num_elements(kevin, "C"))
        # print(calculate_num_elements(kevin, "H"))
        # print(calculate_num_elements(kevin, "S"))                
        # print(calculate_overlaps(kevin, mam, "C"))
        # print(calculate_overlaps(mam, patricia, "S"))
        # print(kevin)
        # print(kevin)

        # if kevin != mam:
        #     print(" ".join(kevin))
        #     print(" ".join(mam))
        #     # print(" ".join(patricia));
        #     print(" ".join(total_problem_statements[extract][sentence_number]["Kevin"][1]))
        #     print(" ".join(total_problem_statements[extract][sentence_number]["Mam"][1]))
            # print(" ".join(total_problem_statements[extract][sentence_number]["Patricia"][1]))
            # print(" ".join(total_problem_statements[extract][6]["Kevin"][1]))            

        # if element_is_different(kevin, mam, "C"):
        # # if len(calculate_overlaps(kevin, mam, "C")) != calculate_num_elements(kevin, "C"):
        #     print(kevin)
        #     print(mam)
        #     print(total_problem_statements[extract][sentence_number]["Kevin"][1])
        #     print(total_problem_statements[extract][sentence_number]["Mam"][1])
            # break
    #     break
    # break

        
