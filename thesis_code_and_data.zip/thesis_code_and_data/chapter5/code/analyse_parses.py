from nltk.tree import Tree
import re
from gensim.models.word2vec import Word2Vec

words_from_parses=[line.strip() for line in open("5_sentences_before_verified_solutions","r")]

subtrees_to_try=open("subtree_candidates_from_parses_PROBLEMS","w")
words_from_subtrees=open("words_from_subtree_candidates_from_parses_PROBLEMS","w")

word2vec_model=Word2Vec.load("../MODELS/fuse_word2vec.model")

for index,line in enumerate(open("5_sentences_before_verified_solutions.parses","r")):
    sentence=line.strip()
    if sentence=="NON_SENTENCE":
        subtrees_to_try.write(sentence+"\n")
        words_from_subtrees.write(sentence+"\n")                
        continue
    try:
        t = Tree.fromstring(sentence)
    except:
        subtrees_to_try.write(sentence+"\n")
        words_from_subtrees.write(words_from_parses[index]+"\n")
        continue
    max_val_subtree,max_subtree=0,None
    for subtree in t.subtrees():
        subtree_val=0
        if subtree.label()=="S": continue
        for leaf in subtree.leaves():
            if leaf in word2vec_model:
                subtree_val+=word2vec_model.similarity(leaf,"poor")
        if max_val_subtree==None or subtree_val > max_val_subtree:
            (max_val_subtree,max_subtree)=(subtree_val,subtree)
    # print(re.sub("[ ]+"," ",str(max_subtree).replace("\n","")))
    # for some reason a max subtree isn't found in some cases
    if not max_subtree:
        subtrees_to_try.write(sentence+"\n")
        words_from_subtrees.write(words_from_parses[index]+"\n")        
    else:
        subtrees_to_try.write(re.sub("[ ]+"," ",str(max_subtree).replace("\n",""))+"\n")
        words_from_subtrees.write(" ".join(list(max_subtree.leaves()))+"\n")        
    # print(len(list(max_subtree.leaves())),len(list(t.leaves())))
