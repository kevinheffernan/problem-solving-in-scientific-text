import spacy
from benepar.spacy_plugin import BeneparComponent

def prevent_sentence_boundary_detection(doc):
    for token in doc:
        # This will entirely disable spaCy's sentence detection
        token.is_sent_start = False
    return doc

nlp = spacy.load('en')
nlp.add_pipe(prevent_sentence_boundary_detection, name='prevent-sbd', before='parser')
nlp.add_pipe(BeneparComponent('benepar_en'))

outfile=open("5_sentences_before_verified_solutions.parses","w")

for index,line in enumerate(open("5_sentences_before_verified_solutions","r")):
    print("Instance:",index)
    if line.strip()=="NON_SENTENCE":
        outfile.write(line.strip()+"\n")
    else:
        doc=nlp(line.strip())
        sent = list(doc.sents)[0]
        outfile.write(sent._.parse_string+"\n")    

