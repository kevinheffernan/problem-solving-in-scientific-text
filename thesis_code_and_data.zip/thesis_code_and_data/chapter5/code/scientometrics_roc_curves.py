from sklearn.metrics import roc_curve, auc, accuracy_score
import csv
import matplotlib.pyplot as plt

with open("naive_bayes_solution_outputs.csv") as fp:
    reader = csv.reader(fp, delimiter=",", quotechar='"')
    next(reader, None)  # skip the headers
    nb_problem_predictions = [row for row in reader]

with open("scientometrics_solution_smo.csv") as fp:
    reader = csv.reader(fp, delimiter=",", quotechar='"')
    next(reader, None)  # skip the headers
    svm_problem_predictions = [row for row in reader]

with open("scientometrics_solution_logistic.csv") as fp:
    reader = csv.reader(fp, delimiter=",", quotechar='"')
    next(reader, None)  # skip the headers
    lr_problem_predictions = [row for row in reader]        

# with open("scientometrics_solution_output_predictions_ids.csv") as fp:
#     reader = csv.reader(fp, delimiter=",", quotechar='"')
#     next(reader, None)  # skip the headers
#     solution_predictions = [row for row in reader]    

# for no, label, prediction, error, _, ID, in solution_predictions:
#     if label == '1:solution' and label != prediction:
#         print(label, prediction)
#         print(problem_data[int(ID)-1])

y_labels, y_preds = [], []
for no, label, prediction, error, predicted, ID in nb_problem_predictions:
    y_labels.append([ID, (1 if label == '1:solution' else 0)])
    y_preds.append([ID, (float(predicted) if prediction == '1:solution' else 1-float(predicted))])
y_true = [x[1] for x in sorted(y_labels)]
y_score = [x[1] for x in sorted(y_preds)]
print(accuracy_score(y_true, [1 if p>=0.5 else 0 for p in y_score]))
fpr, tpr, thresholds = roc_curve(y_true, y_score)
roc_auc = auc(fpr, tpr)
# Plot ROC curve
plt.plot(fpr, tpr, label='NB (area = %0.3f)' % roc_auc)


y_labels, y_preds = [], []
for no, label, prediction, error, predicted, ID in svm_problem_predictions:
    y_labels.append([ID, (1 if label == '1:solution' else 0)])
    y_preds.append([ID, (float(predicted) if prediction == '1:solution' else 1-float(predicted))])
y_true = [x[1] for x in sorted(y_labels)]
y_score = [x[1] for x in sorted(y_preds)]
print(accuracy_score(y_true, [1 if p>=0.5 else 0 for p in y_score]))
fpr, tpr, thresholds = roc_curve(y_true, y_score)
roc_auc = auc(fpr, tpr)
# Plot ROC curve
plt.plot(fpr, tpr, label='SVM (area = %0.3f)' % roc_auc)

y_labels, y_preds = [], []
for no, label, prediction, error, predicted, ID in lr_problem_predictions:
    y_labels.append([ID, (1 if label == '1:solution' else 0)])
    y_preds.append([ID, (float(predicted) if prediction == '1:solution' else 1-float(predicted))])
y_true = [x[1] for x in sorted(y_labels)]
y_score = [x[1] for x in sorted(y_preds)]
print(accuracy_score(y_true, [1 if p>=0.5 else 0 for p in y_score]))
fpr, tpr, thresholds = roc_curve(y_true, y_score)
roc_auc = auc(fpr, tpr)
# Plot ROC curve
plt.plot(fpr, tpr, label='LR (area = %0.3f)' % roc_auc)

## Compute fpr, tpr, thresholds and roc auc
# fpr, tpr, thresholds = roc_curve(y_true, y_score)
# roc_auc = auc(fpr, tpr)



# print(fpr)
# print(list(fpr))

# # Plot ROC curve
# plt.plot(fpr, tpr, label='ROC curve (area = %0.3f)' % roc_auc)
# plt.plot([float(x) for x in fpr], [float(x) for x in tpr], label='ROC curve')
plt.plot([0.0, 1.0], [0.0, 1.0], 'k--', label='Random choice')  # random predictions curve
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")
plt.savefig('test_output.png')


