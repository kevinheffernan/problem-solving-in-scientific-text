# this takes the confirmed aims and then outputs all the previous 5 sentences

info_of_solutions=[line.split() for line in open("aims_at_least_5_from_header.txt","r")]

indices_of_confirmed_solutions=[int(line.strip().split()[0])-1 for line in open("predicted_solutions.txt","r")]

confirmed_solutions=[info_of_solutions[index] for index in indices_of_confirmed_solutions]

print(confirmed_solutions[0:10])
