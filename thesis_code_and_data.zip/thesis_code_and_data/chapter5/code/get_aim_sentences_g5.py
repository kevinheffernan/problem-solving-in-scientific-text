# get the text for the aim sentences which are >= 5 from a section header

outfile=open("aims_at_least_5_from_header_sents.txt","w")
outfile2=open("indices_of_g5_sents.txt","w")
all_aim_sentences_ids_g5=set(line for line in open("aims_at_least_5_from_header.txt","r"))
all_sentences={index:line for index,line in enumerate(open("all_aim_sentences.txt","r"))}
sentence_indices=[]
for index,line in enumerate(open("all_aim_sentences_ids.txt","r")):
    if line in all_aim_sentences_ids_g5:
        outfile2.write("%s\n" % index)
        outfile.write(all_sentences[index])

