import csv

with open("scientometrics_problem_output_predictions_ids.csv") as fp:
    reader = csv.reader(fp, delimiter=",", quotechar='"')
    next(reader, None)  # skip the headers
    problem_predictions = [row for row in reader]

with open("scientometrics_solution_output_predictions_ids.csv") as fp:
    reader = csv.reader(fp, delimiter=",", quotechar='"')
    next(reader, None)  # skip the headers
    solution_predictions = [row for row in reader]    

problem_data = [line.strip() for line in open("scientometrics_problem_data.txt", "r")]
solution_data = [line.strip() for line in open("scientometrics_solution_data.txt", "r")]

# for no, label, prediction, error, _, ID, in problem_predictions:
#     if label == '1:problem' and label != prediction:
#         # print(label, prediction)
#         print(problem_data[int(ID)-1])
    
# for no, label, prediction, error, _, ID in problem_predictions:
#     if label == '2:non_problem' and label != prediction:
#         # print(label, prediction)
#         print(problem_data[int(ID)-1])        

# for no, label, prediction, error, _, ID, in solution_predictions:
#     if label == '1:solution' and label != prediction:
#         # print(label, prediction)
#         print(solution_data[int(ID)-1])
    
for no, label, prediction, error, _, ID in solution_predictions:
    if label == '2:non_solution' and label != prediction:
        # print(label, prediction)
        print(solution_data[int(ID)-1])        
        

