# does a fuzzy match to find the string from the scixml in the parscit file

from lxml import etree
from fuzzywuzzy import fuzz

def get_header():
    headers=[]
    for index,line in enumerate(open("aims_at_least_5_from_header.txt","r")):
        filename,sent_id=line.strip().split()
        if sent_id.startswith("A-"):
            headers.append("abstract")
        else:
            sentence_text="".join(etree.parse(filename).getroot().xpath('//S[@ID="%s"]' % sent_id)[0].itertext())
        filename_only=filename.split("/")[-1].split(".")[0]
        letter=filename_only[0]
        letter_number=filename_only.split("-")[0]
        parscit_sentences=etree.parse("/home/kevin/ACL-SSPLIT/%s/%s/%s-parscit.130908.xml" % (letter,letter_number,filename_only)).getroot().xpath("//S")
        mx=0
        closest=0
        for i,s in enumerate(parscit_sentences):
            ratio=fuzz.ratio(sentence_text,"".join(s.itertext()))
            if ratio > mx:
                mx=ratio
                closest=i
        parent=parscit_sentences[closest].getparent()
        while "genericHeader" not in parent.attrib:
            parent=parent.getprevious()
        headers.append(parent.get("genericHeader"))
        # print(parent.get("genericHeader"))
        # print(sentence_text)
        # print("".join(parscit_sentences[closest].itertext()))
    
