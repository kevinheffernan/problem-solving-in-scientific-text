import codecs as cd
import numpy as np
from nltk.wsd import lesk
from lxml import etree
from nltk.corpus import sentiwordnet as swn
from pywsd.utils import penn2morphy
from gensim.models.word2vec import Word2Vec
from nltk.stem import WordNetLemmatizer
from nltk.sentiment.util import mark_negation
from nltk import ngrams
from gensim.models.doc2vec import Doc2Vec
from weka import Weka
import sys
from fuzzywuzzy import fuzz

weka=Weka("/home/kevin/Downloads/weka-3-8-3/weka.jar","./","./")
lemmatizer=WordNetLemmatizer()

def load_data(label):
    data,tmp=[],[]
    for line in cd.open("5_sentences_before_verified_solutions.tag","r","utf-8").readlines():
        if line=="\n":
            data.append([tmp,label])
            tmp=[]
        else:
            try:
                word,pos=line.strip().split()
            except:
                print("error:",line)
                word=line.strip()
                pos="_SP"
            # special case for escape character
            if word=="\\": word="\\\\"
            tmp.append([word.lower(),pos])
    return data

def get_bow(data):
    bow_data=[]
    for words,label in data:
        lemmas={}
        for word,pos in words:
            lemma=lemmatizer.lemmatize(word)
            # ignore punctuation, numbers, conjunctions, prepositions, determiners and pronouns
            if lemma.isalpha() and pos[0:2] not in ["CC","IN","DT","PR","WP","WD"]:
                lemmas["lemma:"+lemma]=1
        bow_data.append([lemmas,label])
    return bow_data

def get_polarity(data):
    polarity=[]
    for index,(words,label) in enumerate(data):
        # head,pos=problem_heads[index]
        sentence = [word for word,pos in words]
        # synset = lesk(sentence,head,penn2morphy(pos))
        # polarities={"polarity_pos":float('-inf'),"polarity_neg":float('-inf')}
        # if synset:
        #     scores = swn.senti_synset(synset.name())
        #     if scores != None:
        #         if scores.pos_score() > polarities["polarity_pos"]:
        #             polarities["polarity_pos"] = scores.pos_score()
        #         if scores.neg_score() > polarities["polarity_neg"]:
        #             polarities["polarity_neg"] = scores.neg_score()
        polarities={}
        for word,pos in words:
            synset = lesk(sentence,word,penn2morphy(pos))
            if synset:        
                scores = swn.senti_synset(synset.name())
                if scores != None:
                    # if scores.pos_score() > polarities["polarity_pos"]:
                    #     polarities["polarity_pos"] = scores.pos_score()
                    # if scores.neg_score() > polarities["polarity_neg"]:
                    #     polarities["polarity_neg"] = scores.neg_score()
                    polarities[word+":polarity_pos"]=scores.pos_score()
                    polarities[word+":polarity_neg"]=scores.neg_score()
        # if polarities["polarity_pos"]==float("-inf"): polarities["polarity_pos"]=0
        # if polarities["polarity_neg"]==float("-inf"): polarities["polarity_neg"]=0
        polarity.append([polarities,label])
    return polarity

def get_word2vec_polarity(data):
    word2vec=[]
    word2vec_model=Word2Vec.load("../MODELS/fuse_word2vec.model")
    for index,(words,label) in enumerate(data):
        # head,pos=problem_heads[index]
        # polarities={"word2vec_polarity_excellent":float('-inf'),"word2vec_polarity_poor":float('-inf')}
        # if head in word2vec_model:
        #     for polarity in ["excellent","poor"]:
        #         polarities["word2vec_polarity_%s:%s"%(polarity,head)]=word2vec_model.similarity(head,polarity)
        polarities={}
        for word,pos in words:
            if word in word2vec_model:
                for polarity in ["excellent","poor"]:
                    polarities["word2vec_polarity_%s:%s"%(polarity,word)]=word2vec_model.similarity(word,polarity)
        #         for polarity in ["excellent","poor"]:
        #             if word2vec_model.similarity(word,polarity) > polarities["word2vec_polarity_%s"%polarity]:
        #                 polarities["word2vec_polarity_%s"%polarity]=word2vec_model.similarity(word,polarity)
        # for polarity in ["excellent","poor"]:
        #     if polarities["word2vec_polarity_%s"%polarity]==float("-inf"):
        #         polarities["word2vec_polarity_%s"%polarity]=0
        word2vec.append([polarities,label])
    return word2vec

def get_ngrams(data,ngram):
    ngram_data=[]
    for words,label in data:
        sentence=[word for word,pos in words]
        ngram_data.append([{" ".join(t):1 for t in ngrams(sentence,ngram)},label])
    return ngram_data

def get_adverbial_of_result(data):
    result_data=[]
    result_signals = ["thus","therefore","then","hence","so","consequently","as a result","accordingly","thereby","in consequence","as a consequence"]
    for words,label in data:
        result_dict={}
        sentence=" ".join([word for word,pos in words])
        for result in result_signals:
            if result in sentence:
                result_dict["result:%s" % result]=1
                result_dict["result:presence"]=1
        result_data.append([result_dict,label])
    return result_data

def get_contrast(data):
    contrast_data=[]
    contrast_signals=["however","but","nevertheless","nonetheless","still","yet","though","although","even so","despite that","in spite of that","anyway","anyhow","be that as it may","having said that","notwithstanding", "on the other hand"]
    for words,label in data:
        contrast_dict={}
        sentence=" ".join([word for word,pos in words])
        for contrast in contrast_signals:
            if contrast in sentence:
                contrast_dict["contrast:%s" % contrast]=1
                contrast_dict["contrast:presence"]=1
        contrast_data.append([contrast_dict,label])
    return contrast_data

def get_example(data):
    example_data=[]
    example_signals = ["e.g.","for instance","for example","example","such as","notably","like","in particular","namely","to illustrate"]
    for words,label in data:
        example_dict={}
        sentence=" ".join([word for word,pos in words])
        for example in example_signals:
            if example in sentence:
                example_dict["example:%s" % example]=1
                example_dict["example:presence"]=1
        example_data.append([example_dict,label])
    return example_data

def get_negation(data):
    negation_data=[]
    for words,label in data:
        negation_dict={}
        # this takes tokenization into account (e.g. n't will be found)
        sentence=[word for word,pos in words]
        for token in mark_negation(sentence):
            if "_NEG" in token:
                negation_dict["negation:presence"]=1
        negation_data.append([negation_dict,label])
    return negation_data

def normalize(vector):
    # normalize vectors between -1 and 1 inclusive
    norm=np.linalg.norm(vector)
    return vector if norm==0 else vector/norm

def get_discourse(data):
    discourse_data=[]
    lbl="?"
    for index,line in enumerate(open("aims_at_least_5_from_header.txt","r")):
        discourse={}
        filename,sent_id=line.strip().split()
        if sent_id.startswith("A-"):
            discourse["discourse:%s" % "abstract"]=1
            discourse["discourse:distance"]=int(sent_id.split("-")[1])
            discourse_data.append([discourse,lbl])
            continue
        else:
            sentence_text="".join(etree.parse(filename).getroot().xpath('//S[@ID="%s"]' % sent_id)[0].itertext())

        # get distance information
        sent=etree.parse(filename).getroot().xpath('.//S[@ID="%s"]' % sent_id)[0]
        # keep going to parent until I find the div
        tmp_element=sent
        while tmp_element.tag!="DIV":
            tmp_element=tmp_element.getparent()
        # now I should have div and need to get sent id of first sentence child
        first_sentence_id_in_div=tmp_element.xpath(".//S")[0].get("ID")
        discourse["discourse:distance"]=int(sent_id.split("-")[1]) - int(first_sentence_id_in_div.split("-")[1])

        # now find fuzzy match in parscit and get header type
        filename_only=filename.split("/")[-1].split(".")[0]
        letter=filename_only[0]
        letter_number=filename_only.split("-")[0]
        parscit_sentences=etree.parse("/home/kevin/ACL-SSPLIT/%s/%s/%s-parscit.130908.xml" % (letter,letter_number,filename_only)).getroot().xpath("//S")
        mx=0
        closest=0
        for i,s in enumerate(parscit_sentences):
            ratio=fuzz.ratio(sentence_text,"".join(s.itertext()))
            if ratio > mx:
                mx=ratio
                closest=i
        parent=parscit_sentences[closest].getparent()
        while "genericHeader" not in parent.attrib:
            parent=parent.getprevious()
        discourse["discourse:%s" % parent.get("genericHeader")]=1
        discourse_data.append([discourse,lbl])
    return discourse_data

# def get_discourse(data):
    
    # return [[{"discourse:introduction":1,"discourse:distance":5},"solution"]]*8392
    # discourse_data,file_data=[],[]
    # for prefix in ["","non_"]:
    #     sents=etree.parse("../Scientometrics/data/xml/%s%s.xml" % (prefix,label)).getroot().findall(".//SENT")
    #     file_data+=[(s.get("FILE"),s.get("SENT-ID"),prefix+label) for s in sents]
    # for filename,sent_id,lbl in file_data:
    #     filename=filename.replace("/home/kh562/","/anfs/bigdisc/kh562/Corpora_from_local/")
    #     discourse,sentence={},[]
    #     for element in ["S","A-S"]:
    #         sentence+=etree.parse(filename).getroot().findall(".//%s[@ID='%s']" % (element,sent_id))
    #     sentence=sentence[0]
    #     # get distance information
    #     header=sentence.getparent()
    #     first_child=header.getchildren()[0].get("ID")
    #     discourse["discourse:distance"]=int(sent_id.split("-")[1])-int(first_child.split("-")[1])
    #     # get section header
    #     while header!=None:
    #         if "genericHeader" in header.attrib:
    #             discourse["discourse:%s" % header.get("genericHeader")]=1
    #             break
    #         header=header.getprevious()
    #     discourse_data.append([discourse,lbl])
    # return discourse_data

def compute_combinations(features):
    print("number of features:",len(features))
    num_instances=len(features[0][0])
    for combination in range(1,1<<len(features)):
        # get binary representation of combination
        binary=[int(c) for c in bin(combination)[2:]]
        # get combination of features
        comb=[features[index] for index,c in enumerate([0]*(len(features)-len(binary))+binary) if c!=0]
        feature_names=[feature_name for feature,feature_name in comb]
        # combine dictionaries in combination
        combined_data=[]
        for i in range(0,num_instances):
            combined_dict={key:dictionary[key] for feature,feature_name in comb for dictionary,label in [feature[i]] for key in dictionary}
            label=features[0][0][i][1]
            if label not in ["problem","non_problem"]: print("error:",label)
            combined_data.append([combined_dict,label])
        label_type="problem_" if "problem" in feature_names[0] else "solution_"
        combined_feature_names="%s" % label_type+"_".join([feature_name.split("%s" % label_type)[1] for feature,feature_name in comb])
        weka.writeArff(combined_data,combined_feature_names)

def combine_features(features):
    for f in features: print(len(f[0]))
    print("number of features:",len(features))
    num_instances=len(features[0][0])
    feature_names=[feature_name for feature,feature_name in features]
    # combine dictionaries in combination
    combined_data=[]
    for i in range(0,num_instances):
        combined_dict={key:dictionary[key] for feature,feature_name in features for dictionary,label in [feature[i]] for key in dictionary}
        label="?"
        # if label not in ["problem","non_problem","solution","non_solution"]: print "error:",label
        combined_data.append([combined_dict,label])
    label_type="problem_" if "problem" in feature_names[0] else "solution_"
    combined_feature_names="%s" % label_type+"_".join([feature_name.split("%s" % label_type)[1] for feature,feature_name in features])
    weka.writeArff(combined_data,"TEST_PROBLEM_SEPTEMBER_2019_"+combined_feature_names)

# problem_data=load_data("problem")
# problem_data+=load_data("non_problem")
# problem_heads=[l.strip().split() for l in cd.open("problem_sentences_from_aims_to_screen_august_heads.txt","r","utf-8")]
# problem_heads+=[l.strip().split() for l in cd.open("../data/head/non_problem.txt","r","utf-8")]

solution_data=load_data("solution")
print("length of solution data:",len(solution_data))
solution_heads=[l.strip().split() for l in cd.open("5_sentences_before_verified_solutions.heads","r","utf-8")]
# solution_data+=load_data("non_solution")
# solution_heads=[l.strip().split() for l in cd.open("../data/head/solution.txt","r","utf-8")]
# solution_heads+=[l.strip().split() for l in cd.open("../data/head/non_solution.txt","r","utf-8")]

# get bag of words baseline
# problem_bow=get_bow(problem_data)
solution_bow=get_bow(solution_data)
# weka.writeArff(solution_bow,"solution_bow")

# get bigrams
# problem_bigrams=get_ngrams(problem_data,2)
# solution_bigrams=get_ngrams(solution_data,2)
# weka.writeArff(solution_bigrams,"solution_bigrams")

# get trigrams
# problem_trigrams=get_ngrams(problem_data,3)
solution_trigrams=get_ngrams(solution_data,2)
# weka.writeArff(solution_trigrams,"solution_trigrams")

# get contrast
# problem_contrast=get_contrast(problem_data)
# solution_contrast=get_ngrams(solution_data,2)
# weka.writeArff(solution_contrast,"solution_contrast")

# get example
# problem_example=get_example(problem_data)
# solution_example=get_ngrams(solution_data,2)
# weka.writeArff(solution_example,"solution_example")

# get adverbial of result
# solution_result=get_adverbial_of_result(solution_data)
# weka.writeArff(solution_result,"solution_result")

# get negation
# problem_negation=get_negation(problem_data)
# solution_negation=get_ngrams(solution_data,2)
# weka.writeArff(solution_negation,"solution_negation")

# get polarity
# problem_polarity=get_polarity(problem_data)
# solution_polarity=get_ngrams(solution_data,2)
# weka.writeArff(solution_polarity,"solution_polarity")

# get discourse
# problem_discourse=get_discourse("problem")
solution_discourse=get_discourse("solution")
# weka.writeArff(solution_discourse,"solution_discourse")

# get word2vec smoothed polarity
# problem_word2vecPolarity=get_word2vec_polarity(problem_data)
# solution_word2vecPolarity=get_word2vec_polarity(solution_data)
# weka.writeArff(solution_word2vecPolarity,"solution_word2vecPolarity")

# get syntax features
# problem_syntax=[[{"syntax:"+pos:1 for word,pos in words},label] for words,label in problem_data]
solution_syntax=[[{"syntax:"+pos:1 for word,pos in words},label] for words,label in solution_data]
# weka.writeArff(solution_syntax,"solution_syntax")

# doc2vec
doc2vecModel=Doc2Vec.load("../MODELS/acl_sent_doc2vec.model")
# problem_doc2vec=[[{"doc2vec:%s" % i:v for i,v in enumerate(normalize(doc2vecModel.infer_vector([word for word,pos in words])))},label] for words,label in problem_data]
solution_doc2vec=[[{"doc2vec:%s" % i:v for i,v in enumerate(normalize(doc2vecModel.infer_vector([word for word,pos in words])))},label] for words,label in solution_data]
# weka.writeArff(solution_doc2vec,"solution_doc2vec")

# word2vec
word2vec_model=Word2Vec.load("../MODELS/fuse_word2vec.model")
# problem_word2vec=[]
# for index,instance in enumerate(problem_data):
#     words,label=instance
#     head,pos=problem_heads[index]
#     try:
#         word2vec_vector={"word2vec:%s" % i:v for i,v in enumerate(normalize(word2vec_model[head]))}
#     except:
#         word2vec_vector={"word2vec:%s" %i:0 for i in range(0,100)}
#     problem_word2vec.append([word2vec_vector,label])

solution_word2vec=[]
for index,instance in enumerate(solution_data):
    words,label=instance
    head,pos=solution_heads[index]
    try:
        word2vec_vector={"word2vec:%s" % i:v for i,v in enumerate(normalize(word2vec_model[head]))}
    except:
        word2vec_vector={"word2vec:%s" %i:0 for i in range(0,100)}
    solution_word2vec.append([word2vec_vector,label])

# weka.writeArff(solution_word2vec,"solution_word2vec")

# modality
# modal_predictions=[pred.strip() for pred in cd.open("../data/modality/problems.txt","r","utf-8")]
# problem_modality=[[{"modality:%s" % t:1 for t in [modal_predictions[index]] if t!="None"},label] for index,(words,label) in enumerate(problem_data)]
# weka.writeArff(problem_modality,"problem_modality")

# transitivity

transitivity=[line.strip() for line in cd.open("words_from_subtree_candidates_from_parses_PROBLEMS.transitivity","r","utf-8")]
# problem_transitivity=[[{"transitivity:%s" % t:1 for t in transitivity[index].split() if t !="None"},label] for index,(words,label) in enumerate(problem_data)]
# transitivity=[line.strip() for line in cd.open("../data/transitivity/solutions.txt","r","utf-8")]
solution_transitivity=[[{"transitivity:%s" % t:1 for t in transitivity[index].split() if t !="None"},label] for index,(words,label) in enumerate(solution_data)]
# # weka.writeArff(solution_transitivity,"solution_transitivity")

# combine all features together
# combine_features([[solution_bow,"solution_bow"],[solution_word2vecPolarity,"solution_word2vecPolarity"]])
# combine_features([[solution_bow,"solution_bow"],[solution_word2vecPolarity,"solution_word2vec"]])
# combine_features([[solution_bow,"solution_bow"],[solution_word2vecPolarity,"solution_doc2vec"]])

# combine_features([[solution_bow,"solution_bow"],[solution_bigrams,"solution_bigrams"],[solution_trigrams,"solution_trigrams"],[solution_negation,"solution_negation"],[solution_word2vec,"solution_word2vec"],[solution_polarity,"solution_polarity"],[solution_example,"solution_example"],[solution_doc2vec,"solution_doc2vec"],[solution_word2vecPolarity,"solution_word2vecPolarity"],[solution_syntax,"solution_syntax"],[solution_transitivity,"solution_transitivity"],[solution_discourse,"solution_discourse"],[solution_result,"solution_result"]])

combine_features([[solution_bow,"solution_bow"],[solution_word2vec,"solution_word2vec"],[solution_trigrams, "solution_trigrams"],[solution_doc2vec,"solution_doc2vec"],[solution_syntax,"solution_syntax"],[solution_transitivity,"solution_transitivity"],[solution_discourse,"solution_discourse"]])

# combine_features([[solution_bow,"solution_bow"],[solution_negation,"solution_negation"],[solution_word2vec,"solution_word2vec"],[solution_polarity,"solution_polarity"],[solution_example,"solution_example"],[solution_doc2vec,"solution_doc2vec"],[solution_word2vecPolarity,"solution_word2vecPolarity"],[solution_syntax,"solution_syntax"],[solution_transitivity,"solution_transitivity"],[solution_discourse,"solution_discourse"],[solution_contrast,"solution_contrast"]])
# combine_features([[solution_bow,"solution_bow"],[solution_word2vec,"solution_word2vec"],[solution_polarity,"solution_polarity"],[solution_example,"solution_example"],[solution_doc2vec,"solution_doc2vec"],[solution_word2vecPolarity,"solution_word2vecPolarity"],[solution_syntax,"solution_syntax"],[solution_transitivity,"solution_transitivity"],[solution_discourse,"solution_discourse"],[solution_contrast,"solution_contrast"]])
# combine_features([[solution_bow,"solution_bow"],[solution_word2vec,"solution_word2vec"],[solution_example,"solution_example"],[solution_doc2vec,"solution_doc2vec"],[solution_word2vecPolarity,"solution_word2vecPolarity"],[solution_syntax,"solution_syntax"],[solution_transitivity,"solution_transitivity"],[solution_discourse,"solution_discourse"],[solution_contrast,"solution_contrast"]])
# combine_features([[solution_bow,"solution_bow"],[solution_word2vec,"solution_word2vec"],[solution_example,"solution_example"],[solution_doc2vec,"solution_doc2vec"],[solution_word2vecPolarity,"solution_word2vecPolarity"],[solution_syntax,"solution_syntax"],[solution_transitivity,"solution_transitivity"],[solution_contrast,"solution_contrast"]])
# combine_features([[solution_bow,"solution_bow"],[solution_word2vec,"solution_word2vec"],[solution_doc2vec,"solution_doc2vec"],[solution_word2vecPolarity,"solution_word2vecPolarity"],[solution_syntax,"solution_syntax"],[solution_transitivity,"solution_transitivity"],[solution_discourse,"solution_discourse"]])

# combine features
# combine_features([[problem_bow,"problem_bow"],[problem_negation,"problem_negation"],[problem_example,"problem_example"],[problem_discourse,"problem_discourse"],[problem_polarity,"problem_polarity"],[problem_transitivity,"problem_transitivity"],[problem_word2vec,"problem_word2vec"],[problem_doc2vec,"problem_doc2vec"],[problem_word2vecPolarity,"problem_word2vecPolarity"],[problem_syntax,"problem_syntax"]])











# # add polarity to bow
# polarity_bow=[[dict(problem_bow[index][0].items()+problem_polarity[index][0].items()),problem_bow[index][1]] for ex in range(0,len(problem_data))]
# weka.writeArff(polarity_bow,"problem_polarity_bow")

# add bag of words to word2vec smoothed polarity
# problem_word2vecPolarity_bow=[[dict(problem_word2vecPolarity[index][0].items()+problem_bow[index][0].items()),problem_bow[index][1]] for index in range(0,len(problem_data))]
# weka.writeArff(problem_word2vecPolarity_bow,"problem_word2vecPolarity_bow)"

