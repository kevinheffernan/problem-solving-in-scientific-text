import codecs,re

sentences = [s.strip() for s in codecs.open("aims_at_least_5_")]
