# checks to see if a problem was in a given instance

# also checks if there was a solution mentioned

contexts_with_problem=0
context_number_with_problem=set()
context=[]
num_contexts=0
for index,line in enumerate(open("test_august.pred","r")):
    if "1:problem" in line:
        context.append(1)
    else:
        context.append(0)
    if (index+1)%5==0:
        num_contexts+=1
        if 1 in context:
            contexts_with_problem+=1
            context_number_with_problem.add(num_contexts)
        context=[]

contexts_with_solution_and_problem=0
for index,line in enumerate(open("test_august_solutions.pred","r")):
    if "1:solution" in line:
        if index+1 in context_number_with_problem:
            contexts_with_solution_and_problem+=1

print(contexts_with_problem)
print(num_contexts)
print(contexts_with_solution_and_problem)
