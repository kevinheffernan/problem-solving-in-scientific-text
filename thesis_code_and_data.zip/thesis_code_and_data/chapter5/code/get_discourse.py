# file just to check that discourse information is being extracted correctly

from lxml import etree
from fuzzywuzzy import fuzz
 
def get_discourse(data):
    discourse_data=[]
    lbl="?"
    for index,line in enumerate(open("aims_at_least_5_from_header.txt","r")):
        discourse={}
        filename,sent_id=line.strip().split()
        if sent_id.startswith("A-"):
            discourse["discourse:%s" % "abstract"]=1
            discourse["discourse:distance"]=int(sent_id.split("-")[1])
            discourse_data.append([discourse,lbl])
            continue
        else:
            sentence_text="".join(etree.parse(filename).getroot().xpath('//S[@ID="%s"]' % sent_id)[0].itertext())

        # get distance information
        sent=etree.parse(filename).getroot().xpath('.//S[@ID="%s"]' % sent_id)[0]
        # keep going to parent until I find the div
        tmp_element=sent
        while tmp_element.tag!="DIV":
            tmp_element=tmp_element.getparent()
        # now I should have div and need to get sent id of first sentence child
        first_sentence_id_in_div=tmp_element.xpath(".//S")[0].get("ID")
        discourse["discourse:distance"]=int(sent_id.split("-")[1]) - int(first_sentence_id_in_div.split("-")[1])

        # now find fuzzy match in parscit and get header type
        filename_only=filename.split("/")[-1].split(".")[0]
        letter=filename_only[0]
        letter_number=filename_only.split("-")[0]
        parscit_sentences=etree.parse("/home/kevin/ACL-SSPLIT/%s/%s/%s-parscit.130908.xml" % (letter,letter_number,filename_only)).getroot().xpath("//S")
        mx=0
        closest=0
        for i,s in enumerate(parscit_sentences):
            ratio=fuzz.ratio(sentence_text,"".join(s.itertext()))
            if ratio > mx:
                mx=ratio
                closest=i
        parent=parscit_sentences[closest].getparent()
        while "genericHeader" not in parent.attrib:
            parent=parent.getprevious()
        discourse["discourse:%s" % parent.get("genericHeader")]=1
        discourse_data.append([discourse,lbl])
    return discourse_data


discourse=get_discourse([])
for instance,lbl in discourse:
    print(instance)
