extracts,extract=[],[]

for line in open("verified_extracts","r"):
    if line.strip()=="":
        extracts.append(extract)
        extract=[]
    else:
        extract.append(line.strip())        

extracts_text=[e[1:]for e in extracts]
print(len(extracts),len(extracts_text),len(set([" ".join(ex for ex in e) for e in extracts_text])))
print(len(set([e[0] for e in extracts])))

training_ids=["D08-1114, S-14",
"P13-2133, S-11",
"P05-1059, S-13",
"P09-1119, S-8",
"D11-1080, S-19",
"W98-1120, S-8",
"D11-1115, S-9",
"W09-1009, S-21",
"W14-0906, S-11",
"N06-1006, S-8",
"P10-1097, S-13",
"W06-0304, S-9",
"P06-1013, S-10",
"P12-1019, S-15",
"D15-1070, S-7",
"W06-2808, S-27",
"D11-1019, S-14",
"P03-1038, S-9",
"W13-5306, S-5",
"E12-1013, S-14",
"W00-1707, S-8",
"W00-1707, S-30",
"E06-1050, S-18",
"P05-1064, S-22",
"P05-3025, S-7",
"W14-3206, S-9",
"N09-3016, S-15",
"D14-1141, S-9",
"W15-1605, S-7",
"W97-0122, S-16",
"W98-1213, S-15",
"W06-3325, S-15",
"D09-1015, S-17",
"W11-4005, S-18",
"Q13-1017, S-9",
"P09-1120, S-12",
"W10-2608, S-20",
"P11-4018, S-7",
"P14-1019, S-14",
"W11-4416, S-15",
"W14-3628, S-20",
"S14-2029, S-7",
"P15-1017, S-30",
"P06-2073, S-35",
"P08-2048, S-11"]

training_ids=[" ".join(e.split(", ")) for e in training_ids]

print(len(training_ids))
ids=set([e[0] for e in extracts])

overlap=0
for i in training_ids:
    if i in ids: overlap+=1
print(overlap)
print(len(set([e[0] for e in extracts])-set(training_ids)))
