# code to check how many AIMs are at least 5 sentences from a section header

from lxml import etree

num_5_away=0
num_less=0

outfile=open("aims_at_least_5_from_header.txt","w")

for line in open("all_aim_sentences_ids.txt","r"):
    filename,sent_id=line.split()
    # the sentences are all in a div which corresponds to a header
    # abstract sentences don't need to calculate div only s
    if sent_id.startswith("A-"):
        outfile.write("%s %s\n" % (filename,sent_id))
        num_5_away+=1
        continue
    sent=etree.parse(filename).getroot().xpath('.//S[@ID="%s"]' % sent_id)[0]
    # keep going to parent until I find the div
    tmp_element=sent
    while tmp_element.tag!="DIV":
        tmp_element=tmp_element.getparent()
    # now I should have div and need to get sent id of first sentence child
    first_sentence_id_in_div=tmp_element.xpath(".//S")[0].get("ID")
    if int(sent_id.split("-")[1]) - int(first_sentence_id_in_div.split("-")[1]) >= 5:
        outfile.write("%s %s\n" % (filename,sent_id))
        num_5_away+=1
    else:
        num_less+=1
    # print(sent_id,first_sentence_id_in_div)
print(num_5_away,num_less,num_5_away+num_less)
