import csv
from collections import Counter

with open("scientometrics_solution_smo.csv") as fp:
    reader = csv.reader(fp, delimiter=",", quotechar='"')
    next(reader, None)  # skip the headers
    svm_problem_predictions = [row for row in reader]

errors = []
for no, label, prediction, error, predicted, ID in svm_problem_predictions:
    if label != prediction:
        errors.append(int(ID))
errors = sorted(errors)

feature_mapping = {0:'abstract', 1:'acknowledgements', 2:'conclusions', 3:'discussions', 4:'distance', 5:'evaluation', 6:'introduction', 7:'keywords', 8:'method', 9:'related work'}

discourse_data = {}
error_discourse_data = {}
for key, value in feature_mapping.items():
    discourse_data[value] = []
    error_discourse_data[value] = []


solution_data_raw = [line.strip() for line in open('scientometrics_solution_data.txt')]

for line_index, line in enumerate(open('solution_discourse_info.txt', 'r')):
    data = line.strip().split()
    for index, value in enumerate(data[:-1]):
        if int(value) == 0: continue
        # discourse_data[feature_mapping[index]].append([int(value), data[-1]])
        discourse_data[feature_mapping[index]].append([int(value), data[-1], int(data[4])])        
        if line_index+1 in errors:
            if index==8 and int(data[4]) in [0,1,2] and data[-1] == 'non_solution':
                print(data[4], solution_data_raw[line_index+1])
            error_discourse_data[feature_mapping[index]].append([int(value), data[-1], int(data[4])])


print(error_discourse_data['abstract'])
            
for key, value in feature_mapping.items():
    if value == 'distance': continue
    # print(value, sum([e[0] for e in discourse_data[value] if e[1] == 'solution']), [e[2] for e in discourse_data[value]])
    print(value, sum([e[0] for e in error_discourse_data[value] if e[1] == 'solution']), sorted([e[2] for e in error_discourse_data[value] if e[1]=='solution']))
    print(value, sum([e[0] for e in error_discourse_data[value] if e[1] == 'non_solution']), sorted([e[2] for e in error_discourse_data[value] if e[1]=='non_solution']))    
    print(value, sum([e[0] for e in discourse_data[value] if e[1] == 'non_solution']))    
    print(value, sum([e[0] for e in error_discourse_data[value] if e[1] == 'non_solution']))
    print()

print()
    
for value in discourse_data:
    if value == 'distance': continue
    print(value, sum([e[0] for e in discourse_data[value] if e[1] == 'non_solution']))
    print(value, sum([e[0] for e in discourse_data[value] if e[1] == 'solution']))    

print()

solution_counter = Counter([e[0] for e in discourse_data['distance'] if e[1] == 'solution'])
non_solution_counter = Counter([e[0] for e in discourse_data['distance'] if e[1] == 'non_solution'])

print(len(sorted([e[0] for e in error_discourse_data['distance'] if (e[1]=="non_solution" and e[0] in [0,1,2])])))


import matplotlib.pyplot as plt
import numpy as np

fig, axs = plt.subplots(3, 3)
# plt.figure(figsize=(12,8)) 
# fig.suptitle('Vertically stacked subplots')
# feature_mapping = {0:'abstract', 1:'acknowledgements', 2:'conclusions', 3:'discussions', 4:'distance', 5:'evaluation', 6:'introduction', 7:'keywords', 8:'method', 9:'related work'}
# for i, val1 in enumerate(['abstract', 'acknowledgements', 'conclusion', 'dicsussions', 'evaluation']):
#     for j, val2 in enumerate(['introduction', 'keywords','method','related work']):
counter=-1
for i in range(3):
    axs[i, 0].set_ylabel('Frequency')    
    for j in range(3):

    # for j in range(5):
# axs[0].plot(x, y)
# axs[1].plot(x, -y)
        counter += 1
        if counter==10: continue
        if counter==4:
            counter+=1
        print(i,j)
        print(counter)
        bins = np.linspace(0, 10)
        axs[i,j].hist([[e[2] for e in error_discourse_data[feature_mapping[counter]] if e[1] == 'solution'], [e[2] for e in error_discourse_data[feature_mapping[counter]] if e[1] == 'non_solution']], bins=bins, label=['solutions', 'non-solutions'], width=.2, rwidth=3)
        axs[i,j].set_title(feature_mapping[counter])
        axs[i,j].set_yticks(range(0, 20, 5))
        # plt.legend(loc='upper right')
        # axs[i,j].xlabel('Distance from section header')
        # axs[i,j].ylabel('Frequency')
        # axs[i,j].xticks(range(0, 20))


axs[2, 0].set_xlabel('Distance from header')
axs[2, 1].set_xlabel('Distance from header')
axs[2, 2].set_xlabel('Distance from header')        
axs[0,2].legend(loc='upper right', bbox_to_anchor=(1, 1), labels=['solution errors', 'non-solution errors'])
# fig.tight_layout()
fig.set_size_inches(8.5, 6.5)
plt.subplots_adjust(hspace=0.5)
plt.savefig('error_solution_dist_tmp.png')


