import codecs, re

sentences = [s.strip() for s in codecs.open("aims_at_least_5_from_header_candc.txt","r","utf-8").readlines()]

outfile=open("aims_at_least_5_from_header_transitivity.txt","w")

for i,sent in enumerate(sentences):
    output=[]
    for word in sent.split()[1:]:
        features = word.split("|")
        if features[2][0:2]=="VB":
            # intransitive
            try:
                if re.match("S\[.*\]\\\NP",features[-1]): 
                    output+=["intransitive"]
                    # transitive
                elif re.match("\(S\[.*\]\\\NP\)/NP",features[-1]): 
                    output+=["transitive"]
                    # ditransitive
                elif re.match("\(\(S\[.*\]\\\NP\)/NP\)/NP",features[-1]): 
                    output+=["ditransitive"]
            except:
                outfile.write("None\n")
    if len(output)==0:
        outfile.write("None\n")
    else:
        outfile.write(" ".join(set(output))+"\n")
