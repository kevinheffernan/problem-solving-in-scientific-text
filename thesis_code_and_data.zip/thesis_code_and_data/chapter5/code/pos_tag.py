# code to pos tag the tokens in format: token tab pos

import spacy

# outfile=open("problems_august.tag","w")
outfile=open("5_sentences_before_verified_solutions.tag","w")

nlp = spacy.load("en_core_web_sm")

# for index,line in enumerate(open("problem_sentences_from_aims_to_screen_august.txt","r")):
for index,line in enumerate(open("words_from_subtree_candidates_from_parses_PROBLEMS","r")):    
    # print(index)
    line=line.replace("—","-")
    doc=nlp(line.strip(),disable=["parser"])
    for token in doc:
        # for some reason empty tokens are left in
        if token.tag_=="_SP": outfile.write("__SPECIAL_SYMBOL__" + "\t" + token.tag_ + "\n")
        else:
            outfile.write(token.text + "\t" + token.tag_ + "\n")
    outfile.write("\n")
