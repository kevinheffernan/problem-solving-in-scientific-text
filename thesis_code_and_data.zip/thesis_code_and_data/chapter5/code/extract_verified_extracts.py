# I can't believe I'm finally here...

indexes_of_verified_solutions=[]
for line in open("test_september_solutions.pred","r"):
    if "1:solution" in line:
        index=int(line.split()[0])
        # zero indexing
        indexes_of_verified_solutions.append(index-1)
        # print(index-1)

problem_present,presence=[],False
for index,line in enumerate(open("test_september_problems.pred","r")):
    if "1:problem" in line:
        presence=True
    if (index+1) % 5 == 0:
        problem_present.append(presence)
        presence=False

print(len(indexes_of_verified_solutions),len(problem_present),problem_present.count(True))
    
filename_info=[line.strip() for index,line in enumerate(open("aims_at_least_5_from_header.txt","r")) if index in indexes_of_verified_solutions]

outfile=open("verified_extracts","w")

problems,extract=[],[]
for index,line in enumerate(open("5_sentences_before_verified_solutions","r")):
    extract.append(line.strip())
    if (index+1) % 5 == 0:
        problems.append(extract)
        extract=[]

print(len(problems))        

verified_solutions=[line.strip() for index,line in enumerate(open("aims_at_least_5_from_header_sents.txt","r")) if index in indexes_of_verified_solutions]

counts=0
for index,line in enumerate(verified_solutions):
    if problem_present[index]:
        counts+=1
        outfile.write("%s %s\n" % (filename_info[index].split("/")[-1].split(".")[0],filename_info[index].split()[-1]))
        for problem in problems[index]:
            outfile.write("%s\n" % problem)
        outfile.write("%s\n" % line)
        outfile.write("\n")

print(counts)
