from lxml import etree

indexes_of_verified_solutions=[]
for line in open("test_september_solutions.pred","r"):
    if "1:solution" in line:
        index=int(line.split()[0])
        # zero indexing
        indexes_of_verified_solutions.append(index-1)
        # print(index-1)

outfile=open("5_sentences_before_verified_solutions_id_info.txt","w")
        
for index,line in enumerate(open("aims_at_least_5_from_header.txt","r")):
    filename,sent_id=line.strip().split()
    sent_type="A-S" if sent_id.split("-")[0]=="A" else "S"
    sent_number=int(sent_id.split("-")[1])
    if index in indexes_of_verified_solutions:
        root=etree.parse(filename).getroot()
        # get previous 5 sentences in file if verified solution
        for i in range(sent_number-5,sent_number):
            # print(sent_type,i,sent_number,filename)
            previous_sent=root.xpath('.//%s[@ID="%s-%s"]' % (sent_type,sent_type[0],i))[0]
            # outfile.write("".join(previous_sent.itertext())+"\n")
            outfile.write("%s %s-%s\n" % (filename,sent_type[0],i))
        
