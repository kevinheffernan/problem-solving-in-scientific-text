import codecs as cd
import os

class Weka():
    """
    wrapper for weka
    """
    def get_training_features(self):
        training_features=set()
        # for line in open("problem_bow_negation_example_discourse_polarity_transitivity_word2vec_doc2vec_word2vecPolarity_syntax.arff","r"):
        # for line in open("solution_bow_word2vec_trigrams_doc2vec_syntax_transitivity_discourse.arff","r"):
        for line in open("problem_bow_negation_example_discourse_polarity_transitivity_word2vec_doc2vec_word2vecPolarity_syntax.arff","r"):                    
            if line.startswith("@ATTRIBUTE") and not line.startswith("@ATTRIBUTE __CLASS_LABEL__"):
                training_features.add(line.split('"')[1])
        return training_features

    def __init__(self,weka_classpath,arff_dir,prediction_dir):
        """
        initialisation of weka wrapper.

        @param weka_classpath: /path/to/weka.jar
        @type weka_classpath: string

        @param arff_dir: /path/to/arff/files
        @type arff_dir: string

        @param prediction_dir: /path/to/store/predictions
        @type prediction_dir: string
        """
        self.weka_classpath=weka_classpath
        self.arff_dir=arff_dir
        self.prediction_dir=prediction_dir

    def writeArff(self,data,filename):
        """
        converts data to arff file format and writes to file. number of attributes per instance does
        not need to be consistent.

        @param data: data to be written 
        @type data: list of dictionary,label pairs with the dictionary consisting of feature_name:value pairs and label denoting the class label.

        @param filename: name for arff file
        @type filename: string
        """
        arff=cd.open("%s.arff" % filename,"w","utf-8")
        # write relation
        arff.write("@RELATION %s\n" % filename)
        # get list of sorted unique attributes
        # attributes=sorted(list(set([feature for instance,label in data for feature,value in instance.items()]).union(self.get_training_features())))
        attributes=sorted(list(self.get_training_features()))
        # write attributes
        for attribute in attributes: arff.write("@ATTRIBUTE \"%s\" NUMERIC\n" % attribute)
        # add class label attribute
        # arff.write("@ATTRIBUTE __CLASS_LABEL__ {%s}\n" % ",".join(set([label for instance,label in data])))
        arff.write("@ATTRIBUTE __CLASS_LABEL__ {problem,non_problem}\n")
        # write data information
        arff.write("@DATA\n")
        for instance,label in data:
            arff.write("%s\n" % ",".join(["0" if attribute not in instance else str(instance[attribute]) for attribute in attributes]+[label]))

    def evaluate(self,prefix):
        """
        makes system call to weka. performs 10-fold cross-validation and stores predictions.

        @param prefix: prefix for arff and prediction file (e.g. problem_bow)
        @type prefix: string
        """
        # support vector machine
        os.system("java -cp %s weka.classifiers.functions.SMO -t %s.arff -classifications \"weka.classifiers.evaluation.output.prediction.PlainText -file %s.pred\" >/dev/null 2>&1" % (self.weka_classpath,self.arff_dir+prefix,self.prediction_dir+prefix)) 

    def accuracy(self,prefix):
        """
        read prediction file and calculate accuracy.

        @param prefix: prefix for arff and prediction file (e.g. problem_bow)
        @type prefix: string
        """
        num_instances,num_errors=0,0
        for line in open(self.prediction_dir+prefix+".pred","r"):
            # ignore first line and empty lines
            if "inst#" in line or line=="\n": continue
            else: num_instances+=1
            # determine if error in instance
            if "+" in line: num_errors+=1
        return "%.1f" % (100 * ((num_instances-num_errors)/float(num_instances)))


    def predictions(sedlf,prefix):
        """
        returns raw predictions
        """
        predictions=[]
        for line in open(self.prediction_dir+prefix+".pred","r"):
            # ignore first line and empty lines
            if "inst#" in line or line=="\n": continue
            # in weka + carries the error but in my analysis - carries error
            predictions.append("-" if "+" in line else "+")
        return predictions
