MIT License

Copyright (c) 2022

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

###################################################################################
# Problem-solving corpus
###################################################################################

This directory contains the problem-solving corpus by Heffernan and Teufel.
For training, development and test data, each file is provided in three different
formats:
  a) .bio       - BIO encoded
  b) .jsonlines - json format with one context window per line
  c) .txt       - raw text

## Dataset statistics

   Sents  Words
   -------------------------------------
   4800  134898  train/training_docs.txt
    600   16693  dev/dev_docs.txt
    600   16818  test/test_docs.txt
   -------------------------------------
   6000  168409  total

## Directory contents

  1) Instructions for annotators
     - pdf file containing the instructions for annotators to mark material.

  2) Training set
     - training_docs_joint.bio
     - training_docs_joint.jsonlines
     - training_docs_joint.txt
     
     - each training set file comprises 4800 sentences (800 context windows)     

  3) Development set
     - dev_docs_joint.bio
     - dev_docs_joint.jsonlines
     - dev_docs_joint.txt
     [annotations]
       - Annotator_1.txt
       - Annotator_2.txt
       - Annotator_3.txt

     - each dev set file comprises 600 sentences (100 context windows)

  4) Test set
     - test_docs_joint.bio
     - test_docs_joint.jsonlines
     - test_docs_joint.txt
     
     - each test set file comprises 600 sentences (100 context windows)

###################################################################################
